import eventLog from './eventLogModule.js';
import helpers from './helpers.js';

const keyEndpoint = 'https://id.recordedfuture.com/cryptokey';

function _base64ToArrayBuffer(base64) {
    let binaryString = atob(base64);
    let len = binaryString.length;
    let bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
}

function _arrayBufferToBase64(buffer) {
    let binary = '';
    let bytes = new Uint8Array(buffer);
    let len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

function importSecretKey(rawKey) {
    return crypto.subtle.importKey(
        'raw',
        rawKey,
        'AES-GCM',
        false,
        ['encrypt', 'decrypt']
    );
}

function convertBase64toURLsafe(str) {
    return str
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=/g, '');
}

function getChallenge() {
    let randomBytes = new Uint8Array(32);
    crypto.getRandomValues(randomBytes);

    let verifier = convertBase64toURLsafe(_arrayBufferToBase64(randomBytes));

    let enc = new TextEncoder();
    let encodedVerifier = enc.encode(verifier);

    let promise = crypto.subtle.digest({ name: 'SHA-256' }, encodedVerifier);

    return new Promise((resolve) => {
        promise.then((result) => {
            resolve({
                challenge: convertBase64toURLsafe(_arrayBufferToBase64(result)),
                verifier
            });
        });
    });
}

async function createEncryptionKey(accessToken, retry = false) {
    try {
        const request = new Request(keyEndpoint + '/create', {
            method: 'GET',
            headers: new Headers({
                'Authorization': 'Bearer ' + accessToken,
                'x-rf-user-agent': 'RFChromeExtension/6.1.4'    // Updated by gulp task "version"!
            }),
        });
        const res = await fetch(request);
        if (res.status === 200) {
            const base64 = await res.text();
            return _base64ToArrayBuffer(base64);
        } else {
            throw res.status;
        }
    } catch(err) {
        console.error(`Problem when creating encryption key: ${JSON.stringify(err, null, 4)}`);
        await eventLog.error(`Problem when creating encryption key: ${JSON.stringify(err, null, 4)}`);
        await eventLog.addErrorCode(eventLog.ERROR_CODES.CREATE_ENCRYPTION_KEY_ERROR.id);

        if (!retry) {
            await helpers.delay(1000);
            return createEncryptionKey(accessToken, true);
        } else {
            console.error('Problem when trying to create encryption token a second time');
            await eventLog.error('Problem when trying to create encryption token a second time');
            await eventLog.addErrorCode(eventLog.ERROR_CODES.CREATE_ENCRYPTION_KEY_ERROR2.id);
            throw err;
        }
    }
}

async function getEncryptionKey(retry = false) {
    try {
        const request = new Request(keyEndpoint + '/get', {
            method: 'GET',
            headers: new Headers({
                'x-rf-user-agent': 'RFChromeExtension/6.1.4'    // Updated by gulp task "version"!
            }),
        });
        const res = await fetch(request);
        if (res.status === 200) {
            const base64 = await res.text();
            return _base64ToArrayBuffer(base64);
        } else {
            throw res.status;
        }
    } catch (errrrr) {
        await eventLog.error(`Error when trying to get encryption key: ${JSON.stringify(errrrr, null, 4)}`);
        await eventLog.addErrorCode(eventLog.ERROR_CODES.GET_ENCRYPTION_TOKEN_ERROR.id);

        if (!retry) {
            await eventLog.log('Will try to fetch encryption key again');
            // If it fails, then wait 1 second and try again
            await helpers.delay(1000);
            return getEncryptionKey(true);
        } else {
            await eventLog.addErrorCode(eventLog.ERROR_CODES.GET_ENCRYPTION_TOKEN_ERROR2.id);
            await eventLog.error('Failed to get encryption key on retry as well');
            throw errrrr;
        }
    }
}

async function encryptToken(token, key, retry = false) {
    try {
        let enc = new TextEncoder();
        let encoded = enc.encode(token);
        let iv = crypto.getRandomValues(new Uint8Array(16));
        const cryptoKey = await importSecretKey(key)
        const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, cryptoKey, encoded)
        return { ciphertext: _arrayBufferToBase64(ciphertext), iv: _arrayBufferToBase64(iv) };
    } catch (errr) {
        console.error('Problem when trying to encrypt token', err);
        await eventLog.error(`Problem when trying to encrypt token: ${JSON.stringify(err, null, 4)}`);
        await eventLog.addErrorCode(eventLog.ERROR_CODES.ENCRYPT_TOKEN_ERROR.id);

        if (!retry) {
            await helpers.delay(1000);
            return encryptToken(token, key, true);
        } else {
            console.error('Problem when trying to encrypt token a second time');
            await eventLog.error('Problem when trying to encrypt token a second time');
            await eventLog.addErrorCode(eventLog.ERROR_CODES.ENCRYPT_TOKEN_ERROR2.id);
            throw errr;
        }
    }
}

async function decryptToken(ciphertext, key, iv, retry = false) {
    try {
        const cryptoKey = await importSecretKey(key);
        let ivBuffer = _base64ToArrayBuffer(iv);
        const tokenBuffer = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: ivBuffer }, cryptoKey, _base64ToArrayBuffer(ciphertext));
        return String.fromCharCode.apply(null, new Uint8Array(tokenBuffer))
    } catch (errrr) {
        console.error('Problem when trying to decrypt token', errrr);
        await eventLog.error(`Problem when trying to decrypt token ${JSON.stringify(errrr, null, 4)}`);
        await eventLog.addErrorCode(eventLog.ERROR_CODES.DECRYPT_TOKEN_ERROR.id);

        if (!retry) {
            await eventLog.log('Will try to decrypt token again');
            // If it fails, then wait 1 second and try again
            await helpers.delay(1000);
            return decryptToken(ciphertext, key, iv, true);
        } else {
            await eventLog.error('Failed to get encryption key on retry as well');
            await eventLog.addErrorCode(eventLog.ERROR_CODES.DECRYPT_TOKEN_ERROR2.id);
            throw errrrr;
        }
    }
};

export default {
    getChallenge,
    createEncryptionKey,
    getEncryptionKey,
    encryptToken,
    decryptToken
};