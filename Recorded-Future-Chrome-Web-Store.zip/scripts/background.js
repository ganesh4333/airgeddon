/* importScripts('/pdfjs.js'); */

import graphqlHelper from './graphQLhelper.js';
import config from './configModule.js';
import regExpUtil from './regExpUtilModule.js';
import userSettings from './userSettingsModule.js';
import utils from './utilsModule.js';
import eventLog from './eventLogModule.js';
import helpers from './helpers.js';
import sortingFunctions from './sortingFunctions.js';
import authenticationHelpers from './authenticationHelpers.js';

console.log('Background worker running....');

const notificationAlerts = [];
let sandBoxSubmissions = [];

const ICONS = {
  ON: chrome.runtime.getURL('./images/16x16.png'),
  OFF: chrome.runtime.getURL('./images/16x16-grey.png'),
  BLACKLISTED: chrome.runtime.getURL('./images/16x16-blacklisted.png')
};

let exportInProgress = false;

const MAX_AMOUNT_OF_ENTITIES_PER_REQUEST = 200;
const DELAY_BETWEEN_EACH_REQUEST = 300; // in ms
let MAX_RISK_SCORE_CACHE_TIME = 1800000; // 1 800 000 ms = 30 minutes

let getEndpointsRequestCounter;

let _pending = false;
let _retries = 0;
let _timeout, _token, _endpoints;
let iocIgnoreList = [];

let pageWithTooManyEntitiesCache = [];

const tabColor = {};
let riskScores = {};
const intelCardUrls = {};
let currentSite;
let currentUrl;

let cveIds = {};
let nvdData = {};

let fetchIocRiskScoresInProgress = false;
let lastIocRiskScoreFetch;
let debugMode = false;

const shortAlarm = { name: 'shortRefreshRetry', timestep: 1200 };
const longAlarm = { name: 'longRefreshRetry', timestep: 5000, retries: 4 };

let fullAccessList = {
  cve: false,
  ip: false,
  idn: false,
  hash: false,
  url: false
};

let notificationListenerAlreadyCreated = false;
let userHasGrantedNotificationsPermission = false;
let gcmListenerRegistered = false;
let activeDeviceToken;

const checkIfUserHasGrantedNotificationPermission = () => new Promise(resolve => {
  chrome.storage.local.get(['userHasGrantedNotificationsPermission'], (items) => {
    const allowed = items.userHasGrantedNotificationsPermission;
    if (allowed === true) { // First check local storage
      userHasGrantedNotificationsPermission = true;
      createNotificationListeners();
    } else if (allowed === false) {
      userHasGrantedNotificationsPermission = false;
    } else { // If not there, set to true as default
      userHasGrantedNotificationsPermission = true;
      createNotificationListeners();
    }
    resolve();
  });
})

checkIfUserHasGrantedNotificationPermission();
init();
createMessageListener();
createUpdateListener();
createContextMenuListener();
chrome.action.setBadgeBackgroundColor({ color: '#777' });
createContextMenuForIntelCard('pre');
createContextMenuForFusionNote('pre');
showIntro();

/* const readLocalPdfFile = (resource) => 
  new Promise(function(resolve, reject) {
    let path = './';
    let request = new XMLHttpRequest();

    let fail = (error) => {reject(error)};
    ['error', 'abort'].forEach((event) => { request.addEventListener(event, fail); });

    request.addEventListener('load', event => resolve(event));
    request.open('GET', resource.replace(/^\//, path));
    request.send();
  }); */

////////// DEBUGGING ///////////////////////////////////////////


// TODO: fix so that these functions are available to use
/* window.enableDebugMode = () => {
  console.log('Debugging mode enabled');
  debugMode = true;
};

window.disableDebugMode = () => {
  console.log('Debugging mode disabled');
  debugMode = false;
}; */

const log = (...args) => {
  if (debugMode) {
    console.log(...args);
  }
};

const warn = (...args) => {
  if (debugMode) {
    console.warn(...args);
  }
};

const error = (...args) => {
  if (debugMode) {
    console.error(...args);
  }
};

//////////////////////////////////////////////////////////////

const versionRegexes = {
  rVersion: '(([0-9]{1,5}\.[0-9]{1,5})) (r|R)([0-9]{1,5}(\.[0-9]{1,5})?)|((([0-9]{1,5}\.[0-9]{1,5}))(r|R)([0-9]{1,5}(\.[0-9]{1,5})?))', // 4.5 R4.5
  standardVersion1: new RegExp(/((\d{1,5}\.\d{1,5}))/g), // 4.6
  standardVersion2: new RegExp(/((\d{1,5}\.\d{1,5}\.\d{1,5}))/g), // 4.5.6
  standardVersion3: new RegExp(/((\d{1,5}\.\d{1,5}\.\d{1,5}\.\d{1,5}))/g), // 5.3.1.5
  standardVersion4: new RegExp(/((\d{1,5}\.\d{1,5}\.\d{1,5}\.\d{1,5}\.\d{1,5}))/g), // 4.3.6.0.2
  patchVersion: new RegExp(/(((\d{1,5}\.\d{1,5})) (Patch|patch) [0-9]{0,2})/g) // 3.4 Patch 7
}

/* chrome.runtime.onInstalled.addListener(async () => {
  for (const cs of chrome.runtime.getManifest().content_scripts) {
    for (const tab of await chrome.tabs.query({url: cs.matches})) {
      chrome.scripting.executeScript({
        target: {tabId: tab.id},
        files: cs.js,
      });
    }
  }
}); */

async function init() {
  // Automatically set this flag to true so that we never show the intro message for domain abuse alerts
  userSettings.setSettingInStorageByName('hasSeenDomainAbuseAlertsIntro', true);

  chrome.alarms.create({ periodInMinutes: 4.9 });

  // Keep alive hack
  const keepAlive = () => setInterval(chrome.runtime.getPlatformInfo, 20e3);
  chrome.runtime.onStartup.addListener(keepAlive);
  keepAlive();

  setTimeout(async () => {
    const storage = await getStorage();
    if (storage.accessToken) {
      _token = storage.accessToken;
    }
    if (storage.updated === true) {
      chrome.storage.local.set({ updated: false });
    }
    chrome.tabs.query({ active: true, currentWindow: true }, async tabs => {
      const settings = await userSettings.getUserSettings();
      const tabId = (tabs && tabs[0] && tabs[0].id) ? tabs[0].id : null;
      const tabUrl = (tabs && tabs[0] && tabs[0].url) ? tabs[0].url : null;
      let siteIsBlacklisted = false;

      if (tabUrl) {
        currentUrl = tabUrl;
        const url = new URL(tabUrl);
        const host = url.hostname;
        currentSite = host;
      }
      if (currentSite) {
        siteIsBlacklisted = currentSite && settings && settings.userCustomBlacklist &&
          settings.userCustomBlacklist.some(url => currentSite.match(new RegExp(url, 'g')));
      }

      if (_token) {
        _setExtensionIcon(siteIsBlacklisted ? ICONS.BLACKLISTED : ICONS.ON, tabId);
        _updateBadgeTextWithIocCountFromTab(tabId, currentUrl);

        const jwtToken = JSON.parse(atob(_token.split('.')[1]));
        if (jwtToken.modules) {
          const modules = jwtToken.modules.split(' ').map(x => x = x.replace('module:', ''));
          if (modules.includes('brand-protection')) {
            setupFirebaseListener();
          } else {
            warn('User does not have brand protection module, will not create alert listener');
          }
        } else {
          warn('Not a module user, will not create alert listener');
        }
      }
    });
  }, 800);
}

const messageReceivedEventHandler = async (resp, retry = false) => {
  const settings = await userSettings.getUserSettings();
  const anyTypeOfAlertIsEnabled = Object.keys(settings.alertTypes).some(key => settings.alertTypes[key]);
  const userHasGrantedNotificationsPermission = await userSettings.getSettingFromStorageByName('userHasGrantedNotificationsPermission');
  const allowed = userHasGrantedNotificationsPermission === true || userHasGrantedNotificationsPermission === undefined;
  if (_token && anyTypeOfAlertIsEnabled && allowed) {
    log("ALERT FROM FIREBASE: ", resp);
    let title;
    if (resp.data.title && resp.data.title.toLowerCase().includes('mentioned you')) {
      title = 'Mentioned in Playbook Alert';
    } else if (resp.data.title && resp.data.title.toLowerCase().includes('update to')) {
      title = 'Update to Playbook Alert';
    } else if (resp.data.title && resp.data.title.toLowerCase().includes('new playbook alert')) {
      title = 'New Playbook Alert';
    } else {
      title = resp.data.title || 'New Playbook Alert';
    }

    const body = JSON.parse(resp.data.body);
    const caseId = body["case-id"];
    const query = `
    query Case {
      entity(id: "${caseId}") {
        id
        created
        name
        ... on Case {
          priority {
            id
            name
          }
          case_rule {
            id
            name
            tags
            created_at
            level
            risk {
              score
              level
            }
            type {
              name
              displayName
            }
            usecase {
              id
              name
              dashboard
              description
              risk {
                level
                score
              }
              type {
                name
                displayName
              }
            }
          }
          entities {
            id
            name
            longname
            created_at
            risk {
              level
              score
            }
          }
          caseContext {
            ... on DomainAbuseContext {
              maliciousDnsRecords {
                entity {
                  name
                  risk {
                    level
                  }
                }
                assessments {
                  level
                  assessmentId
                  title
                  uiTagName
                }
              }
              targets {
                id
                name
              }
            }
          }
        }
      }
    }   
    `;
    let graphQlResp = await graphqlHelper.submitGraphQLRequest(_token, query);
    log('Case details:', graphQlResp);
    if (graphQlResp && graphQlResp.error && graphQlResp.error.status === 401) {
      // token expired, try again
      if (!retry) {
        await eventLog.error('Received firebase notification but token is expired, try to re-authenticate');
        warn('Received firebase notification but token is expired, try to re-authenticate');
        chrome.tabs.query({ active: true, currentWindow: true }, async tabs => {
          const tabId = (tabs && tabs[0] && tabs[0].id) ? tabs[0].id : null;

          await eventLog.log('_refreshAuthTokens source 002');

          _refreshAuthTokens(tabId, async () => {
            log('Refreshed token, retrying fetch case id');
            await eventLog.log('Refreshed token, retrying fetch case id');
            messageReceivedEventHandler(resp, true);
          }, '007', false, false); // do not logout if failed
        });
      } else {
        error('Could not fetch case');
        eventLog.error('Could not fetch case');
      }
    } else {
      // Display the actual notification
      const notificationId = 'RecordedFutureBrowserExtensionNotificationAlert' + Math.floor(Math.random() * 100000000);
      const iconUrl = chrome.runtime.getURL('./images/logo_bw.png');
      const alertType = (graphQlResp.data && graphQlResp.data.entity && graphQlResp.data.entity['case_rule'])
        ? graphQlResp.data.entity['case_rule'].name.toLowerCase().replaceAll(' ', '')
        : undefined;

      if (alertType && settings.alertTypes.domainAbuse && alertType.includes('domainabuse')) {
        const createdAt = graphQlResp.data.entity.created;
        const id = graphQlResp.data.entity.entities[0].id;
        const name = graphQlResp.data.entity.entities[0].name;
        const formattedDate = new Date(createdAt).toLocaleDateString();
        const formattedTime = new Date(createdAt).toLocaleTimeString();

        const link = `https://app.recordedfuture.com/live/sc/task/?id=${caseId}`;
        const criticality = graphQlResp.data.entity.priority.name;

        // Only show "High" in order to prevent flooding, or if you were directly tagged in a comment
        if (criticality === 'High' || resp.data.title.includes('mentioned you in a comment')) {
          let message =
            `${criticality} alert (${formattedTime}):
          ${name}
          `;
          message = message.replaceAll(/( ){4,4}/g, ''); // remove tabs

          const duplicates = (notificationAlerts && notificationAlerts.length > 0)
            ? notificationAlerts.filter(x =>
              x.title === title &&
              x.alertType === alertType &&
              x.criticality === criticality &&
              x.name === name &&
              x.id === id
            ) : [];
          const minTimeDifference = 1000 * 2; // 2 seconds in ms
          const timestamp = Date.now();
          const duplicateWasShownLessThan30MinutesAgo = duplicates && duplicates.length > 0 && duplicates.some(x => (timestamp - x.timeShown) <= minTimeDifference);

          if (!duplicateWasShownLessThan30MinutesAgo) {
            // Make sure it only shows alerts if no duplicate of it has been shown previously less than x seconds ago
            // This is to prevent multiple alert notifications being displayed at once of the same alert
            notificationAlerts.push({
              notificationId,
              title,
              alertType,
              createdAt,
              id,
              name,
              criticality,
              formattedDate,
              formattedTime,
              link,
              timeShown: Date.now()
            });
            chrome.notifications.create(notificationId, {
              title,
              message,
              type: 'basic',
              priority: 2,
              iconUrl
            });
          } else {
            warn('Did not show alert because a duplicate has already been shown recently');
            log(`Received domain abuse alert for ${name} with level ${criticality}, but it was not shown because it was a duplicate of another alert that has already been shown less than 2 seconds ago`);
            eventLog.log(`Received domain abuse alert for ${name} with level ${criticality}, but it was not shown because it was a duplicate of another alert that has already been shown less than 2 seconds ago`);
          }
        }
      } else {
        eventLog.error(`Could not display notification for alert: ${JSON.stringify(graphQlResp, null, 4)}`);
      }
    }
  } else {
    log('Notification receieved but will not be displayed');
    log('_token', _token);
    log('userHasGrantedNotificationsPermission', userHasGrantedNotificationsPermission);
    log('allowed', allowed);
    log('anyTypeOfAlertIsEnabled', anyTypeOfAlertIsEnabled);
  }
}

const setupFirebaseListener = async (forceRemove = false) => {
  const isFirefox = typeof InstallTrigger !== 'undefined';

  const settings = await userSettings.getUserSettings();
  const anyTypeOfAlertIsEnabled = Object.keys(settings.alertTypes).some(key => settings.alertTypes[key]);

  const onNotEnabled = async () => {
    let deviceTokenToUnregister;
    if (activeDeviceToken) {
      deviceTokenToUnregister = activeDeviceToken;
    } else {
      deviceTokenToUnregister = await userSettings.getSettingFromStorageByName('activeDeviceToken');
    }
    if (deviceTokenToUnregister) {
      const query = `
      mutation RemoveToken {
        unregisterPushNotificationDeviceAppToken(deviceAppToken:"${deviceTokenToUnregister}")
      }
      `;
      await graphqlHelper.submitGraphQLRequest(_token, query);
      activeDeviceToken = undefined;
      await chrome.storage.local.set({ activeDeviceToken: null });
      log('Removed active device token');
    } else {
      warn('Could not find active device token to unregister');
    }
  };

  if (_token) {
    if (!isFirefox && !forceRemove) {
      const jwtToken = JSON.parse(atob(_token.split('.')[1]));
      const modules = jwtToken.modules ? jwtToken.modules.split(' ').map(x => x = x.replace('module:', '')) : [];
      const userHasBrandProtectionModule = modules.includes('brand-protection');

      if (!jwtToken.modules) {
        warn('User does not have modules, cant setup alert listener');
      }

      if (userHasBrandProtectionModule) {
        chrome.storage.local.get(['userHasGrantedNotificationsPermission'], async (items) => {
          const allowed = items.userHasGrantedNotificationsPermission === true || items.userHasGrantedNotificationsPermission === undefined;
          if (allowed && anyTypeOfAlertIsEnabled) {
            log('Alerts are enabled, setup listener');

            if (!gcmListenerRegistered) {
              gcmListenerRegistered = true;
              chrome.gcm.onMessage.addListener(resp => {
                messageReceivedEventHandler(resp)
              });
            } else {
              warn('Attempted to register GCM onMessage listener but it was aborted because it seems to be already registered.');
            }
            chrome.gcm.register(['252434603327'], async (deviceToken) => {
              // The token can be used to send messages specifically to this
              // user. So you can store it server side and when you need to send
              // a message, you can do so.
              activeDeviceToken = deviceToken;
              await chrome.storage.local.set({ activeDeviceToken: activeDeviceToken });

              console.log("Register response: ", deviceToken)
              if (chrome.runtime.lastError) {
                log('Failed to register to GCM');
              } else {
                log('Successfully registered to GCM');
                let query = `
                mutation AddToken {
                  registerPushNotificationDeviceAppToken(applicationId:"com.recordedfuture.browserextension", deviceAppToken:"${deviceToken}", notificationService:FIREBASE, pushCapabilities:[TASKS])
                }
                `;
                let resp = await graphqlHelper.submitGraphQLRequest(_token, query);
                log(resp);
                if (resp && resp.data && resp.data.registerPushNotificationDeviceAppToken !== undefined) {
                  // Success
                  log('Register device app token for extension to firebase');
                  query = `
                  query UCC {
                    useCaseConfigurations {
                      result {
                        id
                        title
                        browserExtensionNotifications {
                          isConfigured
                          enabled
                        }
                      }
                    }
                  }
                  `;
                  resp = await graphqlHelper.submitGraphQLRequest(_token, query);
                  log(resp);
                  if (resp && resp.data && resp.data.useCaseConfigurations && resp.data.useCaseConfigurations.result) {
                    // Success
                    const domainAbuseConfig = resp.data.useCaseConfigurations.result.find(x =>
                      x.title === 'Domain Abuse' ||
                      x.title.includes('Domain Abuse') ||
                      x.title.toLowerCase().replaceAll(' ', '').includes('domainabuse')
                    );
                    if (domainAbuseConfig) {
                      if (domainAbuseConfig.id) {
                        query = `
                        mutation ChangeNotificationSetting {
                          changeUseCaseConfiguration(id:"${domainAbuseConfig.id}", input:{browserExtensionNotifications: {enabled: true, priorities: ["alias:case.priority.high"]}}) {
                            browserExtensionNotifications {
                              enabled
                            }
                          }
                        }
                        `;
                        resp = await graphqlHelper.submitGraphQLRequest(_token, query);
                        log(resp);
                      }
                    }
                  } else {
                    warn('Could not fetch use case configurations');
                    eventLog.error('Could not fetch use case configurations');
                    eventLog.error(JSON.stringify(resp, null, 4));
                  }
                } else {
                  warn('Could not regiser extension device app token');
                  eventLog.error('Could not regiser extension device app token');
                  eventLog.error(JSON.stringify(resp, null, 4));
                }
              }
            });
          } else {
            log('Alerts are disabled');

            if (!isFirefox) {
              chrome.gcm.unregister(() => {
                log('Unregistered from GCM');
              })
            }

            let deviceTokenToUnregister;
            if (activeDeviceToken) {
              deviceTokenToUnregister = activeDeviceToken;
            } else {
              deviceTokenToUnregister = await userSettings.getSettingFromStorageByName('activeDeviceToken');
            }
            if (deviceTokenToUnregister) {
              await onNotEnabled();
            } else {
              warn('No device token found to unregister');
            }
          }
        });
      } else {
        warn('Current user does not have Brand Protection module, will not enable firebase listener');
        await onNotEnabled();
      }
    } else {
      warn('Alerts not available, will not setup firebase listener');
      if (!isFirefox) { // Remove listener if Chrome
        await onNotEnabled();
      }
    }
  }
}

async function showIntro() {
  const hasSeenIntro = await userSettings.getSettingFromStorageByName('hasSeenIntro');
  if (!hasSeenIntro) {
    userSettings.setSettingInStorageByName('hasSeenIntro', true);

    if (typeof InstallTrigger !== 'undefined') { // Firefox
      chrome.tabs.create({
        url: 'https://www.recordedfuture.com/products/browser-extension/get-started/?utm_campaign=express&utm_source=firefox-extension&utm_medium=affiliate'
      });
    } else { // Chrome
      chrome.tabs.create({
        url: 'https://www.recordedfuture.com/products/browser-extension/get-started/?utm_campaign=express&utm_source=chrome-extension&utm_medium=affiliate'
      });
    }
  }
}

function getStorage() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['scope', 'idToken', 'updated', 'refreshToken', 'iv', 'accessToken'], items => {
      const storage = items || [];
      resolve(storage);
    });
  });
}

chrome.runtime.onUpdateAvailable.addListener(function () {
  chrome.storage.local.set({ updated: true });
  chrome.runtime.reload();
});

function updateContextMenus() {
  return getStorage().then(function (storage) {
    chrome.contextMenus.removeAll(function () {
      if (storage.scope !== undefined) {
        if (storage.scope.includes('AnalystNoteCrud') && storage.scope.includes('IntelligenceCard')) {
          createContextMenuForIntelCard('post');
          createContextMenuForFusionNote('post');
        } else if (storage.scope.includes('AnalystNoteCrud') && !storage.scope.includes('IntelligenceCard')) {
          createContextMenuForFusionNote('post');
        } else if (storage.scope.includes('IntelligenceCard') && !storage.scope.includes('AnalystNoteCrud')) {
          createContextMenuForIntelCard('post');
        }
      }
    });
  });
}


function createContextMenuForIntelCard(state) {
  var contextMenuId = 'openintelcard';
  var contextMenuTitle = 'Open Intelligence Card in Recorded Future';
  var contextMenuContexts = ['selection'];
  if (state === 'pre') {
    _createContextMenu(contextMenuId, contextMenuTitle, contextMenuContexts, _handleIntelCardClick);
  } else if (state === 'post') {
    _createContextMenuPostInstall(contextMenuId, contextMenuTitle, contextMenuContexts, _handleIntelCardClick);
  }
}

function createContextMenuForFusionNote(state) {
  var contextMenuId = 'createnote';
  var contextMenuTitle = 'Create Note in Recorded Future';
  var contextMenuContexts = ['selection'];
  if (state === 'pre') {
    _createContextMenu(contextMenuId, contextMenuTitle, contextMenuContexts, _handleCreateNoteClick);
  } else if (state === 'post') {
    _createContextMenuPostInstall(contextMenuId, contextMenuTitle, contextMenuContexts, _handleCreateNoteClick);
  }
}

function urlWasApprovedRecently(url) {
  const item = pageWithTooManyEntitiesCache.find(x => x.url === url || x.url === currentUrl);
  if (item) {
    const timestamp = Date.now();
    // If the user approved this website less than 3 minutes ago then it will still be valid
    if (timestamp <= (item.timestamp + (3 * 60 * 1000))) {
      item.timestamp = timestamp;
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}

function createNotificationListeners() {
  if (userHasGrantedNotificationsPermission) {
    if (!notificationListenerAlreadyCreated) {
      // Listener for notification clicked
      chrome.notifications.onClicked.addListener(notifId => {
        //console.log('notifId', notifId);
        if (notifId.startsWith('RecordedFutureBrowserExtensionNotificationLoggedOut')) {
          //console.log('Notification clicked');
          chrome.notifications.clear(notifId, () => {
            chrome.storage.local.set({ currentLoggedOutNotificationId: undefined });
            chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
              const tab = (tabs && tabs[0]) ? tabs[0] : null;
              if (tab) {
                _startAuthentication(tab.id, true);
              }
            });
          })
        } else if (notifId.startsWith('RecordedFutureBrowserExtensionNotificationAlert')) {
          const alertCase = notificationAlerts.find(x => x.notificationId === notifId);
          if (alertCase) {
            log('Alert notification clicked', alertCase);
            chrome.tabs.create({ url: alertCase.link });
            chrome.notifications.clear(notifId);
            _trackAction({ action: 'userClickedDomainAbuseAlertNotification' });
          }
        } else if (notifId.startsWith('browserExtensionSandboxScanningCompletedNotification')) {
          log('Sandbox scanning complete notification clicked');
          chrome.notifications.clear(notifId);
          chrome.tabs.create({ url: 'https://sandbox.recordedfuture.com/reports/owned' });
          _trackAction({ action: 'userClickedSandboxScanningCompleteNotification' });
        }
      });
      // Listener for notification closed
      chrome.notifications.onClosed.addListener((notifId, byUser) => {
        //console.log('notifId', notifId);
        if (notifId.startsWith('RecordedFutureBrowserExtensionNotificationLoggedOut')) {
          // User dismissed the logged out notification
          //console.log('Notification dismissed', byUser);
          chrome.storage.local.set({ currentLoggedOutNotificationId: undefined });
          log('userDismissedLogoutNotification');
          _trackAction({ action: 'userDismissedLogoutNotification' });

          chrome.storage.local.get(['logoutNotificationDismissCounter'], items => {
            let counter = (items && items.logoutNotificationDismissCounter) ? items.logoutNotificationDismissCounter : 0;
            counter++;
            chrome.storage.local.set({ logoutNotificationDismissCounter: counter });
          });
        }
      });
      notificationListenerAlreadyCreated = true;
    }
  }
}

/**
 * Listen for messages containing an updated number of IoCs on a page,
 * then update the badge text with the new number
 */
function createMessageListener() {
  function connected(portFromCS) {
    if (portFromCS.name === 'port-bkg-cs') {
      portFromCS.onMessage.addListener((request) => {
        if (request.numberOfIocs) {
          const allIocs = request.iocs.matches.reduce((total, current) => {
            total = [...total, ...current.iocs];
            return total;
          }, []).map(x => ({ name: x.name, fromPlainText: x.fromPlainText, fromLink: x.fromLink, redirect: x.redirect }));

          getStorage().then(function (storage) {
            if (storage.refreshToken !== undefined) {
              _fetchIocRiskScores(allIocs, portFromCS.sender.tab.id);
            }
          });
        } else if (request.iframeIocs && request.iframeDomain) {
          const allIocs = request.iocs.matches.reduce((total, current) => {
            total = [...total, ...current.iocs];
            return total;
          }, []).map(x => ({ name: x.name, fromPlainText: x.fromPlainText, fromLink: x.fromLink, redirect: x.redirect }));
          getStorage().then(function (storage) {
            if (storage.refreshToken !== undefined) {
              _fetchIocRiskScores(allIocs, portFromCS.sender.tab.id);
            }
          });
        } else if (request.scanDisabled) {
          if (request.siteIsBlacklisted && _token) {
            _setExtensionIcon(ICONS.BLACKLISTED, portFromCS.sender.tab.id);
          } else {
            _setExtensionIcon(ICONS.OFF, portFromCS.sender.tab.id);
          }
          _setBadgeText('', portFromCS.sender.tab.id);
        } else if (request.scanDisabled === false) {
          _setExtensionIcon(ICONS.ON, portFromCS.sender.tab.id);
        } else if (request.triggerNotification) {
          chrome.storage.local.get(['logoutNotificationDismissCounter', 'userHasGrantedNotificationsPermission', 'lastLoggedOutNotificationTimestamp', 'currentLoggedOutNotificationId'], items => {
            let dismissCounter = (items && items.logoutNotificationDismissCounter) ? items.logoutNotificationDismissCounter : 0;
            userHasGrantedNotificationsPermission = (items.userHasGrantedNotificationsPermission === true || items.userHasGrantedNotificationsPermission == undefined || items.userHasGrantedNotificationsPermission === null);
            const lastLoggedOutNotificationTimestamp = items.lastLoggedOutNotificationTimestamp;
            let currentLoggedOutNotificationId = items.currentLoggedOutNotificationId;

            const currentTimestamp = Date.now();
            const moreThanSevenDaysAgo = lastLoggedOutNotificationTimestamp && currentTimestamp >= (lastLoggedOutNotificationTimestamp + 1000 * 60 * 60 * 24 * 7); // 7 days
            //const moreThanSevenDaysAgo = lastLoggedOutNotificationTimestamp && currentTimestamp >= (lastLoggedOutNotificationTimestamp + 1000 * 60 * 5); // 5 minutes

            const isFirefox = typeof InstallTrigger !== 'undefined';
            /* console.log('token', _token);
            console.log('userHasGrantedNotificationsPermission', userHasGrantedNotificationsPermission)
            console.log('lastLoggedOutNotificationTimestamp', lastLoggedOutNotificationTimestamp)
            console.log('moreThanSevenDaysAgo', moreThanSevenDaysAgo)
            console.log('currentLoggedOutNotificationId', currentLoggedOutNotificationId)
            console.log('dismissCounter', dismissCounter) */

            getStorage().then(storage => {
              if (storage.accessToken) {
                _token = storage.accessToken;
              }
              checkIfUserHasGrantedNotificationPermission().then(() => {
                if (
                  userHasGrantedNotificationsPermission // The extension has the permission
                  && (!lastLoggedOutNotificationTimestamp || moreThanSevenDaysAgo) // Either the user has never seen the notifiction before or the last time it was shown was more than 7 days ago
                  && !_token // And the user has to be logged out
                  && (!currentLoggedOutNotificationId || isFirefox) // No notification is currently displayed (Chrome only)
                  && dismissCounter < 2 // User has not already dismissed this same notification 2 times
                ) {
                  //console.log('show notification')
                  log('Display logout notifcation!');
                  log('userHasGrantedNotificationsPermission', userHasGrantedNotificationsPermission)
                  log('lastLoggedOutNotificationTimestamp', lastLoggedOutNotificationTimestamp)
                  log('moreThanSevenDaysAgo', moreThanSevenDaysAgo)
                  log('_token', _token)
                  log('currentLoggedOutNotificationId', currentLoggedOutNotificationId)
                  log('isFirefox', isFirefox)
                  log('dismissCounter', dismissCounter)

                  chrome.storage.local.set({ lastLoggedOutNotificationTimestamp });
                  const iconUrl = chrome.runtime.getURL('./images/logo_bw.png');

                  currentLoggedOutNotificationId = 'RecordedFutureBrowserExtensionNotificationLoggedOut' + Math.floor(Math.random() * 100000000);
                  chrome.storage.local.set({ currentLoggedOutNotificationId });

                  //const message = 'To access the Recorded Future Browser Extension, please sign in';
                  const message = 'Login to use the Recorded Future browser extension';

                  if (isFirefox) { // Firefox
                    browser.notifications.create(currentLoggedOutNotificationId, {
                      type: 'basic',
                      iconUrl,
                      title: 'Recorded Future Browser Extension',
                      message
                    });
                  } else {
                    chrome.notifications.create(currentLoggedOutNotificationId, {
                      title: 'Recorded Future Browser Extension',
                      message,
                      type: 'basic',
                      priority: 2,
                      requireInteraction: true,
                      iconUrl
                    });
                  }
                }
              });
            });
          });
        } else if (request.pdfTextContent) {
          let text = request.pdfTextContent;
          text = utils.trimText(text);
          utils.findIocs(text, 'document', null, true).then(iocs => {
            let docIocs = JSON.parse(JSON.stringify(iocs));
            const iocsSimplified = docIocs.matches.reduce((total, current) => [...total, ...current.iocs], []);
            chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
              const tab = (tabs && tabs[0]) ? tabs[0] : null;
              if (tab) {
                _fetchIocRiskScores(iocsSimplified, tab.id);
              }
            });
          });
        } else if (request.tooManyEntities) { // Firefox solution
          if (urlWasApprovedRecently(request.url)) {
            // If already approved recently, fetch risk scores and send to popup
            _fetchIocRiskScores(request.entities, portFromCS.sender.tab.id, false, true, false, false, null, true);
          } else {
            _setExtensionIcon(ICONS.BLACKLISTED, portFromCS.sender.tab.id);
            chrome.runtime.sendMessage({ action: 'tooManyEntities', entities: request.entities });
          }
        } else if (request.refreshBadge) {
          const allIocs = request.entities.matches.reduce((total, current) => {
            total = [...total, ...current.iocs];
            return total;
          }, []).map(x => ({ name: x.name, fromPlainText: x.fromPlainText, fromLink: x.fromLink, redirect: x.redirect }));
          _fetchIocRiskScores(allIocs, portFromCS.sender.tab.id, false, true, false, request.forcePopupRedraw);
        } else if (request.getRiskScores) {
          _fetchIocRiskScores(request.iocs, portFromCS.sender.tab.id, true, true);
        } else if (request.fetchRiskScoreCache) {
          // Send current risk score cache to content script
          chrome.tabs.sendMessage(portFromCS.sender.tab.id, {
            action: 'fetchedRiskScoreCache',
            cache: riskScores
          });
        }
      });
    }
  }

  chrome.runtime.onConnect.addListener(connected);
}

let sandboxReportStatus;
let countdownNumber;
let sandboxCountdownInterval;

function startCheckingSandboxReportStatus() {
  let sandboxStatusCheckerInterval;

  sandboxStatusCheckerInterval = setInterval(() => {
    fetch('https://sandbox.recordedfuture.com/rf-api/v0/samples', {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${_token}`,
        'x-rf-user-agent': 'RFChromeExtension/6.1.4'
      }
    }).then(async (response) => {
      const res = await response.json()

      const filteredList = res.data.filter(x => sandBoxSubmissions.find(y => y.id === x.id));

      sandBoxSubmissions.forEach(s => {
        const item = filteredList.find(x => x.id === s.id);
        if (item) {
          s.status = item.status;
        }
      });

      const submissionsStillRunning = filteredList.filter(x => x.status === 'running');

      if (submissionsStillRunning.length === 0) {
        clearInterval(sandboxStatusCheckerInterval);
        sandboxReportStatus = 'done';
        chrome.runtime.sendMessage({
          action: 'sandboxTimerCompleted',
          sandBoxSubmissions
        });
        const iconUrl = chrome.runtime.getURL('./images/logo_bw.png');
        const isFirefox = typeof InstallTrigger !== 'undefined';
        const notifId = `browserExtensionSandboxScanningCompletedNotification${Math.floor(Math.random() * 100000)}`;
        if (isFirefox) { // Firefox
          browser.notifications.create(notifId, {
            type: 'basic',
            iconUrl,
            title: 'Recorded Future Browser Extension',
            message: 'Sandbox scanning completed'
          });
        } else {
          chrome.notifications.create(notifId, {
            title: 'Recorded Future Browser Extension',
            message: 'Sandbox scanning completed',
            type: 'basic',
            priority: 2,
            iconUrl
          });
        }
      }
    });
  }, 3000);
}

function startSandboxTimer() {
  countdownNumber = 160;
  sandboxCountdownInterval = setInterval(() => {
    countdownNumber--;
    console.log(`Countdown timer for sandbox reports ${countdownNumber}`);
    chrome.runtime.sendMessage({
      action: 'sandboxTimerProgress',
      sandBoxSubmissions,
      countdownNumber
    });
    if (countdownNumber <= 0) { // Countdown finished
      clearInterval(sandboxCountdownInterval);
      startCheckingSandboxReportStatus();
    }
  }, 1000)
}

async function submitToSandbox(urls) {
  sandBoxSubmissions = [];

  const promises = [];
  urls.forEach(url => {
    var formdata = new FormData();
    formdata.append('kind', 'url');
    formdata.append('url', url);

    sandBoxSubmissions.push({
      url
    });

    const promise = fetch('https://sandbox.recordedfuture.com/rf-api/v0/samples', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${_token}`,
        'x-rf-user-agent': 'RFChromeExtension/6.1.4'
      },
      body: formdata
    }).then(async (response) => {
      const res = await response.json()
      if (!res.error) {
        const submission = sandBoxSubmissions.find(x => x.url === url);

        if (submission) {
          if (res.id && res.status) {
            submission.id = res.id;
            submission.status = res.status;
            submission.submitted = res.submitted;
          } else if (res.error) {
            submission.status = 'error';
          }
        }
      } else {
        error('Could not submit URLs to sandbox');
        error(JSON.stringify(res, null, 4));
        throw 'Could not submit to sandbox';
      }
    });
    promises.push(promise);
  });

  sandboxReportStatus = 'running';
  Promise.all(promises).then(() => {
    startSandboxTimer();
  })
}

function getPdfTextContent(tabId) {
  chrome.tabs.sendMessage(tabId, {
    action: 'getPdfTextContent'
  });
}

function getCveNvdData(cveId, cveName, delayTime = 1) {
  log('Get NVD data for CVE ' + cveName + ' with id: ' + cveId);
  const promise = new Promise((resolve) => {
    // Check first if we already have NVD data for this CVE cached, in which case we dont need to fetch it again
    let maxCacheTime = debugMode ? 1000 : MAX_RISK_SCORE_CACHE_TIME;
    const now = Date.now();
    const validNvdDataExistsInCache = cveName &&
      nvdData[cveName] &&
      nvdData[cveName].timestamp &&
      (now - nvdData[cveName].timestamp) < maxCacheTime;
    if (validNvdDataExistsInCache) {
      resolve();
    } else {
      helpers.delay(delayTime).then(() => {
        const query = `query {
          entity(id:"${cveId}") {
            name
            hits
            external_info
            ... on ICyberVulnerability {
              affected_products {
                ... on IEntity {
                  id
                  name
                }
              }
              cvssScore {
                version
                baseScore
              }
            }
          }
        }`;
        graphqlHelper.submitGraphQLRequest(_token, query).then(response => {
          if (response && response.data && response.data.entity) {
            let affectedProductList = [];

            if (response.data.entity.cvssScore) {
              response.data.entity.cvssScore.forEach(x => {
                x.version = Number(x.version);
              });
            }
            if (response.data.entity.affected_products) {
              response.data.entity.affected_products.forEach(x => {
                let versionNumber = regExpUtil.getAllVersionNumbers(x.name)[0];
                let nameWithoutVersion = x.name.replace(new RegExp(versionNumber, 'gi'), '');
                let platform = null;

                if (nameWithoutVersion.includes(' for ')) {
                  const parts = nameWithoutVersion.split(' for ');
                  nameWithoutVersion = parts[0];
                  platform = parts[1];
                }

                if (nameWithoutVersion[nameWithoutVersion.length - 1] === ".") { // remove trailing dot
                  nameWithoutVersion = nameWithoutVersion.slice(0, -1);
                }
                nameWithoutVersion = nameWithoutVersion.replace('  ', ' '); // remove double spaces
                nameWithoutVersion = nameWithoutVersion.trim(); // remove trailing space

                const item = affectedProductList.find(p => p.name === nameWithoutVersion && p.platform === platform);
                if (item) {
                  item.versions.push(versionNumber)
                } else { // insert new
                  affectedProductList.push({
                    name: nameWithoutVersion,
                    versions: [versionNumber],
                    platform
                  });
                }
              });
            }

            nvdData[response.data.entity.name] = {
              affectedProducts: affectedProductList,
              cvss: (response.data.entity.cvssScore || null),
              timestamp: Date.now()
            };
          }
          resolve();
        });
      });
    }
  });
  return promise;
}

function generateVersionString(versions) {
  let versionsString = '';

  versions = versions.filter(v => !!v); // filter away undefined

  if (!versions || versions.every(v => !v)) {
    return '';
  }

  if (versions.length > 0) {
    versionsString += ' - Versions: ';
  }

  // Example: 5.2 R8.1
  // 5.2r8.4
  // 4.5 r7
  if (versions.filter(v => new RegExp(versionRegexes.rVersion, 'gi').test(v)).length > 0) {
    let versionsOfThisSort = versions.filter(v => new RegExp(versionRegexes.rVersion, 'gi').test(v));
    versionsOfThisSort.sort(sortingFunctions.sortFunc1);
    const lowest = versionsOfThisSort[0];
    const highest = versionsOfThisSort[versionsOfThisSort.length - 1];
    if (lowest === highest) {
      versionsString += `${lowest}, `;
    } else {
      versionsString += `from ${lowest} to ${highest}, `;
    }

    versions = versions.filter(v => !versionsOfThisSort.includes(v)); // filter away these types
  }
  // Standard versions 1, example 4.5   5.6   5.6
  let standardVersions1 = versions.filter(v => {
    const match = v.match(versionRegexes.standardVersion1)
    return (match && match.length === 1 && match[0] === v);
  });
  if (standardVersions1.length > 0) {
    let versionsOfThisSort = standardVersions1;
    versionsOfThisSort.sort(sortingFunctions.sortFunc2);
    const lowest = versionsOfThisSort[0];
    const highest = versionsOfThisSort[versionsOfThisSort.length - 1];
    if (lowest === highest) {
      versionsString += `${lowest}, `;
    } else {
      versionsString += `from ${lowest} to ${highest}, `;
    }

    versions = versions.filter(v => !versionsOfThisSort.includes(v)); // filter away these types
  }
  // Standard versions 2, example 4.5.5   5.6.2   5.6.5
  let standardVersions2 = versions.filter(v => {
    const match = v.match(versionRegexes.standardVersion2)
    return (match && match.length === 1 && match[0] === v);
  });
  if (standardVersions2.length > 0) {
    let versionsOfThisSort = standardVersions2;
    versionsOfThisSort.sort(sortingFunctions.sortFunc3);
    const lowest = versionsOfThisSort[0];
    const highest = versionsOfThisSort[versionsOfThisSort.length - 1];
    if (lowest === highest) {
      versionsString += `${lowest}, `;
    } else {
      versionsString += `from ${lowest} to ${highest}, `;
    }

    versions = versions.filter(v => !versionsOfThisSort.includes(v)); // filter away these types
  }
  // Standard versions 3, example 4.5.5.5
  let standardVersions3 = versions.filter(v => {
    const match = v.match(versionRegexes.standardVersion3)
    return (match && match.length === 1 && match[0] === v);
  });
  if (standardVersions3.length > 0) {
    let versionsOfThisSort = standardVersions3;
    versionsOfThisSort.sort(sortingFunctions.sortFunc4);
    const lowest = versionsOfThisSort[0];
    const highest = versionsOfThisSort[versionsOfThisSort.length - 1];
    if (lowest === highest) {
      versionsString += `${lowest}, `;
    } else {
      versionsString += `from ${lowest} to ${highest}, `;
    }

    versions = versions.filter(v => !versionsOfThisSort.includes(v)); // filter away these types
  }
  // Standard versions 4, example 4.5.5.5.3
  let standardVersions4 = versions.filter(v => {
    const match = v.match(versionRegexes.standardVersion4)
    return (match && match.length === 1 && match[0] === v);
  });
  if (standardVersions4.length > 0) {
    let versionsOfThisSort = standardVersions4;
    versionsOfThisSort.sort(sortingFunctions.sortFunc5);
    const lowest = versionsOfThisSort[0];
    const highest = versionsOfThisSort[versionsOfThisSort.length - 1];
    if (lowest === highest) {
      versionsString += `${lowest}, `;
    } else {
      versionsString += `from ${lowest} to ${highest}, `;
    }

    versions = versions.filter(v => !versionsOfThisSort.includes(v)); // filter away these types
  }
  // Patch versions, example 3.4 Patch 8
  let patchVersions = versions.filter(v => {
    const match = v.match(versionRegexes.patchVersion)
    return (match && match.length === 1 && match[0] === v);
  });
  if (patchVersions.length > 0) {
    let versionsOfThisSort = patchVersions;
    versionsOfThisSort.sort(sortingFunctions.sortFunc6);
    const lowest = versionsOfThisSort[0];
    const highest = versionsOfThisSort[versionsOfThisSort.length - 1];
    if (lowest === highest) {
      versionsString += `${lowest}, `;
    } else {
      versionsString += `from ${lowest} to ${highest}, `;
    }

    versions = versions.filter(v => !versionsOfThisSort.includes(v)); // filter away these types
  }
  if (versions.length > 0) {
    versions.forEach((v, index) => {
      versionsString += v;
      if (index !== (versions.length - 1)) {
        versionsString += ', ';
      }
    });
  }

  return versionsString;
}

function exportIocsToCsv(iocs, tabId, settings, hasIntelligenceCard, callback) {
  exportInProgress = true;
  log('Export to CSVs');
  const iocsSimplified = iocs.reduce((total, current) => [...total, ...current.iocs], []);

  const now = Date.now();
  let maxCacheTime = debugMode ? 2000 : MAX_RISK_SCORE_CACHE_TIME;

  const someIocsDoesNotExistInCache = iocsSimplified.some(x => !riskScores[x.name]);
  const someIocsInCacheAreOld = iocsSimplified.some(x => riskScores[x.name] && riskScores[x.name].timestamp && (now - riskScores[x.name].timestamp) > maxCacheTime);

  const performExport = function (iocs, callback) {
    log('Begin rendering CSVs and downloading them');
    let downloadRequests = [];
    const promises = [];
    if (hasIntelligenceCard) {
      const cves = iocs.find(x => x.type === 'cves');
      const cveNames = cves.iocs.map(x => x.name);
      cveNames.forEach((name, index) => {
        const cveId = cveIds[name];
        // index 0-100   -> 0s delay
        // index 101-200 -> 1s delay
        // index 201-300 -> 2s delay
        // index 301-400 -> 3s delay
        // etc etc...
        let delay = Math.ceil(index / 100) - 1;
        if (delay < 0) delay = 0;
        delay = delay * 1000;

        if (cveId) {
          const promise = getCveNvdData(cveId, name, delay);
          promises.push(promise);
        }
      });
    }
    Promise.all(promises).then(() => {
      iocs.forEach(iocType => {
        if (iocType.iocs.length > 0) {
          let skip = false;
          if (iocType.type === 'idns' && !settings.entityTypesToShow.domain) {
            skip = true;
          }
          if (iocType.type === 'urls' && !settings.entityTypesToShow.url) {
            skip = true;
          }
          if (iocType.type === 'cves' && !settings.entityTypesToShow.vulnerability) {
            skip = true;
          }
          if (iocType.type === 'ips' && !settings.entityTypesToShow.ip) {
            skip = true;
          }
          if (iocType.type === 'hashes' && !settings.entityTypesToShow.hash) {
            skip = true;
          }
          // No full risk rules exists but instead we have a preview, indicating user does not have full access
          const onlyPreviewsExists = iocType.iocs.every(
            x => (x.riskData && x.riskData.riskRules && !x.riskData.riskRules.evidence && x.riskData.riskRules.summary)
          );
          if (onlyPreviewsExists) { // All of the iocs for this ioc-type have an undefined evidence field for rules
            // If at least one ioc have a riskrules-count bigger than 0 that means risk rules do exist,
            // but user don't have access to them, hence we should skip this ioc typ
            skip = iocType.iocs.some(x => (x.riskData && x.riskData.riskRules && !x.riskData.riskRules.evidence && x.riskData.riskRules.count > 0));
          }
          // Skip the export for this type if it is disabled in settings
          if (!skip) {
            let header = [
              'Name',
              'Risk score',
              'Risk rules',
              'Site found on',
              'Recorded Future Portal Link'
            ];
            if (iocType.type === 'cves') {
              if (hasIntelligenceCard) {
                header = [
                  'Name',
                  'Risk score',
                  'CVSS Score',
                  'Severity',
                  'Affected Products',
                  'Web Reporting Prior to NVD Disclosure',
                  'Exploited in the Wild by Malware',
                  'Recent Verified Proof of Concept Available Using Remote Execution',
                  'Historically Exploited in the Wild by Malware',
                  'Recent Verified Proof of Concept Available',
                  'Historical Verified Proof of Concept Available Using Remote Execution',
                  'Recently Linked to Penetration Testing Tools',
                  'Recently Linked to Exploit Kit',
                  'Recently Linked to Remote Access Trojan',
                  'Recently Linked to Ransomware',
                  'Recently Linked to Malware',
                  'Recent Unverified Proof of Concept Available',
                  'Site found on',
                  'Recorded Future Portal Link'
                ];
              } else { // Express plus
                header = [
                  'Name',
                  'Risk score',
                  'Severity',
                  'Web Reporting Prior to NVD Disclosure',
                  'Exploited in the Wild by Malware',
                  'Recent Verified Proof of Concept Available Using Remote Execution',
                  'Historically Exploited in the Wild by Malware',
                  'Recent Verified Proof of Concept Available',
                  'Historical Verified Proof of Concept Available Using Remote Execution',
                  'Recently Linked to Penetration Testing Tools',
                  'Recently Linked to Exploit Kit',
                  'Recently Linked to Remote Access Trojan',
                  'Recently Linked to Ransomware',
                  'Recently Linked to Malware',
                  'Recent Unverified Proof of Concept Available',
                  'Site found on',
                  'Recorded Future Portal Link'
                ];
              }
            }
            let rows = [header];
            iocType.iocs.forEach(ioc => {
              if (!ioc.riskData && riskScores[ioc.name]) {
                ioc.riskData = riskScores[ioc.name];
              }
            });
            iocType.iocs.sort((a, b) => {
              if (b.riskData && b.riskData.riskScore && a.riskData && a.riskData.riskScore) {
                return b.riskData.riskScore - a.riskData.riskScore
              } else if (b.riskData && b.riskData.riskScore && (!a.riskData || !a.riskData.riskScore)) {
                return 1;
              } else if ((!b.riskData || !b.riskData.riskScore) && a.riskData && a.riskData.riskScore) {
                return -1;
              } else {
                return 0;
              }
            });
            iocType.iocs.forEach(ioc => {
              let riskRules = '';

              if (ioc.riskData && ioc.riskData.riskRules && ioc.riskData.riskRules.evidence) {
                let evidence = ioc.riskData.riskRules.evidence;
                if (ioc.redirect && ioc.redirect.risk && ioc.redirect.risk.rule && ioc.redirect.risk.rule.evidence) {
                  evidence = ioc.redirect.risk.rule.evidence;
                } else if (ioc.riskData && ioc.riskData.riskRules && ioc.riskData.riskRules.evidence) {
                  evidence = ioc.riskData.riskRules.evidence;
                }
                if (evidence) {
                  riskRules = "\"";
                  Object.keys(evidence)
                    .sort((a, b) => {
                      if (evidence[b].level && evidence[a].level) {
                        return evidence[b].level - evidence[a].level;
                      } else {
                        return 0;
                      }
                    })
                    .map(key => evidence[key].rule).forEach(rule => {
                      riskRules += rule + "\n";
                    });
                  riskRules += "\"";
                }
  
                let riskScore = (ioc.riskData && ioc.riskData.riskScore !== undefined && ioc.riskData.riskScore !== null) ? ioc.riskData.riskScore : '';
                const recordedFutureLink = utils.getIntelCardUrl(ioc.name);
                let name = ioc.name;
                if (ioc.redirect && ioc.redirect.redirectsTo) {
                  name = `\"${ioc.name}\nredirects to\n${ioc.redirect.redirectsTo}\"`;
                  if (ioc.redirect.risk) {
                    riskScore = ioc.redirect.risk.score
                  }
                }
  
                let newRow = [
                  name,
                  riskScore,
                  riskRules,
                  currentUrl,
                  recordedFutureLink
                ];
  
                if (iocType.type === 'cves') {
                  const affectedProducts = (nvdData[ioc.name] && nvdData[ioc.name].affectedProducts) ? nvdData[ioc.name].affectedProducts : [];
                  let cvss = (nvdData[ioc.name] && nvdData[ioc.name].cvss) ? nvdData[ioc.name].cvss : [];
                  cvss = cvss.sort((a, b) => b.version - a.version);
                  // Format affected versions
                  let affectedProductsString = affectedProducts.reduce((t, c, i) => {
                    let versionsString = generateVersionString(c.versions);
                    versionsString = versionsString.trim(); // remove trailing space
                    if (versionsString[versionsString.length - 1] === ",") { // remove trailing comma
                      versionsString = versionsString.slice(0, -1);
                    }
  
                    t += `${c.name}${c.platform ? ` for ${c.platform}` : ''} ${versionsString}`;
                    t += "\n";
  
                    if (i === (affectedProducts.length - 1)) {
                      t += "\"";
                    }
                    return t;
                  }, "\"");
                  // Format CVSS Score
                  let cvssString = cvss.reduce((t, c, i) => {
                    /*
                      CVSS documentation: https://www.first.org/cvss/specification-document
    
                      None	0.0
                      Low	0.1 - 3.9
                      Medium	4.0 - 6.9
                      High	7.0 - 8.9
                      Critical	9.0 - 10.0
                    */
                    let criticality = '';
                    const baseScore = c.baseScore || null;
                    if (baseScore) {
                      if (baseScore > 9.0) criticality = '(Critical)';
                      if (baseScore < 9.0 && baseScore > 7.0) criticality = '(High)';
                      if (baseScore < 7.0 && baseScore > 4.0) criticality = '(Medium)';
                      if (baseScore < 4.0 && baseScore > 0.1) criticality = '(Low)';
                    }
                    t += `CVSS ${c.version} Score ${baseScore} of 10 ${criticality}`;
                    t += "\n";
                    if (i === (cvss.length - 1)) {
                      t += "\"";
                    }
                    return t;
                  }, "\"");
                  if (cvssString === '"') cvssString = "\"\"";
                  if (affectedProductsString === '"') affectedProductsString = "\"\"";
  
                  const riskRulesExists = ioc.riskData && ioc.riskData.riskRules && ioc.riskData.riskRules.evidence;
                  const riskRulesAsList = riskRulesExists ? Object.keys(ioc.riskData.riskRules.evidence) : [];
  
                  const riskRule1 = riskRulesExists && riskRulesAsList.includes('noCvssScore');
                  const riskRule2 = riskRulesExists && (riskRulesAsList.includes('malwareActivity') || riskRulesAsList.includes('recentMalwareActivity'));
                  const riskRule3 = riskRulesExists && riskRulesAsList.includes('recentPocVerifiedRemote');
                  const riskRule4 = riskRulesExists && riskRulesAsList.includes('historicMalwareActivity');
                  const riskRule5 = riskRulesExists && riskRulesAsList.includes('recentPocVerified');
                  const riskRule6 = riskRulesExists && riskRulesAsList.includes('pocVerifiedRemote');
                  const riskRule7 = riskRulesExists && riskRulesAsList.includes('recentScannerUptake');
                  const riskRule8 = riskRulesExists && riskRulesAsList.includes('linkedToRecentExploitKit');
                  const riskRule9 = riskRulesExists && riskRulesAsList.includes('linkedToRecentRAT');
                  const riskRule10 = riskRulesExists && riskRulesAsList.includes('linkedToRecentRansomware');
                  const riskRule11 = riskRulesExists && riskRulesAsList.includes('linkedToRecentIntrusionMethod');
                  const riskRule12 = riskRulesExists && riskRulesAsList.includes('recentPocUnverified');
  
                  let severity = '';
                  if (ioc.riskData && ioc.riskData.level === 5) {
                    severity = 'Very critical';
                  } else if (ioc.riskData && ioc.riskData.level === 4) {
                    severity = 'Critical';
                  } else if (ioc.riskData && ioc.riskData.level === 3) {
                    severity = 'High';
                  } else if (ioc.riskData && ioc.riskData.level === 2) {
                    severity = 'Medium';
                  } else if (ioc.riskData && ioc.riskData.level === 1) {
                    severity = 'Low';
                  }
  
                  if (hasIntelligenceCard) {
                    newRow = [
                      ioc.name,
                      riskScore,
                      cvssString,
                      severity,
                      affectedProductsString,
                      (riskRule1 ? 'Yes' : 'No'), // Web Reporting Prior to NVD Disclosure
                      (riskRule2 ? 'Yes' : 'No'), // Exploited in the Wild by Malware
                      (riskRule3 ? 'Yes' : 'No'), // Recent Verified Proof of Concept Available Using Remote Execution
                      (riskRule4 ? 'Yes' : 'No'), // Historically Exploited in the Wild by Malware
                      (riskRule5 ? 'Yes' : 'No'), // Recent Verified Proof of Concept Available
                      (riskRule6 ? 'Yes' : 'No'), // Historical Verified Proof of Concept Available Using Remote Execution
                      (riskRule7 ? 'Yes' : 'No'), // Recently Linked to Penetration Testing Tools
                      (riskRule8 ? 'Yes' : 'No'), // Recently Linked to Exploit Kit
                      (riskRule9 ? 'Yes' : 'No'), // Recently Linked to Remote Access Trojan
                      (riskRule10 ? 'Yes' : 'No'), // Recently Linked to Ransomware
                      (riskRule11 ? 'Yes' : 'No'), // Recently Linked to Malware
                      (riskRule12 ? 'Yes' : 'No'), // Recent Unverified Proof of Concept Available
                      currentUrl,
                      recordedFutureLink
                    ];
                  } else { // Express plus
                    newRow = [
                      ioc.name,
                      riskScore,
                      severity,
                      (riskRule1 ? 'Yes' : 'No'), // Web Reporting Prior to NVD Disclosure
                      (riskRule2 ? 'Yes' : 'No'), // Exploited in the Wild by Malware
                      (riskRule3 ? 'Yes' : 'No'), // Recent Verified Proof of Concept Available Using Remote Execution
                      (riskRule4 ? 'Yes' : 'No'), // Historically Exploited in the Wild by Malware
                      (riskRule5 ? 'Yes' : 'No'), // Recent Verified Proof of Concept Available
                      (riskRule6 ? 'Yes' : 'No'), // Historical Verified Proof of Concept Available Using Remote Execution
                      (riskRule7 ? 'Yes' : 'No'), // Recently Linked to Penetration Testing Tools
                      (riskRule8 ? 'Yes' : 'No'), // Recently Linked to Exploit Kit
                      (riskRule9 ? 'Yes' : 'No'), // Recently Linked to Remote Access Trojan
                      (riskRule10 ? 'Yes' : 'No'), // Recently Linked to Ransomware
                      (riskRule11 ? 'Yes' : 'No'), // Recently Linked to Malware
                      (riskRule12 ? 'Yes' : 'No'), // Recent Unverified Proof of Concept Available
                      currentUrl,
                      recordedFutureLink
                    ];
                  }
                }
                rows = [
                  ...rows,
                  newRow
                ];
              }
            });
            const text = rows.map(e => e.join(",")).join("\n");
            /*
            ALTERNATE METHOD:
            var blob = new Blob([text], { type: "text/csv;charset=utf-8" });
            const reader = new FileReader();
            reader.onload = () => {
                const buffer = reader.result;
                const blobUrl = `data:${blob.type};base64,${btoa(new Uint8Array(buffer).reduce((data, byte) => data + String.fromCharCode(byte), ''))}`;
                let downloading = chrome.downloads.download({
                    url: blobUrl,
                    'filename': `${iocType.label.replace(' ', '')}.csv`,
                });
                downloadRequests = [...downloadRequests, downloading];
            };
            reader.readAsArrayBuffer(blob); */

            // browser.downloads.download for FF?
            try {
              const isFirefox = typeof InstallTrigger !== 'undefined';
              if (isFirefox) {
                var blob = new Blob([text], { type: "text/csv;charset=utf-8" });
                let downloading = chrome.downloads.download({
                  'url': URL.createObjectURL(blob),
                  'filename': `${iocType.label.replace(' ', '')}.csv`,
                });
                downloadRequests = [...downloadRequests, downloading];
              } else {
                const btoaResult = btoa(text);
                let downloading = chrome.downloads.download({
                  'url': 'data:text/csv;base64,' + btoaResult,
                  'filename': `${iocType.label.replace(' ', '')}.csv`,
                });
                downloadRequests = [...downloadRequests, downloading];
              }
            } catch (errorx) {
              console.warn(errorx);
            }
          }
        }
      });
      Promise.all(downloadRequests).then(() => {
        chrome.runtime.sendMessage({ action: 'exportCompleted' });
        exportInProgress = false;
        callback();
      }).catch(err => {
        eventLog.error(`ERROR 4233: ${JSON.stringify(err, null, 4)}`);
        console.warn('ERROR 4233', err);
      });
    }).catch(err => {
      eventLog.error(`ERROR 1219: ${JSON.stringify(err, null, 4)}`);
      console.warn('ERROR 1219', err);
    });
  }

  if (someIocsDoesNotExistInCache || someIocsInCacheAreOld) {
    log('Fetch risk scores before exporting');
    log('someIocsDoesNotExistInCache: ' + someIocsDoesNotExistInCache);
    log('someIocsInCacheAreOld: ' + someIocsInCacheAreOld);
    _fetchIocRiskScores(iocsSimplified, tabId, true, true, false, false, () => {
      log('Export callback');
      performExport(iocs, callback);
    });
  } else {
    performExport(iocs, callback);
  }
}

function createList(entities, isLocalFile, isPdf, currentTab, riskScoreCache) {
  const url = 'https://api.recordedfuture.com/graphql';

  let entityIds = '[';
  entities.forEach((x, i) => {
    if (x.entityType === 'idns' || x.entityType === 'domain') {
      entityIds += `\"idn:${x.name}\"`;
    } else if (x.entityType === 'urls' || x.entityType === 'url') {
      entityIds += `\"url:${x.name}\"`;
    } else if (x.entityType === 'hashes' || x.entityType === 'hash') {
      entityIds += `\"hash:${x.name}\"`;
    } else if (x.entityType === 'ips' || x.entityType === 'ip' || x.entityType === 'ipaddress') {
      entityIds += `\"ip:${x.name}\"`;
    } else if (x.entityType === 'cves' || x.entityType === 'vulnerability') {
      if (riskScoreCache && riskScoreCache[x.name] && riskScoreCache[x.name].cveId) {
        const item = riskScoreCache[x.name];
        const cveId = item.cveId;
        entityIds += `\"${cveId}\"`;
      } else if (cveIds[x.name]) {
        const cveId = cveIds[x.name];
        entityIds += `\"${cveId}\"`;
      }
    }
    if (i !== (entities.length - 1)) entityIds += ',';
  });
  entityIds += ']';
  let listName;

  if (isLocalFile && isPdf) {
    listName = `${currentTab.title} List`;
  } else if (isLocalFile && !isPdf) {
    const parts = currentTab.url.split('/');
    listName = `${parts[parts.length - 1]} List`;
  } else {
    let currentURL = new URL(currentTab.url);
    listName = `${currentURL.protocol}//${currentURL.host} List`;
  }

  eventLog.log(`mutation {\n  createCustomEntityList(title:\"${listName}\", entityIds: ${entityIds}) {\n    id\n    name\n  }\n}`);

  const body = {
    query: `mutation {
          createCustomEntityList(title:"${listName}", entityIds: ${entityIds}) {
            id
            name
          }
        }
        `
  };
  const isFirefox = typeof InstallTrigger !== 'undefined';
  const headers = new Headers({
    'Authorization': 'Bearer ' + _token,
    'Content-Type': 'application/javascript',
    'x-rf-user-agent': 'RFChromeExtension/6.1.4'    // Updated by gulp task "version"!
  });

  fetch(url, {
    headers,
    method: 'POST',
    body: JSON.stringify(body)
  }).then(res => res.json()).then(data => {
    if (data && data.data && data.data.createCustomEntityList && data.data.createCustomEntityList.id) {
      let listId = data.data.createCustomEntityList.id.split(':')[1];
      // Set list description
      const body2 = {
        "operationName": "UpdateListAnnotation",
        "query": `mutation UpdateListAnnotation($listId: Identity!, $annotation: String!) {\n  updateListAnnotation(listId: $listId, annotation: $annotation) {\n    __typename\n    id\n    description\n  }\n}`,
        "variables": { "listId": "report:" + listId, "annotation": "Exported from Browser Extension" },
        "tracing": false
      };
      fetch(url, {
        headers,
        method: 'POST',
        body: JSON.stringify(body2)
      }).then(res => res.json()).then(data => {
        const openList = (listId) => {
          chrome.runtime.sendMessage({ action: 'listCreated' });
          let redirectUrl = `https://app.recordedfuture.com/portal/list/${listId}`;
          chrome.tabs.create({ url: redirectUrl });

          /* if (isFirefox) {
            chrome.tabs.create({
              url: redirectUrl
            }, () => {
              //window.close();
            });
          } else {
            chrome.tabs.create({ url: redirectUrl });
          } */
        }
        setTimeout(() => {
          openList(listId);
        }, 5500);
      }).catch(err => {
        eventLog.addErrorCode(eventLog.ERROR_CODES.CREATE_LIST_ERROR.id);
        console.error(err);
        chrome.runtime.sendMessage({ action: 'listCreationError', msg: 'Something went wrong' });
      });
    }
  }).catch(err => {
    eventLog.addErrorCode(eventLog.ERROR_CODES.CREATE_LIST_ERROR2.id);
    console.error(err);
    chrome.runtime.sendMessage({ action: 'listCreationError', msg: 'Something went wrong' });
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getToken') {
    eventLog.log('Request getToken')
    userSettings.getUserSettings().then(settings => {
      const siteIsBlacklisted = currentSite && settings && settings.userCustomBlacklist &&
        settings.userCustomBlacklist.some(url => currentSite.match(new RegExp(url, 'g')));
      if (_token && !siteIsBlacklisted) {
        _setExtensionIcon(ICONS.ON, request.tabId);
      } else if (_token && siteIsBlacklisted) {
        _setExtensionIcon(ICONS.BLACKLISTED, request.tabId);
      } else {
        _setExtensionIcon(ICONS.OFF, request.tabId);
      }
    });
    getStorage().then(storage => {
      if (storage.accessToken) {
        _token = storage.accessToken;
      }
      sendResponse(_token);
    });
  } else if (request.action === 'setDisabledIcon') {
    _setExtensionIcon(ICONS.BLACKLISTED, request.tabId);
  } else if (request.action === 'getEntitiesResponse') {
    // Send entities to popup
    chrome.runtime.sendMessage({ action: 'getEntitiesResponseToPopup', msg: request.msg });
  } else if (request.action === 'getPdfRiskScoresFromBackground') {
    getPdfTextContent(request.tabId);
  } else if (request.action === 'export') {
    // This is a timeout function. If the export is not done within 15 seconds we can assume that is has faield along the way
    // Notify popup about this so it can clear the loading state
    setTimeout(() => {
      if (exportInProgress) {
        chrome.runtime.sendMessage({ action: 'exportCompleted', timeout: true });
        exportInProgress = false;
      }
    }, 40000);
    userSettings.getUserSettings().then(settings => {
      exportIocsToCsv(request.currentIocs.matches, request.tabId, settings, request.hasIntelligenceCard, () => {
        sendResponse({ status: 'download_started' });
      });
    });
  } else if (request.action === 'updateBadge') {
    if (!request.value) {
      _setBadgeText('', request.tabId);
      chrome.action.setBadgeBackgroundColor({
        color: '#777',
        tabId: request.tabId
      });
    }
  } else if (request.action === 'fetchRiskScores') {
    _fetchIocRiskScores(request.iocs, request.tabId, false, true, false, false, null, true);
  } else if (request.action === 'userDeniedNotificationsPermission') {
    userHasGrantedNotificationsPermission = false;
  } else if (request.action === 'userGrantedNotificationsPermission') {
    userHasGrantedNotificationsPermission = true;
    createNotificationListeners();
  } else if (request.action === 'currentPageIsApproved') {
    sendResponse(urlWasApprovedRecently(request.url));
  } else if (request.action === 'sandboxCompletedDismissed') {
    sandBoxSubmissions = [];
  } else if (request.action === 'getSandboxSubmissions') {
    sendResponse({ sandBoxSubmissions, countdownNumber });
  } else if (request.action === 'getRiskScores') {
    sendResponse(riskScores);
  } else if (request.action === 'getCveIds') {
    sendResponse(cveIds);
  } else if (request.action === 'submitToSandbox') {
    submitToSandbox(request.urls);
  } else if (request.action === 'getRedirectUrls') {
    fetchRedirectUrls(request.urlList).then(resp => {
      sendResponse(resp);
    });
  } else if (request.action === 'getExportStatus') {
    sendResponse(exportInProgress);
  } else if (request.action === 'updateAlertsMessageListener') {
    setupFirebaseListener();
  } else if (request.action === 'createList') {
    createList(request.entities, request.isLocalFile, request.isPdf, request.currentTab, request.riskScoreCache);
  } else if (request.action === 'getFullAccessList') {
    sendResponse(fullAccessList);
  } else if (request.action === 'startAuthentication') {
    eventLog.log('startAuthentication requested');
    _startAuthentication(request.tabId)
      .then((token) => {
        sendResponse(token);
      }).catch((err) => {
        eventLog.addErrorCode(eventLog.ERROR_CODES.START_AUTHENTICATION_THROW_ERROR.id);
        eventLog.error(`ERROR 1219: ${JSON.stringify(err, null, 4)}`);
        console.log(err);
      });
  } else if (request.action === 'refreshAuthTokens') {
    eventLog.log('_refreshAuthTokens source 003');
    _refreshAuthTokens(request.tabId, null, '003');
  } else if (request.action === 'signOut') {
    eventLog.log(`Sign out due to signout action being called from browser, manual: ${request.manual}`);
    _signOut(request.manual, request.tabId, '000');
  }
  return true;
});

/**
 * Listen for context menu click events and handle the click appropriately
 */
function createContextMenuListener() {
  chrome.contextMenus.onClicked.addListener(function (info) {
    if (info.menuItemId === 'openintelcard') {
      _handleIntelCardClick(info);
    } else if (info.menuItemId === 'createnote') {
      _handleCreateNoteClick(info);
    }
  });
}

/**
 * Listen for changes of the page content
 * If the content has finished loading, count the IoCs on the page and update the badge text
 * if not, wait 5 seconds before scanning the page content
 */
function createUpdateListener() {
  chrome.tabs.onActivated.addListener(function (activeInfo) {
    // When changing tab, also change badge color
    if (tabColor[activeInfo.tabId]) {
      chrome.action.setBadgeBackgroundColor({
        color: tabColor[activeInfo.tabId],
        tabId: activeInfo.tabId
      });
    }
    userSettings.getUserSettings().then(settings => {
      chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
        const tab = (tabs && tabs[0]) ? tabs[0] : null;
        if (tab && tab.url !== '') {
          currentUrl = tab.url;
          const url = new URL(tab.url);
          const host = url.hostname;
          currentSite = host;

          if (currentSite) {
            const siteIsBlacklisted = currentSite && settings && settings.userCustomBlacklist &&
              settings.userCustomBlacklist.some(url => currentSite.match(new RegExp(url, 'g')));

            if (_token && !siteIsBlacklisted) {
              _setExtensionIcon(ICONS.ON, activeInfo.tabId);
            } else if (_token && siteIsBlacklisted) {
              _setExtensionIcon(ICONS.BLACKLISTED, activeInfo.tabId);
            } else {
              _setExtensionIcon(ICONS.OFF, activeInfo.tabId);
            }
          }
        }
      });
    });
  });

  chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    const isPdf = tab && tab.url && tab.url.split('?')[0].toLowerCase().endsWith('.pdf');

    if (tab) {
      currentUrl = tab.url;
      const url = new URL(tab.url);
      const host = url.hostname;
      currentSite = host;
    }

    if (isPdf) { // If user is looking at a pdf file a special fix is needed to update the badge
      getPdfTextContent(tabId);
    } else if (changeInfo.status === 'complete') {
      _updateBadgeTextWithIocCountFromTab(tabId);

      userSettings.getUserSettings().then(settings => {
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
          const tab = (tabs && tabs[0]) ? tabs[0] : null;
          if (tab) {
            currentUrl = tab.url;
            const url = new URL(tab.url);
            const host = url.hostname;
            currentSite = host;

            if (currentSite) {
              const siteIsBlacklisted = currentSite && settings && settings.userCustomBlacklist &&
                settings.userCustomBlacklist.some(url => currentSite.match(new RegExp(url, 'g')));

              if (_token && !siteIsBlacklisted) {
                _setExtensionIcon(ICONS.ON, tabId);
              } else if (_token && siteIsBlacklisted) {
                _setExtensionIcon(ICONS.BLACKLISTED, tabId);
              } else {
                _setExtensionIcon(ICONS.OFF, tabId);
              }
            }
          }
        });
      });
    } else {
      // Set an alarm in 5 seconds
      chrome.alarms.create('delayedBadgeUpdate', { when: Date.now() + 3000 });
    }
  });

  // Listen to triggered alarms
  chrome.alarms.onAlarm.addListener(function (alarm) {
    console.log('Alarm listener triggered');
    if (alarm.name === 'delayedBadgeUpdate') {
      _updateBadgeTextWithIocCountFromTab();
    }
  });
}

const setIocLinks = iocs => {
  iocs.forEach(ioc => {
    if (intelCardUrls[ioc.name]) {
      ioc.link = intelCardUrls[ioc.name];
    } else {
      const url = utils.getIntelCardUrl(ioc.name);
      intelCardUrls[ioc.name] = url;
      ioc.link = url;
    }
  });
}

async function fetchRedirectUrls(urlList) {
  const resp = [];
  const promises = [];

  for (let i = 0; i < urlList.length; i++) {
    const itemInCache = await helpers.getUrlRedirectFromCache(urlList[i]);
    if (itemInCache) {
      resp.push({
        from: urlList[i],
        to: itemInCache.redirectToUrl
      });
    } else {
      const promise = new Promise(resolve1 => {
        fetch(urlList[i]).then(res => {
          if (res.url) {
            resp.push({
              from: urlList[i],
              to: res.url
            });
            if (debugMode) {
              resolve1();
            } else {
              helpers.addUrlRedirectToCache(urlList[i], res.url).then(() => {
                resolve1();
              });
            }
          } else {
            if (debugMode) {
              resolve1();
            } else {
              helpers.addUrlRedirectToCache(urlList[i], null).then(() => {
                resolve1();
              });
            }
          }
        }).catch(err => {
          console.log('Could not fetch redirect info for ' + urlList[i])
          console.log(JSON.stringify(err, null, 4));
          if (debugMode) {
            resolve1();
          } else {
            helpers.addUrlRedirectToCache(urlList[i], null).then(() => {
              resolve1();
            });
          }
        });
      })
      promises.push(promise);
    }
  }
  if (promises.length > 0) {
    return Promise.all(promises).then(() => {
      return resp;
    });
  } else {
    return resp;
  }
}

function _fetchIocRiskScores(iocs, tabId, doNotSendToPopup = false, updateBadge = true, retry = false, forcePopupRedraw = false, callback = null, userLoadAllDespiteAmountExceedsLimit = false) {
  if (fetchIocRiskScoresInProgress && lastIocRiskScoreFetch) {
    const timestamp = Date.now();
    // If last time this function was called was more than 10 seconds ago
    // then reset the inprogress-flag to false and let it be fetched again
    // this is a safety for a bug wher inprogress-flag would not be reset to
    // false properly which meant fetching would no longer happen
    const diff = timestamp - lastIocRiskScoreFetch;
    if (diff < 10000) {
      return;
    } else {
      fetchIocRiskScoresInProgress = false;
    }
  }

  if (fetchIocRiskScoresInProgress || _pending) {
    return;
  }

  fetchIocRiskScoresInProgress = true;
  lastIocRiskScoreFetch = Date.now();
  const now = Date.now();

  if (!_token) {
    fetchIocRiskScoresInProgress = false;
    return;
  }

  if (iocs.matches) { // Wrong format, get all as list instead
    iocs = iocs.matches.reduce((total, current) => {
      total = [...total, ...current.iocs];
      return total;
    }, []).map(x => ({ name: x.name, fromLink: x.fromLink, fromPlainText: x.fromPlainText }));
  }

  userSettings.getUserSettings().then(settings => {
    // Check that all found IoCs aren't already stored in memory (if they are they cannot be older than the max cache time)
    let maxCacheTime = debugMode ? 10 : MAX_RISK_SCORE_CACHE_TIME;
    const noNewIocs = iocs.every(x => riskScores[x.name] && riskScores[x.name].timestamp && (now - riskScores[x.name].timestamp) < maxCacheTime);
    const anyRedirectUrls = iocs.some(x => x.redirect && !x.redirect.risk && x.redirect.redirectsTo && !riskScores[x.redirect.redirectsTo]); // at least one IoC has a redirect target without risk score
    let iocsClone = iocs.slice(0);

    if (noNewIocs && _token && !anyRedirectUrls) {
      iocsClone.forEach(ioc => {
        if (riskScores[ioc.name]) {
          ioc.riskData = riskScores[ioc.name];
          if (ioc.redirect && ioc.redirect.redirectsTo && !ioc.redirect.risk) {
            if (riskScores[ioc.redirect.redirectsTo]) {
              ioc.redirect.risk = riskScores[ioc.redirect.redirectsTo];
            }
          }
        }
      });
      if (updateBadge) {
        setBadge(iocsClone, tabId);
      }
      fetchIocRiskScoresInProgress = false;
      if (!doNotSendToPopup && _token || forcePopupRedraw) {
        setIocLinks(iocsClone);
        // If 'userLoadAllDespiteAmountExceedsLimit' is true that means the page has too many entities, but the user
        // has manually chosen to load all by clicking the button in the popup. In which case we should save this choice
        // in memory so that if the user opens the opens again right away we will remember that choice. It will be valid for x minutes
        if (userLoadAllDespiteAmountExceedsLimit) {
          const item = pageWithTooManyEntitiesCache.find(x => x.url === currentUrl);
          if (item) {
            item.timestamp = Date.now();
          } else {
            pageWithTooManyEntitiesCache.push({
              url: currentUrl,
              timestamp: Date.now()
            });
          }
        }
        chrome.runtime.sendMessage({ action: 'sendRiskScoresFromBackgroundToPopup', tabId, riskScores, iocs: iocsClone, forcePopupRedraw, userLoadAllDespiteAmountExceedsLimit });
      }
      chrome.tabs.sendMessage(tabId, {
        action: 'fetchedIocRiskScores',
        iocs: iocsClone
      });
    } else {
      const url = 'https://express-api.recordedfuture.com/rfq/v2/soar/enrichment';
      const requests = [];
      const allIocsInPayload = [];
      // If the ioc is in the ignore list and the timestamp is less than 5000ms ago that means we recently tried to enrich this one
      // Do not include in list
      if (!userLoadAllDespiteAmountExceedsLimit) {
        iocsClone = iocsClone.filter(ioc => !iocIgnoreList.find(x => x.name === ioc.name && x.timestamp >= Date.now() - 5000));
      }
      //const iocsThatAreNew = iocsClone.filter(x => !riskScores[x.name]);
      /* let iocsThatAreNew = iocsClone.filter(x => 
                              !Object.keys(riskScores).includes(x.name) &&
                              !Object.keys(riskScores).some(i => i.startsWith(x.name.slice(0, 220)))
                             ); */
      let iocsThatAreNew = iocsClone.filter(x => {
        if (riskScores[x.name] && riskScores[x.name].timestamp) {
          const age = now - riskScores[x.name].timestamp;
          // If the cached risk score is older than the max cache time then we will refetch the risk score, in case it has updated
          // See RF-73279
          let maxCacheTime = debugMode ? 10 : MAX_RISK_SCORE_CACHE_TIME;
          if (age > maxCacheTime) {
            return true;
          } else {
            return false;
          }
        } else {
          return true;
        }
      });
      for (let i = 0; i * MAX_AMOUNT_OF_ENTITIES_PER_REQUEST < iocsThatAreNew.length; i++) {
        const iocsSubset = iocsThatAreNew.slice(MAX_AMOUNT_OF_ENTITIES_PER_REQUEST * i, MAX_AMOUNT_OF_ENTITIES_PER_REQUEST * i + MAX_AMOUNT_OF_ENTITIES_PER_REQUEST);
        const body = {
          ip: [],
          domain: [],
          hash: [],
          url: [],
          vulnerability: []
        };
        const requestOptions = {
          method: 'POST',
          headers: new Headers({
            'Authorization': 'Bearer ' + _token,
            'x-rf-user-agent': 'RFChromeExtension/6.1.4'    // Updated by gulp task "version"!
          }),
        };
        iocsSubset.forEach(ioc => {
          // If risk score for ioc has already been fetched before and is stored in memory
          // then get risk data from memory to reduce amount of http request to RF api
          if (regExpUtil.isIdn(ioc.name)) {
            body.domain.push(ioc.name);
            allIocsInPayload.push(ioc.name);
          } else if (regExpUtil.isUrl(ioc.name)) {
            if (settings.entityTypesToShow.url || settings.disableMaliciousLinks) {
              if (ioc.redirect) {
                if (!body.url.includes(ioc.redirect.redirectsTo)) {
                  body.url.push(ioc.redirect.redirectsTo);
                }
              }
              body.url.push(ioc.name);
              allIocsInPayload.push(ioc.name);
            }
          } else if (regExpUtil.isCve(ioc.name)) {
            body.vulnerability.push(ioc.name);
            allIocsInPayload.push(ioc.name);
          } else if (regExpUtil.isIPAddress(ioc.name)) {
            body.ip.push(ioc.name);
            allIocsInPayload.push(ioc.name);
          } else if (regExpUtil.isHash(ioc.name)) {
            body.hash.push(ioc.name);
            allIocsInPayload.push(ioc.name);
          }
        });
        if ( // Don't make a request if there are no IoCs
          body.vulnerability.length > 0 ||
          body.domain.length > 0 ||
          body.url.length > 0 ||
          body.ip.length > 0 ||
          body.hash.length > 0
        ) {
          requestOptions.body = JSON.stringify(body);
          const request = new Request(url, requestOptions);
          requests.push(request);
        }
      }
      Promise.all(requests.map((req, i) => new Promise((resolve, reject) => {
        return helpers.delay(DELAY_BETWEEN_EACH_REQUEST * i).then(() => {
          fetch(req)
            .then(response => {
              if (response.status === 401) {
                reject(401);
              } else if (response.status === 429) {
                reject(429);
              } else {
                return response.json()
              }
            })
            .then(resp => {
              iocsClone.forEach(ioc => {
                let item = (resp && resp.data && resp.data.results && resp.data.results.length > 0) ? resp.data.results.find(x => x.entity.name === ioc.name) : null;
                if (!item) {
                  item = (resp && resp.data && resp.data.results && resp.data.results.length > 0) ? resp.data.results.find(x => x.entity.name.slice(0, 220) === ioc.name.slice(0, 220)) : null;
                }

                let hasCveId = false;

                if (item && item.entity && item.entity.name && regExpUtil.isCve(item.entity.name)) { // Item is CVE
                  // Store the CVE id in memory so we can use it later for mapping
                  cveIds[item.entity.name] = item.entity.id;
                  hasCveId = true;
                }

                if (item) {
                  if (regExpUtil.isIPAddress(item.entity.name) && !fullAccessList.ip) {
                    if (item.risk && item.risk.rule && item.risk.rule.evidence) {
                      fullAccessList.ip = true;
                    }
                  } else if (regExpUtil.isCve(item.entity.name) && !fullAccessList.cve) {
                    if (item.risk && item.risk.rule && item.risk.rule.evidence) {
                      fullAccessList.cve = true;
                    }
                  } else if (regExpUtil.isUrl(item.entity.name) && !fullAccessList.url) {
                    if (item.risk && item.risk.rule && item.risk.rule.evidence) {
                      fullAccessList.url = true;
                    }
                  } else if (regExpUtil.isHash(item.entity.name) && !fullAccessList.hash) {
                    if (item.risk && item.risk.rule && item.risk.rule.evidence) {
                      fullAccessList.hash = true;
                    }
                  } else if (regExpUtil.isIdn(item.entity.name) && !fullAccessList.idn) {
                    if (item.risk && item.risk.rule && item.risk.rule.evidence) {
                      fullAccessList.idn = true;
                    }
                  }
                }

                if (ioc.redirect) {
                  let redirectItem = (resp && resp.data && resp.data.results && resp.data.results.length > 0) ? resp.data.results.find(x => x.entity.name === ioc.redirect.redirectsTo) : null;
                  if (redirectItem) {
                    ioc.redirect.risk = redirectItem.risk;
                    riskScores[redirectItem.entity.name] = {
                      level: redirectItem.risk.level,
                      riskScore: redirectItem.risk.score,
                      timestamp: Date.now(),
                      riskRules: redirectItem.risk.rule,
                      mostCriticalRule: redirectItem.risk.rule.mostCritical
                    }
                  }
                }

                if (item) {
                  let riskScore = 0;
                  let criticality = 1;
                  let riskRules;
                  let level;
                  if (item.risk) {
                    riskScore = item.risk.score || item.risk.context.public.score || 0;
                    level = item.risk.level || 0;
                    if (item.risk.level && item.risk.score) {
                      criticality = item.risk.level;
                    } else if (item.risk.context.public && item.risk.context.public.summary && riskScore !== 0) {
                      const sortedSummary = item.risk.context.public.summary.sort((a, b) => b.level - a.level);
                      criticality = sortedSummary[0] ? sortedSummary[0].level : 1;
                    }
                    if (criticality > 3) criticality = 3;
                    if (criticality < 1) criticality = 1;
                    let triggeredRiskRuleSummaryExists = false;
                    if (item.risk.context.public.summary && item.risk.context.public.summary.length > 0) {
                      triggeredRiskRuleSummaryExists = true;
                    }
                    riskRules = item.risk.rule || item.risk.context.public;
                    // Save the risk score in memory
                    const mostCriticalRule = item.risk.context.public.mostCriticalRule;
                    //const cveId = cveIds && cveIds[item.entity.name];

                    if (hasCveId) {
                      riskScores[ioc.name] = { riskScore, level, mostCriticalRule, criticality, triggeredRiskRuleSummaryExists, riskRules, timestamp: Date.now(), cveId: item.entity.id };
                    } else {
                      riskScores[ioc.name] = { riskScore, level, mostCriticalRule, criticality, triggeredRiskRuleSummaryExists, riskRules, timestamp: Date.now() };
                    }
                    if (ioc.redirect) {
                      riskScores[ioc.name].redirect = ioc.redirect;
                    }

                    ioc.riskData = { riskScore, criticality, triggeredRiskRuleSummaryExists, riskRules, level };
                  }
                } else if (riskScores[ioc.name]) {
                  ioc.riskData = riskScores[ioc.name];
                } else if (allIocsInPayload.includes(ioc.name)) {
                  // only add to ignore list if the ioc actually was in the request payload
                  iocIgnoreList.push({
                    name: ioc.name,
                    timestamp: Date.now()
                  });
                }
              });
              // For IOCs that we did not recieve risk information for from API they are also to be stored in cache. This is to avoid
              // multiple calls for the same IOCs
              iocsClone.filter(x => !x.riskData && allIocsInPayload.includes(x.name)).forEach(ioc => {
                riskScores[ioc.name] = {
                  riskScore: 0,
                  level: 1,
                  mostCriticalRule: undefined,
                  criticality: 1,
                  triggeredRiskRuleSummaryExists: false,
                  riskRules: undefined,
                  timestamp: Date.now()
                };
                ioc.riskData = riskScores[ioc.name];
              });
              resolve();
            }).catch(async err => {
              console.warn('ERROR 6743', err);

              await eventLog.error(`ERROR 6743: ${JSON.stringify(err, null, 4)}`);
              await eventLog.addErrorCode(eventLog.ERROR_CODES.ENRICHMENT_THROW_ERROR.id);
              await logStackTrace();

              fetchIocRiskScoresInProgress = false;
            })
        }).catch(async err => {
          console.warn('ERROR 8921', err);

          await eventLog.error(`ERROR 8921: ${JSON.stringify(err, null, 4)}`);
          await eventLog.addErrorCode(eventLog.ERROR_CODES.ENRICHMENT_THROW_ERROR2.id);
          await logStackTrace();

          fetchIocRiskScoresInProgress = false;
        })
      })))
        .then(() => {
          fetchIocRiskScoresInProgress = false;
          if (updateBadge) {
            setBadge(iocsClone, tabId);
          }
          setIocLinks(iocsClone);
          if (!doNotSendToPopup && _token || forcePopupRedraw) {
            // If 'userLoadAllDespiteAmountExceedsLimit' is true that means the page has too many entities, but the user
            // has manually chosen to load all by clicking the button in the popup. In which case we should save this choice
            // in memory so that if the user opens the opens again right away we will remember that choice. It will be valid for x minutes
            if (userLoadAllDespiteAmountExceedsLimit) {
              const item = pageWithTooManyEntitiesCache.find(x => x.url === currentUrl);
              if (item) {
                item.timestamp = Date.now();
              } else {
                pageWithTooManyEntitiesCache.push({
                  url: currentUrl,
                  timestamp: Date.now()
                });
              }
            }
            chrome.runtime.sendMessage({ action: 'sendRiskScoresFromBackgroundToPopup', tabId, riskScores, iocs: iocsClone, forcePopupRedraw, userLoadAllDespiteAmountExceedsLimit });
          }
          if (callback) {
            callback();
          }
          if (allIocsInPayload.length > 0) { // Only send message if there were at least 1 IoC in the request payload
            chrome.tabs.sendMessage(tabId, {
              action: 'fetchedIocRiskScores',
              iocs: iocsClone
            });
          }
        })
        .catch(async err => {
          await eventLog.error(`ERROR 82720: ${JSON.stringify(err, null, 4)}`);
          await eventLog.addErrorCode(eventLog.ERROR_CODES.PROCESS_ENRICHMENT_RESPONSE.id);
          await logStackTrace();
          await eventLog.log(`Enrichment failed`);

          fetchIocRiskScoresInProgress = false;
          log('Enrichment failed');

          if (err === 401 && !retry && !_pending) {
            eventLog.log(`Error 401, unauthorized, try to refresh tokens`);
            log('Error 401, unauthorized, try to refresh tokens');

            const fun = (errorCallback, source, force) => {
              try {
                eventLog.log('_refreshAuthTokens source 004');
                _refreshAuthTokens(tabId, () => {
                  setTimeout(() => {
                    log('Refreshed token, retrying fetch');
                    eventLog.log('Refreshed token, retrying fetch');
                    _fetchIocRiskScores(iocs, tabId, doNotSendToPopup, updateBadge, true, forcePopupRedraw, callback);
                  }, 1200);
                }, source, force)
              } catch (errr) {
                eventLog.addErrorCode(eventLog.ERROR_CODES.ERROR_ON_REFRESH_AUTH_TOKEN_AND_THEN_TRY_TO_ENRICH_AGAIN.id);

                eventLog.error(`ERROR 11990: ${JSON.stringify(errr, null, 4)}`);
                logStackTrace();

                if (errorCallback) {
                  errorCallback();
                }
                throw errr;
              }
            };

            try {
              log('First try');
              fun(null, '004', false);
            } catch (er) {
              log('ERROR CODE 5002 at first refresh try; ' + er);
              eventLog.error(`ERROR 5002: ${JSON.stringify(er, null, 4)}`);
              logStackTrace();

              fetchIocRiskScoresInProgress = false;
              setTimeout(() => {
                log('Second try to refresh, pending = ' + _pending);
                if (_pending) {
                  fun(() => {
                    log('Second try failed, sign out');
                    eventLog.error(`ERROR 101919: Second try failed, sign out`);
                    logStackTrace();
                    _signOut();
                  }, '007', true);
                }
              }, 5000);
            }
          } else if (err === 429) {
            fetchIocRiskScoresInProgress = false;
          }
        });
    }
  });
}

function setBadge(iocs, tabId) {
  const iocsOriginal = iocs;
  if (!_token) {
    _setBadgeText('', tabId);
    return;
  }

  userSettings.getUserSettings().then(settings => {
    const siteIsBlacklisted = currentSite && settings && settings.userCustomBlacklist &&
      settings.userCustomBlacklist.some(url => currentSite.match(new RegExp(url, 'g')));
    if (siteIsBlacklisted) {
      chrome.action.setBadgeBackgroundColor({
        color: '#777',
        tabId: tabId
      });
      _setExtensionIcon(ICONS.BLACKLISTED, tabId);
      return;
    }


    if (settings.entityTypesToShow.url) { // Scrape URLs
      iocs = iocs.filter(x => {
        if (x.fromPlainText === undefined && x.fromLink === undefined) { // Not URL
          return true;
        } else { // Is URL
          return (!!x.fromPlainText || (x.fromLink && x.riskData && x.riskData.riskScore >= 65));
        }
      });
    } else { // Do not include URLS at all
      iocs = iocs.filter(x => x.fromPlainText === undefined && x.fromLink === undefined);
    }

    iocs.forEach(ioc => {
      if (ioc.redirect && ioc.redirect.redirectsTo && !ioc.redirect.risk) {
        ioc.redirect.risk = riskScores[ioc.redirect.redirectsTo];
        if (!ioc.redirect.risk) {
          if (riskScores[ioc.name] && riskScores[ioc.name].redirect && riskScores[ioc.name].redirect.risk) {
            ioc.redirect.risk = riskScores[ioc.name].redirect.risk;
          }
        }
      }

      if (ioc.riskData && ioc.riskData.riskScore) {
        let criticality;
        if (ioc.riskData.riskScore >= 65) {
          criticality = 3;
        } else if (ioc.riskData.riskScore >= 25) {
          criticality = 2;
        } else {
          criticality = 1;
        }

        ioc.riskData.criticality = criticality;
      }
    });

    iocs.forEach(ioc => {
      if (riskScores && ioc.name && riskScores[ioc.name]) {
        ioc.riskData = riskScores[ioc.name];
      }
    });
    const iocsWithRiskData = iocs.filter(x => x.riskData || (x.redirect && x.redirect.risk));

    if (iocsWithRiskData.length > 0) {
      iocsWithRiskData.forEach(ioc => {
        const duplicateThreat = iocsOriginal.find(x => x.name !== ioc.name && x.name.toLowerCase() === ioc.name);
        if (duplicateThreat && duplicateThreat.riskData && duplicateThreat.riskData.riskScore > ioc.riskData.riskScore) {
          ioc.riskData = duplicateThreat.riskData;
        }
      });
      const topThreat = iocsWithRiskData.sort((a, b) => {
        let aLevel = (a.redirect && a.redirect.risk && a.redirect.risk.level && a.redirect.risk.level > a.riskData.criticality) ? a.redirect.risk.level : a.riskData.criticality;
        let bLevel = (b.redirect && b.redirect.risk && b.redirect.risk.level && b.redirect.risk.level > b.riskData.criticality) ? b.redirect.risk.level : b.riskData.criticality;
        return bLevel - aLevel;
      })[0];
      let maxCriticality = topThreat && topThreat.riskData ? topThreat.riskData.criticality : 1;
      if (topThreat.redirect && topThreat.redirect.risk && topThreat.redirect.risk.level && topThreat.redirect.risk.level > maxCriticality) {
        maxCriticality = topThreat.redirect.risk.level;
      }

      let numberOfIocsWithMaxCriticality;
      if (maxCriticality === 1) {
        numberOfIocsWithMaxCriticality = iocs.filter(x => {
          return !x.riskData || x.riskData.criticality === maxCriticality || (x.redirect && x.redirect.risk && x.redirect.risk.level === maxCriticality)
        }).length;
      } else {
        numberOfIocsWithMaxCriticality = iocsWithRiskData.filter(x => {
          return (x.riskData.criticality === maxCriticality) || (x.redirect && x.redirect.risk && x.redirect.risk.level === maxCriticality);
        }).length;
      }

      _setBadgeText(numberOfIocsWithMaxCriticality + '', tabId);
      let color;
      if (maxCriticality >= 3) {
        color = '#CF0A2C';
      } else if (maxCriticality >= 2) {
        color = '#CFA600';
      } else {
        color = '#777';
      }
      tabColor[tabId] = color;
      chrome.action.setBadgeBackgroundColor({
        color: color,
        tabId: tabId
      });
    } else {
      _setBadgeText('0', tabId);
    }
  });
}

/**
 * Call the "scan tabs and update badge text" method with the current tabId
 * @param tabId
 * @private
 */
function _updateBadgeTextWithIocCountFromTab(tabId, url) {
  // Prevent multiple calls at the same time
  _debounce(function () {
    if (tabId && url) {
      _getIocsInTab(tabId, url);
    } else {
      // No tabId/page-url specified, so query the browser for the current tab.
      chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
        if (!tabs || tabs.length === 0) {
          return;
        }
        tabId = tabs[0].id;
        url = tabs[0].url;
        _getIocsInTab(tabId, url);
      });
    }

  }, 250);
}

function _getIocsInTab(tabId, url) {
  const tokenExists = !!_token;
  chrome.tabs.sendMessage(tabId, {
    action: 'getEntities',
    userLoggedIn: tokenExists,
    pageUrl: url
  }, iocResponse => {
    if (chrome.runtime.lastError) {
      // no initialized content script, do nothing
      return;
    }
    if (iocResponse && iocResponse.iocsResult) {
      const allIocs = iocResponse.iocsResult.matches.reduce((total, current) => {
        total = [...total, ...current.iocs];
        return total;
      }, []).map(x => ({ name: x.name, fromLink: x.fromLink, fromPlainText: x.fromPlainText, redirect: x.redirect }));

      // Only count entities that are not url from links, unless they have a riskscore of over 65
      const filteredIocs = allIocs.filter(ioc => ((!ioc.fromLink && !ioc.fromPlainText) || (ioc.fromLink && riskScores[ioc.name] && riskScores[ioc.name].riskScore >= 65)));

      if (filteredIocs.length <= config.MAX_AMOUNT_OF_ENTITIES) { // TODO RÄKNA BORT LÄNKAR HÄR
        _fetchIocRiskScores(allIocs, tabId);
      } else {
        const item = pageWithTooManyEntitiesCache.find(x => x.url === currentUrl);
        if (item) {
          const timestamp = Date.now();
          // If the user approved this website less than 3 minutes ago then it will still be valid
          if (timestamp <= (item.timestamp + (3 * 60 * 1000))) {
            item.timestamp = timestamp;
            _setExtensionIcon(ICONS.ON, tabId);
            setBadge(allIocs, tabId);
          } else {
            _setExtensionIcon(ICONS.BLACKLISTED, tabId);
          }
        } else {
          _setExtensionIcon(ICONS.BLACKLISTED, tabId);
        }
      }
    }
  });
}


//////////////////////////////////////////////////////////////

/* function displayTooManyEntitiesNotification() {
  chrome.tabs.query({currentWindow: true, active: true}, function (tabs) {
    chrome.tabs.sendMessage(tabs[0].id, {
      url: tabs[0].url,
      action: 'displayTooManyEntitiesNotification'
    });
  });
} */

/**
 * Create a context menu entry
 */
function _createContextMenu(contextMenuId, contextMenuTitle, contextMenuContexts) {
  // Firefox does not yet support onInstalled...
  if ('onInstalled' in chrome.runtime) {
    chrome.runtime.onInstalled.addListener(function () {
      chrome.contextMenus.create({
        id: contextMenuId,
        title: contextMenuTitle,
        contexts: contextMenuContexts
      });
    });
  } else {
    chrome.contextMenus.create({
      id: contextMenuId,
      title: contextMenuTitle,
      contexts: contextMenuContexts
    });
  }
}

function _createContextMenuPostInstall(contextMenuId, contextMenuTitle, contextMenuContexts) {
  chrome.contextMenus.create({
    id: contextMenuId,
    title: contextMenuTitle,
    contexts: contextMenuContexts
  });
}

/**
 * Handle context menu clicks for 'Open Intel Card' option
 * @param info
 * @private
 */
function _handleIntelCardClick(info) {
  var text = info.selectionText;

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (tabs.length === 0) {
      return;
    }
    chrome.tabs.create({ url: utils.getIntelCardUrl(text) });
  });
}

/**
 * Handle context menu clicks for 'Create Note' option
 * @param info
 * @private
 */
function _handleCreateNoteClick(info) {
  var text = info.selectionText;

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (tabs.length === 0) {
      return;
    }

    // We want to leave title and url empty for some URLs (e.g. gmail.com)
    var includeTitleAndURL = utils.isTitleAndURLincluded(tabs[0].url);
    var url = includeTitleAndURL ? tabs[0].url : '';
    var title = includeTitleAndURL ? tabs[0].title : '';

    chrome.tabs.create({ url: utils.getCreateNoteUrl(title, url, text) });
  });
}

/**
 * Update the badge text for a specific tab
 * @param text
 * @param tabId
 * @private
 */
function _setBadgeText(text, tabId) {
  chrome.action.setBadgeText({ text: text, tabId: tabId });
}


/**
 * Update the icon image depending on if it is enabled or not
 * @param enabled
 * @private
 */
function _setExtensionIcon(icon, tabId = null) {
  if (tabId) {
    chrome.action.setIcon({ path: icon, tabId });
  } else {
    chrome.action.setIcon({ path: icon });
  }
}

const _getEndpoints = async () => {
  if (_endpoints !== undefined && !debugMode) {
    return _endpoints;
  } else {
    try {
      const configUrl = 'https://id.recordedfuture.com/.well-known/openid-configuration';
      const request = new Request(configUrl, {
        method: 'GET',
        headers: new Headers({
          'Content-Type': 'application/json',
          'x-rf-user-agent': 'RFChromeExtension/6.1.4'    // Updated by gulp task "version"!
        }),
      });

      if (!getEndpointsRequestCounter) {
        getEndpointsRequestCounter = 1;
      } else {
        getEndpointsRequestCounter++;
      }

      let res = await fetch(request);
      if (res.status === 200) {
        res = await res.json();
        // If request was successful, set counter to 0
        getEndpointsRequestCounter = 0;
        const data = {
          auth: res['authorization_endpoint'],
          info: res['userinfo_endpoint'],
          endSession: res['end_session_endpoint'],
          token: res['token_endpoint']
        };
        _endpoints = data;
        return _endpoints;
      } else {
        throw res.status;
      }
    } catch (errr) {
      await eventLog.error(`Problem with fetching endpoints ${JSON.stringify(errr, null, 4)}`);
      console.error(`Problem with fetching endpoints ${JSON.stringify(errr, null, 4)}`);
      // Backup hardcoded endpoints
      return {
        auth: 'https://id.recordedfuture.com/authorize',
        info: 'https://id.recordedfuture.com/userinfo',
        endSession: 'https://id.recordedfuture.com/logout',
        token: 'https://id.recordedfuture.com/token'
      };
    }
  }
};

async function _startAuthentication(tabId = null, triggeredFromNotification = false) {
  eventLog.log('Start authentication');
  return new Promise((resolve) => {
    _getEndpoints().then(async (res) => {
      const authEndpoint = res.auth;
      const redirectUri = _redirectUrl();
      authenticationHelpers.getChallenge().then((resp) => {
        const authUrl = authEndpoint +
          '?client_id=' + 'express' +
          '&audience=' + 'service%3Agraphql%20service%3Asoar-api%20https%3A%2F%2Fsandbox.recordedfuture.com%2F' +
          '&response_type=code' +
          '&code_challenge=' + resp.challenge +
          '&code_challenge_method=' + 'S256' +
          '&redirect_uri=' + redirectUri +
          '&scope=' + 'openid%20email%20IntelligenceCard%20AnalystNoteCrud%20offline_access%20FreeData%20GraphQLApi%20ListCreate%20Modules%20MalwareSandbox';

        chrome.identity.launchWebAuthFlow({ 'url': authUrl, 'interactive': true }, redirectedTo => {
          if (redirectedTo !== undefined) {
            const url = new URL(redirectedTo);
            const code = url.searchParams.get('code');
            const body = {
              'grant_type': 'authorization_code',
              'client_id': 'express',
              'code_verifier': resp.verifier,
              'code': code,
              'redirect_uri': redirectUri
            };

            const request = new Request(res.token, {
              method: 'POST',
              headers: new Headers({
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
              }),
              body: _urlEncode(body)
            });
            fetch(request).then(response => {
              if (response.status === 200) {
                response.json().then((data) => {

                  getStorage().then((storage) => {
                    const accessToken = data['access_token'];
                    _token = accessToken;
                    const scope = _getScope(_token);
                    const idToken = data['id_token'];

                    chrome.tabs.sendMessage(tabId, { action: 'signedIn', scope });

                    _trackAction({ action: 'SysTriggeredBrowserExtensionSignedIn' }).then(async () => {
                      if (storage.refreshToken === undefined) {
                        authenticationHelpers.createEncryptionKey(_token).then((key) => {
                          authenticationHelpers.encryptToken(data['refresh_token'], key).then((encryptionResult) => {
                            _saveToStorage(scope, idToken, encryptionResult.ciphertext, encryptionResult.iv, accessToken);
                            chrome.storage.local.set({ logoutNotificationDismissCounter: 0 });
                            if (triggeredFromNotification) {
                              _trackAction({ action: 'userClickedLogoutNotification' });
                            }
                            chrome.storage.local.get(['currentLoggedOutNotificationId'], items => {
                              const currentLoggedOutNotificationId = items.currentLoggedOutNotificationId;
                              if (currentLoggedOutNotificationId) {
                                chrome.notifications.clear(currentLoggedOutNotificationId, () => {
                                  chrome.storage.local.set({ currentLoggedOutNotificationId: undefined });
                                });
                              }
                              chrome.storage.local.set({ lastLoggedOutNotificationTimestamp: undefined });
                            });
                          });
                        }).catch((err) => {
                          eventLog.error(
                            `Error creating encryption key ${JSON.stringify(err) || 'N/A'}`
                          );
                          console.warn('Error creating encryption key, status: ' + err);
                          logStackTrace();
                          _signOut(false, undefined, '001');
                        });
                      } else {
                        chrome.storage.local.set({ scope: scope, idToken: idToken });
                      }
                      _setExtensionIcon(ICONS.ON, tabId);
                      _updateBadgeTextWithIocCountFromTab();

                      const jwtToken = JSON.parse(atob(_token.split('.')[1]));
                      if (jwtToken.modules) {
                        const modules = jwtToken.modules.split(' ').map(x => x = x.replace('module:', ''));
                        if (modules.includes('brand-protection')) {
                          setupFirebaseListener();
                        } else {
                          warn('User does not have brand protection module, will not create alert listener');
                        }
                      } else {
                        warn('User does not have modules, cant setup alert listener');
                      }
                      resolve(_token);
                    });
                  });
                });
              } else if (response.status >= 400 && response.status < 500) {
                eventLog.error(
                  `Error when trying to refresh auth token (003) with error code ${response.status || 'N/A'}.
                      Message: ${response.message || 'N/A'}`
                );
                console.warn('Error signing in, status: ' + response.status);
                logStackTrace();
                _signOut(false, undefined, '002');
              }
            });
          } else if (chrome.runtime.lastError) {
            eventLog.error(
              `Error on launchWebAuthFlow: ${chrome.runtime.lastError.message || 'N/A'}`
            );
            console.warn('Error signing in, lastError: ' + chrome.runtime.lastError.message);
            logStackTrace();
            _signOut(false, undefined, '003');
          }
        });
      });
    });
  });
}

async function _refreshAuthTokens(tabId = null, callback = null, source = 'N/A', force = false, logoutIfFailed = true) {
  const storage = await getStorage();
  if (storage.accessToken) {
    _token = storage.accessToken;
  }
  if (!_token) { // do not attempt to refresh token if the user doesn't have a token
    return;
  }
  log(`Attempt to refresh token. Timestamp: ${Date.now()}, pending: ${_pending}, source: ${source}`);
  await eventLog.log(`Attempt to refresh token. Timestamp: ${Date.now()}, pending: ${_pending}, source: ${source}`);
  if ((!_pending || _retries > 0) || force) {
    _pending = true;
    try {
      const storage = await getStorage();
      await eventLog.log(`storage fetched: ${JSON.stringify(storage, null, 4)}`);
      await eventLog.log(`_retries: ${_retries}`);

      let request;

      if (storage && storage.refreshToken && _retries < 5) {
        const res = await _getEndpoints();
        await eventLog.log('Get encryption key');
        const oldKey = await authenticationHelpers.getEncryptionKey();
        const refreshToken = await authenticationHelpers.decryptToken(storage.refreshToken, oldKey, storage.iv)
        await eventLog.log(`Decrypt token, refresh token used: ${refreshToken}`);
        const body = {
          'grant_type': 'refresh_token',
          'client_id': 'express',
          'scope': 'openid%20email%20IntelligenceCard%20AnalystNoteCrud%20offline_access%20FreeData%20GraphQLApi%20ListCreate%20Modules%20MalwareSandbox',
          'refresh_token': refreshToken
        };

        await eventLog.log(
          `Refresh request:
        refreshToken: ${refreshToken.slice(0, 5)}....
        token: ${res.token.slice(0, 6)}....`);

        request = new Request(res.token, {
          method: 'POST',
          headers: new Headers({
            'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
          }),
          body: _urlEncode(body)
        });
        const response = await fetch(request)
        log('Response from IDP when refreshing token', response)
        await eventLog.log(`Response from IDP when refreshing token ${JSON.stringify(response, null, 4)}`);

        if (response.status !== 200) {
          try {
            console.warn('Refresh token failed!');
            console.warn(JSON.stringify(response, null, 4));
            console.warn(response);
            console.warn(response.status);
            console.warn(response.message);
  
            const data = await response.json();
            console.warn('data', data);
  
            console.warn('The request:');
            console.warn('body', body);
            console.warn('refreshToken', refreshToken);
            console.warn('res', res);
            console.warn('res.token', res.token);
            console.warn('timestamp', Date.now());
            eventLog.error('Refresh token failed!');
            eventLog.error(JSON.stringify(response, null, 4));
          } catch (errorx) {
            console.error('ERROR 78324');
            console.error(errorx);
          }
        }

        if (response.status === 200) {
          const data = await response.json();
          const accessToken = data['access_token'];
          _token = accessToken;

          const newKey = await authenticationHelpers.createEncryptionKey(_token);
          const encryptionResult = await authenticationHelpers.encryptToken(data['refresh_token'], newKey);
          const scope = _getScope(_token);
          const idToken = data['id_token'];
          eventLog.log('Auth token refreshed, saving to storage');
          _saveToStorage(scope, idToken, encryptionResult.ciphertext, encryptionResult.iv, accessToken);
          _resetRefreshLock('003', tabId);
          if (callback) {
            callback();
            return;
          }
        } else if ((response.status >= 400 && response.status < 429) || (response.status >= 430 && response.status < 500)) {
          console.warn('Error refreshing tokens, status: ' + response.status);
          console.warn(JSON.stringify(response, null, 4));
          await eventLog.error(
            `Error when trying to refresh auth token (001) with error code ${response.status || 'N/A'}.
              Message: ${response.message || 'N/A'}`
          );
          await eventLog.error(JSON.stringify(response, null, 4));
          await eventLog.addErrorCode(eventLog.ERROR_CODES.REFRESH_AUTH_TOKEN2.id);
          await logStackTrace();

          if (logoutIfFailed) {
            await eventLog.log('Will now log out 7489234823');
            logStackTrace();
            _signOut(false, undefined, '004');
            _resetRefreshLock('004', tabId);
          }
        } else if (response.status === 503 || response.status === 0 || response.status === 429) {
          await eventLog.error(
            `Error when trying to refresh auth token (002) with error code ${response.status || 'N/A'}.
              Message: ${response.message || 'N/A'}`
          );
          _retryRefresh(longAlarm.name, longAlarm.timestep);
        } else {
          _retryRefresh(shortAlarm.name, shortAlarm.timestep);
        }
      } else {
        // Refresh token does not exist in storage, user is not logged in
        //_retries = _retries + 1;
        await eventLog.addErrorCode(eventLog.ERROR_CODES.REFRESH_AUTH_TOKEN1.id);
        await logStackTrace();
        await eventLog.log(
          `Sign out user. storage.refreshToken: ${storage.refreshToken}, _retries: ${_retries}`
        );
        logStackTrace();
        _signOut(false, undefined, '007');
        _resetRefreshLock('007', tabId);
      }
    } catch (errrrr) {
      await eventLog.addErrorCode(eventLog.ERROR_CODES.REFRESH_AUTH_TOKEN5.id);
      await logStackTrace();
      await eventLog.error(`error 98765 ${JSON.stringify(errrrr, null, 4)}`);
      console.warn('ERROR', errrrr);

      if (getEndpointsRequestCounter >= 2) {
        //_signOutCleanup(true);
        console.warn('Too many calls to get endpoints failed');
        await eventLog.error(`Too many calls to get endpoints failed`);
        logStackTrace();
        _signOut(false, undefined, '009');
      } else {
        await eventLog.log(`Retry refresh 83838`);
        _retryRefresh(shortAlarm.name, shortAlarm.timestep);
      }
    }
  }
}

function _resetRefreshLock(source = 'N/A', tabId = null) {
  log(`_resetRefreshLock, source: ${source}`);
  if (tabId) {
    eventLog.log(`_resetRefreshLock, source: ${source}`);
  }
  _retries = 0;
  _pending = false;
}

function _retryRefresh(alarmKey, delay) {
  if (alarmKey === shortAlarm.name) {
    _retries = _retries + 1;
  }
  setTimeout(() => {
    eventLog.log('_refreshAuthTokens source 005');
    _refreshAuthTokens(null, null, '001');
  }, delay);
}

function _redirectUrl() {
  // identity return faulty firefox redirect url, so this is hardcoded and handled
  return (typeof InstallTrigger !== 'undefined') ?
    browser.identity.getRedirectURL() :
    chrome.identity.getRedirectURL();
}

function _urlEncode(str) {
  return Object.entries(str)
    .map(([k, v]) => encodeURIComponent(k) + '=' + encodeURIComponent(v))
    .join('&');
}

const logStackTrace = async () => {
  const stack = helpers.getStackTrace();
  await eventLog.log(`Stack trace:
  ${stack}`);
  return;
}

async function _signOut(manual = false, tabId = undefined, source = 'N/A') {
  await setupFirebaseListener(true);

  log('Sign out, source: ' + source);
  await eventLog.log(`Sign out, source: ${source}`);

  _token = undefined;
  riskScores = {};
  if (tabId) {
    chrome.tabs.sendMessage(tabId, { action: 'userLoggedOut' });
    await eventLog.log(`Sign out from extension. Manual: ${manual}, source: ${source}`);
  }

  if (!manual) {
    await logStackTrace();
    const simplifiedErrorCodeLog = await eventLog.getSimplifiedErrorCodeLog();
    if (simplifiedErrorCodeLog) {
      await eventLog.log(`67392: Error code log: ${simplifiedErrorCodeLog}`);
    }
  }

  _setBadgeText('', tabId);
  _setExtensionIcon(ICONS.OFF, tabId);

  const storage = await getStorage();
  const signOutEndpoint = (_endpoints && _endpoints.endSession) ? _endpoints.endSession : 'https://id.recordedfuture.com/logout';
  const redirectUri = _redirectUrl();

  let params = '?client_id=' + 'express' +
    '&post_logout_redirect_uri=' + redirectUri;
  if (storage.idToken !== undefined) {
    params += '&id_token_hint=' + storage.idToken;
  }

  const signOutUrl = signOutEndpoint + params;

  eventLog.log(`Sign out, start web auth flow, signOutUrl: ${signOutUrl}`);
  log(`Sign out, start web auth flow, signOutUrl: ${signOutUrl}`);
  chrome.identity.launchWebAuthFlow(
    {
      'url': signOutUrl,
      'interactive': false
    },
    async () => {
      /* jshint ignore:start */
      if (chrome.runtime.lastError) {
        // supressed, since logged out state is ensured by the cleanup
      }
      /* jshint ignore:end */
      if (manual === true) {
        await eventLog.log(`Sign out manually`);
        _signOutCleanup(true);
      } else {
        await eventLog.log(`Sign out automatically`);
        await _trackAction({ action: 'SysTriggeredBrowserExtensionSignedOut' });
        _signOutCleanup(false);
      }
    }
  );
}

function _signOutCleanup(clearLog = false) {
  // Reset the list of which entities user has full access to
  fullAccessList = {
    cve: false,
    ip: false,
    idn: false,
    hash: false,
    url: false
  };
  if (clearLog && !debugMode) {
    eventLog.clearLog();
  }
  chrome.storage.local.set({ currentLoggedOutNotificationId: undefined });
  chrome.storage.local.set({ activeDeviceToken: undefined });
  _clearAuthStorage().then(() => {
    updateContextMenus();
    _setExtensionIcon(ICONS.OFF);
    getEndpointsRequestCounter = 0;
    _endpoints = undefined;
    chrome.tabs.query({}, function (tabs) {
      if (tabs.length === 0) {
        return;
      }
      for (let tab of tabs) {
        _setBadgeText('', tab.id);
      }
    });
  });
}

function _saveToStorage(scope, idToken, ciphtertext, iv, accessToken) {
  chrome.storage.local.set({
    scope: scope,
    refreshToken: ciphtertext,
    idToken: idToken,
    accessToken: accessToken,
    iv: iv
  });

  updateContextMenus();
}

function _getScope(token) {
  const jwtToken = JSON.parse(atob(token.split('.')[1]));
  if (jwtToken.scope !== undefined) {
    return jwtToken.scope.split(' ');
  } else {
    return '';
  }
}

function _clearAuthStorage() {
  return new Promise((resolve) => {
    _token = undefined;
    chrome.storage.local.remove(['scope', 'idToken', 'refreshToken', 'iv', 'accessToken'], () => { resolve(); });
  });
}

async function _trackAction(trackOptions) {
  const url = 'https://api.recordedfuture.com/rfq/express/track/action';

  const storage = await getStorage();
  if (storage.accessToken) {
    _token = storage.accessToken;
  }
  if (_token !== undefined) {
    try {
      const requestOptions = {
        method: 'POST',
        headers: new Headers({
          'Authorization': 'Bearer ' + _token,
          'Content-Type': 'application/json',
          'User-Agent': 'RFChromeExtension/6.1.4'    // Updated by gulp task "version"!
        }),
        body: JSON.stringify(trackOptions)
      };
      const request = new Request(url, requestOptions);
      await fetch(request);
      return;
    } catch (err) {
      console.error('Problems when trying to track action', trackOptions);
      await eventLog.error(`ERROR 1484: ${JSON.stringify(err, null, 4)}`);
      await eventLog.addErrorCode(eventLog.ERROR_CODES.TRACK_ACTION_ERROR.id);
      // Just swallow the exception by returning
      return;
    }
  } else {
    return;
  }
}

/**
 * Helper to debounce calls to a method
 * @param func
 * @param wait
 * @param immediate
 * @private
 */
function _debounce(func, wait, immediate) {
  var context = this, args = arguments;
  var later = function () {
    _timeout = null;
    if (!immediate) {
      func.apply(context, args);
    }
  };
  var callNow = immediate && !_timeout;
  clearTimeout(_timeout);
  _timeout = setTimeout(later, wait);
  if (callNow) {
    func.apply(context, args);
  }
}
