import eventLog from './eventLogModule.js';

function getStorage() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['scope', 'idToken', 'updated', 'refreshToken', 'iv', 'accessToken'], items => {
      const storage = items || [];
      resolve(storage);
    });
  });
}

/**
 * When the popover is opened, check if signed in. If not, redirect to sign in page else try to get IOCs
 * from current page and start creating the popup content
 */
function onDOMContentLoaded() {
  const isFirefox = typeof InstallTrigger !== 'undefined';
  return new Promise((resolve) => {
    getStorage().then((storage) => {
      if (storage.updated) {
        resolve({});
      } else {
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
          if (tabs.length > 0) {
            const isPdf = tabs[0] && tabs[0].url && tabs[0].url.split('?')[0].toLowerCase().endsWith('.pdf');
            if (isPdf) {
              resolve('IS_PDF');
            } else {
              getToken(tabs[0].id, '001').then((token) => {
                if (token) {
                  chrome.tabs.sendMessage(tabs[0].id, { action: 'getEntities' }, msg => {
                    // For Firefox there is a problem with resolving the found entities to the popup script
                    // This happened after I made utils.getEntites a promise function that has to be chained
                    // The resolved message to popup will be undefined
                    // This is a workaround. Send the found entities to the background that then sends it to the popup
                    // Stupid solution but it works
                    // See RF-69195
                    if (isFirefox) {
                      chrome.runtime.sendMessage({ action: 'getEntitiesResponse', tabId: tabs[0].id, msg });
                      resolve({});
                    } else {
                      if (chrome.runtime.lastError) {
                        resolve({});
                      } else {
                        resolve(msg);
                      }
                    }
                  });
                } else {
                  // TODO: possibly remove entire else statement
                  refreshAuthTokens().then(res => {
                    if (res !== 'CANNOT_REFRESH') {
                      // Only attempt to get entities if the refresh auth tokens was successful
                      chrome.tabs.sendMessage(tabs[0].id, { action: 'getEntities' }, msg => {
                        if (chrome.runtime.lastError) {
                          resolve({});
                        } else {
                          resolve(msg);
                        }
                      });
                    } else {
                      resolve({});  
                    }
                  }).catch(() => {
                    resolve({});
                  });
                }
              });
            }
          }
        });
      }
    });
  });
}

function startAuthentication() {
  eventLog.log('startAuthentication 111')
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      chrome.runtime.sendMessage({ action: 'startAuthentication', tabId: tabs[0].id }, () => {
        resolve({});
      });
    });
  });
}

async function refreshAuthTokens() {
  const currrentToken = await getToken();
  if (!currrentToken) { // no token = user not logged in
    return 'CANNOT_REFRESH';
  }
  //eventLog.log('refreshAuthTokens 3454543');
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.runtime.sendMessage({ action: 'refreshAuthTokens', tabId: tabs[0].id });
    const onStorageUpdate = (changes, namespace) => {
      if (changes.refreshToken !== undefined && namespace === 'local') {
        removeStorageListener(onStorageUpdate);
        return changes.refreshToken.newValue;
      }
    };
    addStorageListener(onStorageUpdate);
  });
}

function getToken(tabId = null, source = '') {
  return new Promise(resolve => {
    getStorage().then(storage => {
      if (storage.accessToken) {
        resolve(storage.accessToken);
      } else {
        chrome.runtime.sendMessage({ action: 'getToken', tabId }, token => {
          eventLog.log(`token received: ${token}`);
          resolve(token);
        });
      }
    })
  });
}

function signOut(manual = true) {
  eventLog.error(`Sign out of extension...`);
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    eventLog.error(`Signout info: Manual: ${manual}`);
    chrome.runtime.sendMessage({ action: 'signOut', manual: manual, tabId: tabs[0].id });
    if (manual === true) {
      setTimeout(() => {
        window.close();
      }, 400);
    }
  });
}

function reloadCurrentPage(hardReload = false) {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const host = new URL(tabs[0].url).hostname;

    if (hardReload || host === 'app.recordedfuture.com' || host.includes('google.com')) {
      chrome.tabs.reload(tabs[0].id);
    } else {
      chrome.tabs.update(tabs[0].id, { url: tabs[0].url });
    }
    window.close();
  });
}

function sandboxLink() {
  window.open('https://sandbox.recordedfuture.com/reports/owned');
}

function redirectLink() {
  window.open('https://www.recordedfuture.com/products/browser-extension/');
}

function termOfUseLink() {
  window.open('https://www.recordedfuture.com/terms-of-use/');
}

function localFileReadingInstructionsLink() {
  window.open('https://support.recordedfuture.com/hc/en-us/articles/4404346693907');
}

function addStorageListener(func) {
  chrome.storage.onChanged.addListener(func);
}

function removeStorageListener(func) {
  chrome.storage.onChanged.removeListener(func);
}

export default {
  getStorage,
  onDOMContentLoaded,
  startAuthentication,
  reloadCurrentPage,
  sandboxLink,
  redirectLink,
  termOfUseLink,
  localFileReadingInstructionsLink,
  signOut,
  refreshAuthTokens,
  addStorageListener,
  removeStorageListener,
  getToken
};