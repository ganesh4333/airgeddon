export default {
    MAX_AMOUNT_OF_ENTITIES: 1000, // If the amount of entities is above this number the extension will not work at all. User will have to manually choose to load entities
    MAX_AMOUNT_OF_ENTITIES_FOR_HIGHLIGHTING: 400, // This is the max amount of entities to highlight on-page
    MAX_AMOUNT_OF_ENTITIES_FOR_EXPORT: 300,
    MAX_AMOUNT_OF_URLS_FOR_SANDBOX: 8
};