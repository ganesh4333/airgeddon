(async () => {
  /* const tess = chrome.runtime.getURL('./scripts/tesseract.min.js');
  await import(tess); */

  const pdfjs = chrome.runtime.getURL('./scripts/pdfjs.js');
  await import(pdfjs);

  const src = chrome.runtime.getURL('./scripts/contentScriptModule.js');
  const contentMain = await import(src);
  contentMain.default.main();
})();