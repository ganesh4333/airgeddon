import config from "./configModule.js";
import utils from "./utilsModule.js";
import highlight from "./highlightModule.js";
import userSettings from "./userSettingsModule.js";
import regExpUtilModule from "./regExpUtilModule.js";

import helpers from "./helpers.js";

const main = () => {
  const versionBox = document.getElementById(
    "RecordedFutureBrowserExtension-version-number"
  );
  if (versionBox) {
    versionBox.innerText = "RFChromeExtension/6.1.4";
  }
  const usageTimestampBox = document.getElementById(
    "RecordedFutureBrowserExtension-last-usage-timestamp"
  );
  if (usageTimestampBox) {
    chrome.storage.local.get(["lastUsage"], (items) => {
      const lastUsage = items.lastUsage;
      usageTimestampBox.innerText = lastUsage;
    });
  }

  /* const injectTesseract = () => {
    // Inject tesseract
    if (!document.getElementById('injectedTess')) {
      const tesseractSrc = chrome.runtime.getURL('./scripts/tesseract.min.js');
      const script = document.createElement('script');
      script.setAttribute('src', tesseractSrc);
      script.setAttribute('type', 'text/javascript');
      //script.innerHTML = tess;
      script.id = 'injectedTess';
      document.querySelector('head').appendChild(script);


      const script3 = document.createElement('script');
      script3.setAttribute('type', 'text/javascript');
      script3.innerHTML = `
        window.tesseractWorkerSrc = '${chrome.runtime.getURL('./scripts/tesseractworker.min.js')}';
        window.tesseractCoreSrc = '${chrome.runtime.getURL('./scripts/tesseract-core.js')}';
      `;
      document.querySelector('head').appendChild(script3);      
      
      const canvasReaderSrc = chrome.runtime.getURL('./scripts/canvasReader.js');
      const script2 = document.createElement('script');
      script2.setAttribute('src', canvasReaderSrc);
      script2.setAttribute('type', 'text/javascript');
      script2.id = 'injectedTess2';
      document.querySelector('head').appendChild(script2);
    }
  } */

  //injectTesseract();
  let bkgPort;

  const createBkgPort = () => {
    bkgPort = chrome.runtime.connect({ name: "port-bkg-cs" });
    bkgPort.onDisconnect.addListener(() => {
      bkgPort = null;
    });
  };

  const sendBkgPortMessage = (msg) => {
    if (!bkgPort) {
      createBkgPort();
    }
    bkgPort.postMessage(msg);
  };

  createBkgPort();
  sendBkgPortMessage({ triggerNotification: true });

  let siteIsBlacklisted = false;
  const iframeDomain = utils.iframeDomain();

  let lastHighlightedEntities;
  let highlightIocsTimestamp;

  userSettings.getUserSettings().then((settings) => {
    const url = new URL(window.location.href);
    const host = url.hostname;
    siteIsBlacklisted =
      settings &&
      settings.userCustomBlacklist &&
      settings.userCustomBlacklist.some((url) =>
        host.match(new RegExp(url, "g"))
      );

    if (!siteIsBlacklisted) {
      setupContentObservers();
    }

    const isFirefox = typeof InstallTrigger !== "undefined";
    if (isFirefox) {
      browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
        messageListener(request, sender, sendResponse, siteIsBlacklisted);
      });
    } else {
      chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        messageListener(request, sender, sendResponse, siteIsBlacklisted);
      });
    }
  });

  async function messageListener(
    request,
    sender,
    sendResponse,
    siteIsBlacklisted
  ) {
    let response;
    if (!siteIsBlacklisted) {
      if (request.action === "hideNotificationBox") {
        let box = document.getElementById(
          "rfBrowextTooManyEntitiesNotificationBox"
        );
        if (box) {
          box.style.opacity = "0";
          setTimeout(() => {
            if (box) {
              box.remove();
            }
          }, 1000);
        }
      } else if (request.action === "updateEntityOptions") {
        updateEntityOptions(request);
        sendResponse(response);
        return true;
      } else if (request.action === "getLinkUrls") {
        const links = regExpUtilModule.getAllLinkUrls(document.body);
        sendResponse(links);
        return true;
      } else if (request.action === "getPdfTextContent") {
        const text = await helpers.getPdfTextContent(window.location.href);
        setTimeout(() => {
          sendBkgPortMessage({ pdfTextContent: text });
        }, 10);
        sendResponse();
        return true;
      } else if (request.action === "getEntities") {
        utils.getEntities().then((entities) => {
          let iocsSimplified = entities.matches.reduce(
            (total, current) => [...total, ...current.iocs],
            []
          );

          if (iocsSimplified.length > config.MAX_AMOUNT_OF_ENTITIES) {
            response = { iocsResult: entities };
            // If Firefox, then let eventPage know there are too many entities
            if (typeof InstallTrigger !== "undefined") {
              sendBkgPortMessage({
                tooManyEntities: true,
                entities: entities,
                url: window.location.href,
              });
            }
            sendResponse(response);
            return true;
          }

          const iocsNames = iocsSimplified.map((x) => x.name);
          const previosIocsNames = lastHighlightedEntities
            ? lastHighlightedEntities.map((x) => x.name)
            : [];
          const identical =
            iocsNames.length === previosIocsNames.length &&
            previosIocsNames.every((x) => iocsNames.includes(x));

          const timestamp = Date.now();
          const diff = highlightIocsTimestamp
            ? timestamp - highlightIocsTimestamp
            : null;

          if (identical && diff && diff < 1200) {
            // Do not update if the IoCs fetched haven't changed and it has been less than 1200 ms since last getEntities event
            response = { iocsResult: entities };
            sendBkgPortMessage({ refreshBadge: true, entities: entities });
          } else {
            lastHighlightedEntities = iocsSimplified;
            highlightIocsTimestamp = Date.now();

            const usesIframes = iframeDomain;
            if (request.userLoggedIn) {
              const urls = entities.matches.find((x) => x.type === "urls");
              if (urls && urls.iocs.length > 0) {
                // Check if there are URLs fetched, if so highlight them
                highlight.highlightUrls(
                  entities.matches.find((x) => x.type === "urls")
                );
              }
              if (!iocsSimplified.every((x) => x.fromLink)) {
                // Do not try to highlight IoCs if all IoCs fetched are from link elements
                if (
                  iocsSimplified.length <=
                  config.MAX_AMOUNT_OF_ENTITIES_FOR_HIGHLIGHTING
                ) {
                  highlight.highlightIocs(
                    entities,
                    usesIframes,
                    request.pageUrl
                  );
                } else {
                  highlight.cacheIocs(entities);
                }
              }
            }
            response = { iocsResult: entities };
            sendBkgPortMessage({ refreshBadge: true, entities: entities });
          }
          sendResponse(response);
          return true;
        });
      } else if (request.action === "userLoggedOut") {
        highlight.removeHighlightBoxes();
        highlight.removeUrlHighlightBoxes();
        highlight.removeHighlightStyling();
        response = {};
        sendResponse(response);
        return true;
      } else if (request.action === "getNumberOfIframeIocsInTab") {
        utils.getNumberOfIframeIocsInTab().then((res) => {
          response = { numberOfIframeIocs: res };
          sendResponse(response);
          return true;
        });
      }
    } else {
      sendBkgPortMessage({ scanDisabled: true, siteIsBlacklisted });
      response = { scanDisabled: true };
      sendResponse(response);
      return true;
    }
  }

  ////////////////////////////////////////////////////////////////////////////

  function updateEntityOptions(request) {
    setTimeout(() => {
      userSettings.getEntityTypesToShow().then((entityTypesToShow) => {
        utils.getEntities(entityTypesToShow).then((entities) => {
          highlight.highlightUrls(
            entities.matches.find((x) => x.type === "urls")
          );
          highlight.highlightIocs(entities, true, request.pageUrl);
          sendBkgPortMessage({
            refreshBadge: true,
            entities: entities,
            forcePopupRedraw: true,
          });
        });
      });
    }, 50);
  }

  /* const throttle = (func, limit) => {
    let lastFunc
    let lastRan
    return function() {
      const context = this
      const args = arguments
      if (!lastRan) {
        func.apply(context, args)
        lastRan = Date.now()
      } else {
        clearTimeout(lastFunc)
        lastFunc = setTimeout(function() {
          if ((Date.now() - lastRan) >= limit) {
            func.apply(context, args)
            lastRan = Date.now()
          }
        }, limit - (Date.now() - lastRan))
      }
    }
  } */

  function setupContentObservers() {
    if (!siteIsBlacklisted) {
      let docBody = document.body;

      let canvasObserver = new MutationObserver(function (
        mutationsList,
        observer
      ) {
        const doUpdate =
          [...mutationsList].filter((x) => x.target.nodeName === "CANVAS")
            .length > 0;
        if (doUpdate) {
          //console.log('doUpdate', doUpdate, mutationsList);
          console.log(
            "Canvas observer triggered, proceed read canvas elements"
          );
          //injectTesseract();
          //utils.readAllCanvasTexts();
        }
      });

      let docObserver = new MutationObserver(function (
        mutationsList,
        observer
      ) {
        // Get all elements that were either added or removed to trigger observer
        const allAddedOrRemovedElements = mutationsList.reduce(
          (total, current) => [
            ...total,
            ...current.addedNodes,
            ...current.removedNodes,
          ],
          []
        );
        // If all of them are caused by the extension highlighting then do not update anything
        // or try to fetch IoCs
        const doNotUpdate = allAddedOrRemovedElements.every((x) => {
          const classList = x.classList;
          return (
            x.id === "customRfStyling" ||
            x.innerHTML === null ||
            x.innerHTML === undefined ||
            x.innerText === "" ||
            (classList && classList.contains("rfBrowextIocHighlightLink")) ||
            (classList &&
              classList.contains("rfBrowextIocHighlightLink__image")) ||
            (classList &&
              classList.contains("rfBrowextIocHighlightLink__title")) ||
            (classList &&
              classList.contains("rfBrowextIocHighlightLink__riskplupp")) ||
            (classList &&
              classList.contains("rfBrowextIocHighlightLink__tooltip")) ||
            (classList &&
              classList.contains("rfBrowextIocHighlightLink__risk")) ||
            (classList && classList.contains("rfBrowextUrlHighlightLink")) ||
            (classList &&
              classList.contains("rfBrowextUrlHighlightLink__image")) ||
            (classList &&
              classList.contains("rfBrowextUrlHighlightLink__title")) ||
            (classList &&
              classList.contains("rfBrowextUrlHighlightLink__riskplupp")) ||
            (classList &&
              classList.contains("rfBrowextUrlHighlightLink__tooltip")) ||
            (classList &&
              classList.contains("rfBrowextUrlHighlightLink__risk")) ||
            (classList &&
              classList.contains("rfBrowextUrlHighlightLink__disabledIcon")) ||
            (classList &&
              classList.contains(
                "rfBrowextUrlHighlightLink__riskScoreWrapper"
              )) ||
            (classList && classList.contains("rfHighlightForeignObject")) ||
            (x.nodeName && x.nodeName.toLowerCase() === "script") ||
            (x.nodeName && x.nodeName.toLowerCase() === "noscript") ||
            (x.nodeName && x.nodeName.toLowerCase() === "style") ||
            (x.nodeName && x.nodeName.toLowerCase() === "img") ||
            (x.nodeName && x.nodeName.toLowerCase() === "input") ||
            (x.nodeName && x.nodeName.toLowerCase() === "video") ||
            (x.nodeName && x.nodeName.toLowerCase() === "button") ||
            (x.nodeName && x.nodeName.toLowerCase() === "code") ||
            (x.nodeName && x.nodeName.toLowerCase() === "head") ||
            (x.nodeName && x.nodeName.toLowerCase() === "title") ||
            (x.nodeName && x.nodeName.toLowerCase() === "meta") ||
            (x.nodeName && x.nodeName.toLowerCase() === "textarea") ||
            (x.nodeName && x.nodeName.toLowerCase() === "link") ||
            (x.nodeName && x.nodeName.toLowerCase() === "style")
          );
        });

        if (!doNotUpdate) {
          // This setTimeout is need to Fix an issue where extension tries to get entities before page is fully loaded
          // which results in that not all actual enitities are found at first. See RF-65616
          setTimeout(() => {
            utils.getEntities().then((iocs) => {
              utils
                .getNumberOfIocs(docBody, "document")
                .then((numberOfIocs) => {
                  if (numberOfIocs < config.MAX_AMOUNT_OF_ENTITIES) {
                    const iocNames = iocs.matches
                      .reduce((total, current) => {
                        total = [...total, ...current.iocs];
                        return total;
                      }, [])
                      .map((x) => x.name);
                    const currentIocList = document.currentIocList || [];
                    const updated = !arraysEqual(currentIocList, iocNames);

                    if (updated) {
                      document.currentIocList = iocNames;
                      if (bkgPort !== null) {
                        sendBkgPortMessage({
                          numberOfIocs: numberOfIocs,
                          iocs: iocs,
                          iframeDomain: iframeDomain,
                        });
                      }
                    }
                  }
                });
            });
          }, 400);
        }
      });
      docObserver.observe(docBody, { childList: true, subtree: true });
      //canvasObserver.observe(docBody, { childList: true, subtree: true, attributes: true });
      if (iframeDomain) {
        let bodyObserver;
        let bodyObserverCallback = () => {
          if (getAllIframes().length) {
            // Iframes found, we can assume body has finished loading
            // Now attach observers to iframes
            // Also disconncet this body observer
            bodyObserver.disconnect();
            let iframes = getAllIframes();
            for (let iframe of iframes) {
              addContentObserverToIframe(iframe, iframeDomain);
            }
          }
        };
        // Observe changes on the DOM body to check for when iframes are present in the DOM tree
        // Only when finding these do we add iframe observers
        bodyObserver = new MutationObserver(bodyObserverCallback);
        bodyObserver.observe(document.querySelector("body"), {
          attributes: true,
          childList: true,
          subtree: true,
        });
      }
    } else if (bkgPort !== null) {
      sendBkgPortMessage({ scanDisabled: true, siteIsBlacklisted });
    }
  }

  const getAllIframes = () => {
    const iframes = document.getElementsByTagName("iframe");
    const getIframesInsideShadowDoms = (root) => {
      let list = [];
      [...root.querySelectorAll("*")].forEach((x) => {
        if (x.shadowRoot) {
          list = [
            ...list,
            ...[...x.shadowRoot.querySelectorAll("iframe")],
            ...[...getIframesInsideShadowDoms(x.shadowRoot)],
          ];
        }
      });
      return list;
    };
    const iframesInShadowDoms = getIframesInsideShadowDoms(document);
    return [...iframes, ...iframesInShadowDoms];
  };

  async function addContentObserverToIframe(iframe, iframeDomain) {
    if (!siteIsBlacklisted) {
      const iframeObserver = new MutationObserver(async (mutationsList) => {
        // Get all elements that were either added or removed to trigger observer
        const allAddedOrRemovedElements = mutationsList.reduce(
          (total, current) => [
            ...total,
            ...current.addedNodes,
            ...current.removedNodes,
          ],
          []
        );
        const doNotUpdate = allAddedOrRemovedElements.every((x) => {
          const classList = x.classList;
          return (
            x.id === "customRfStyling" ||
            x.innerHTML === null ||
            x.innerHTML === undefined ||
            x.innerText === "" ||
            (classList && classList.contains("rfBrowextIocHighlightLink")) ||
            (classList &&
              classList.contains("rfBrowextIocHighlightLink__image")) ||
            (classList &&
              classList.contains("rfBrowextIocHighlightLink__title")) ||
            (classList &&
              classList.contains("rfBrowextIocHighlightLink__riskplupp")) ||
            (classList &&
              classList.contains("rfBrowextIocHighlightLink__tooltip")) ||
            (classList &&
              classList.contains("rfBrowextIocHighlightLink__risk")) ||
            (classList && classList.contains("rfBrowextUrlHighlightLink")) ||
            (classList &&
              classList.contains("rfBrowextUrlHighlightLink__image")) ||
            (classList &&
              classList.contains("rfBrowextUrlHighlightLink__title")) ||
            (classList &&
              classList.contains("rfBrowextUrlHighlightLink__riskplupp")) ||
            (classList &&
              classList.contains("rfBrowextUrlHighlightLink__tooltip")) ||
            (classList &&
              classList.contains("rfBrowextUrlHighlightLink__risk")) ||
            (classList &&
              classList.contains("rfBrowextUrlHighlightLink__disabledIcon")) ||
            (classList &&
              classList.contains(
                "rfBrowextUrlHighlightLink__riskScoreWrapper"
              )) ||
            (classList && classList.contains("rfHighlightForeignObject")) ||
            (x.nodeName && x.nodeName.toLowerCase() === "script") ||
            (x.nodeName && x.nodeName.toLowerCase() === "noscript") ||
            (x.nodeName && x.nodeName.toLowerCase() === "style") ||
            (x.nodeName && x.nodeName.toLowerCase() === "img") ||
            (x.nodeName && x.nodeName.toLowerCase() === "input") ||
            (x.nodeName && x.nodeName.toLowerCase() === "video") ||
            (x.nodeName && x.nodeName.toLowerCase() === "button") ||
            (x.nodeName && x.nodeName.toLowerCase() === "code") ||
            (x.nodeName && x.nodeName.toLowerCase() === "head") ||
            (x.nodeName && x.nodeName.toLowerCase() === "title") ||
            (x.nodeName && x.nodeName.toLowerCase() === "meta") ||
            (x.nodeName && x.nodeName.toLowerCase() === "textarea") ||
            (x.nodeName && x.nodeName.toLowerCase() === "link") ||
            (x.nodeName && x.nodeName.toLowerCase() === "style")
          );
        });

        if (!doNotUpdate) {
          let iocs = await utils.getEntities();
          const iocNames =
            iocs && iocs.matches
              ? iocs.matches
                  .reduce((total, current) => {
                    total = [...total, ...current.iocs];
                    return total;
                  }, [])
                  .map((x) => x.name)
              : [];
          const updated = !arraysEqual(iframe.currentIocList, iocNames);
          if (updated) {
            iframe.currentIocList = iocNames;
            highlight.highlightIocs(iocs, true);
            let iframeIocs = await utils.getNumberOfIframeIocsInTab();
            if (iframeIocs !== undefined && bkgPort !== null) {
              sendBkgPortMessage({
                iframeIocs: iframeIocs,
                iframeDomain: iframeDomain,
                iocs: iocs,
              });
            }
          }
          const urls = iocs.matches.find((x) => x.type === "urls")
            ? iocs.matches.find((x) => x.type === "urls").iocs
            : [];
          const urlsUpdated =
            iframe.currenUrlList &&
            !arraysEqual(
              iframe.currenUrlList.map((x) => x.name.toLowerCase()),
              urls.map((x) => x.name.toLowerCase())
            );
          if (urlsUpdated) {
            iframe.currenUrlList = urls;
            highlight.highlightUrls(urls);
            let iframeIocs = await utils.getNumberOfIframeIocsInTab();
            if (iframeIocs !== undefined && bkgPort !== null) {
              sendBkgPortMessage({
                iframeIocs: iframeIocs,
                iframeDomain: iframeDomain,
                iocs: iocs,
              });
            }
          }
        }
      });
      iframe.addEventListener("load", () => {
        if (iframe.contentDocument !== null) {
          iframeObserver.observe(iframe.contentDocument.body, {
            childList: true,
            subtree: true,
            attributes: true,
          });
        }
      });
    } else if (bkgPort !== null) {
      sendBkgPortMessage({ scanDisabled: true, siteIsBlacklisted });
    }
  }

  function arraysEqual(a, b) {
    return (
      a &&
      b &&
      a.length === b.length &&
      a.every((x) => b.includes(x)) &&
      b.every((x) => a.includes(x))
    );
  }
};

export default {
  main,
};
