const LOG_MAX_SIZE = 3000;

const LOCAL_STORAGE_KEY = 'RFBrowserExtensionEventLog';

const EVENT_TYPES = {
  LOG_MESSAGE: 'logMessage',
  LOG_ERROR: 'logError'
};

const ERROR_CODES = {
  GET_ENCRYPTION_TOKEN_ERROR: { id: 111, name: 'Get encryption token throw error' },
  GET_ENCRYPTION_TOKEN_ERROR2: { id: 112, name: 'Get encryption token fail on retry' },
  CREATE_ENCRYPTION_KEY_ERROR: { id: 113, name: 'Error thrown when trying to create encryption key' },
  CREATE_ENCRYPTION_KEY_ERROR2: { id: 114, name: 'Error thrown when trying to create encryption key on retry' },
  ENCRYPT_TOKEN_ERROR: { id: 115, name: 'Error thrown when trying to encrypt token' },
  ENCRYPT_TOKEN_ERROR2: { id: 116, name: 'Error thrown when trying to encrypt token on retry' },
  DECRYPT_TOKEN_ERROR: { id: 117, name: 'Error thrown when trying to decrypt token' },
  DECRYPT_TOKEN_ERROR2: { id: 118, name: 'Error thrown when trying to decrypt token on retry' },
  TRACK_ACTION_ERROR: { id: 119, name: 'Track action error' },
  CREATE_LIST_ERROR: { id: 211, name: 'Create list throw error' },
  CREATE_LIST_ERROR2: { id: 212, name: 'Create list throw error 2' },
  START_AUTHENTICATION_THROW_ERROR: { id: 301, name: 'Start authentication throw error' },
  ENRICHMENT_THROW_ERROR: { id: 401, name: 'Error when trying to call enrichment' },
  ENRICHMENT_THROW_ERROR2: { id: 402, name: 'Error when trying to call enrichment 2' },
  PROCESS_ENRICHMENT_RESPONSE: { id: 403, name: 'Error when trying to call process enrichment response' },
  ERROR_ON_REFRESH_AUTH_TOKEN_AND_THEN_TRY_TO_ENRICH_AGAIN: { id: 501, name: 'Error when failing to enrich, then trying to refresh auth token and enrich again' },
  REFRESH_AUTH_TOKEN1: { id: 601, name: 'Refresh auth token error 1' },
  REFRESH_AUTH_TOKEN2: { id: 602, name: 'Refresh auth token error 2' },
  REFRESH_AUTH_TOKEN3: { id: 603, name: 'Refresh auth token error 3' },
  REFRESH_AUTH_TOKEN4: { id: 604, name: 'Refresh auth token error 4' },
  REFRESH_AUTH_TOKEN5: { id: 605, name: 'Refresh auth token error 5' },
};

const addErrorCode = async (errorCode) => {
  try {
    chrome.storage.local.get(['RFBrowserExtensionErrorCodeLog'], items => {
      let currentLog = items['RFBrowserExtensionErrorCodeLog'] || [];
      // Insert new log message
      currentLog.push({
        errorCode,
        timestamp: Date.now(),
        readableTimestamp: new Date().toString()
      });
      // Limit the event log so it doesn't get too big
      currentLog = currentLog.slice(200 * -1);
      let newLog = {};
      newLog['RFBrowserExtensionErrorCodeLog'] = currentLog;
      chrome.storage.local.set(newLog, () => {
        return;
      });
    });
  } catch (errr) {
    // do nothing, just swallow, so that nothing fails just because it coulnd't log error code
    console.warn('Problem when logging error code')
    return;
  }
};

const _writeToLog = async (message, type) => {
  try {
    chrome.storage.local.get([LOCAL_STORAGE_KEY], items => {
      let currentLog = items[LOCAL_STORAGE_KEY] || [];
  
      // Insert new log message
      currentLog.push({
        type,
        message,
        timestamp: Date.now(),
        readableTimestamp: new Date().toString()
      });
      // Limit the event log so it doesn't get too big
      currentLog = currentLog.slice(LOG_MAX_SIZE * -1);
      
      let newLog = {};
      newLog[LOCAL_STORAGE_KEY] = currentLog;
      chrome.storage.local.set(newLog, () => {
        return;
      });
    });
  } catch (errr) {
    console.error(errr);
    return;
  }
};

const log = message => {
  return _writeToLog(message, EVENT_TYPES.LOG_MESSAGE);
};

const error = message => {
  return _writeToLog(message, EVENT_TYPES.LOG_ERROR);
};

const clearLog = () => new Promise((resolve) => {
  let newLog = {};
  newLog[LOCAL_STORAGE_KEY] = [];
  chrome.storage.local.set(newLog, () => {
    resolve();
  });
})

const getSimplifiedErrorCodeLog = async () => {
  try {
    chrome.storage.local.get(['RFBrowserExtensionErrorCodeLog'], items => {
      const currentLog = items['RFBrowserExtensionErrorCodeLog'];
      if (currentLog && currentLog.length > 0) {
        currentLog.sort((a, b) => a.timestamp - b.timestamp);
  
        const simplifiedLog = currentLog.map(x => x.errorCode);
        const asString = simplifiedLog.join(',');
  
        return asString;
      } else {
        console.log('No error code log found');
        return '';
      }
    });
  } catch (err) {
    // do nothing
    return '';
  }
};

const printErrorCodes = () => {
  chrome.storage.local.get(['RFBrowserExtensionErrorCodeLog'], items => {
    const currentLog = items['RFBrowserExtensionErrorCodeLog'];
    if (currentLog && currentLog.length > 0) {
      currentLog.sort((a, b) => a.timestamp - b.timestamp);
      currentLog.forEach(x => {
        const error = Object.values(ERROR_CODES).find(z => z.id === x.errorCode);
        if (error) {
          console.log(`%c${x.readableTimestamp}: %c${error.name}`, 'font-weight: bold;', 'font-weight: normal;');
        }
      });
    } else {
      console.log('No error code log found');
    }
  });
};

const printLog = () => {
  chrome.storage.local.get([LOCAL_STORAGE_KEY], items => {
    const currentLog = items[LOCAL_STORAGE_KEY];
    if (currentLog && currentLog.length > 0) {
      currentLog.sort((a, b) => a.timestamp - b.timestamp);
      currentLog.forEach(x => {
        if (x.type === EVENT_TYPES.LOG_ERROR) {
          console.log(`%c${x.readableTimestamp}: %c${x.message}`, 'color: red; font-weight: bold;', 'color: red;');
        } else {
          console.log(`%c${x.readableTimestamp}: %c${x.message}`, 'font-weight: bold;', 'font-weight: normal;');
        }
      });
    } else {
      console.log('No event log found');
    }
  });
};

const printLogAsString = () => {
  chrome.storage.local.get([LOCAL_STORAGE_KEY], items => {
    const currentLog = items[LOCAL_STORAGE_KEY];
    if (currentLog && currentLog.length > 0) {
      console.log(JSON.stringify(currentLog));
    } else {
      console.log('No event log found');
    }
  });
};

// Expose logging functions so that user can view log in console
/* if (window) {
  window.printLog = _printLog;
  window.printLogAsString = _printLogAsString;
} */

export default {
  addErrorCode,
  ERROR_CODES,
  getSimplifiedErrorCodeLog,
  log,
  error,
  clearLog,
  printLog,
  printLogAsString,
  printErrorCodes
};