import eventLog from './eventLogModule.js';

const submitGraphQLRequest = (token, query) => new Promise(resolve => {
  const url = 'https://api.recordedfuture.com/graphql';
  const headers = new Headers({
    'Authorization': 'Bearer ' + token,
    'Content-Type': 'application/javascript',
    'x-rf-user-agent': 'RFChromeExtension/6.1.4'    // Updated by gulp task "version"!
  });
  const requestOptions = {
    method: 'POST',
    headers: headers,
    body: JSON.stringify({
      query
    })
  };

  fetch(url, requestOptions)
    .then(response => response.json())
    .then(result => {
      resolve(result);
    })
    .catch(error => {
      console.log('GraphQLAPI request failed');
      console.log(`Query: ${query}`);
      console.log(error);

      eventLog.log(`
        GraphQL API request failed
        ${JSON.stringify(error, null, 4)}

        Query:
        ${query}
      `);
    });
})

export default {
  submitGraphQLRequest
};