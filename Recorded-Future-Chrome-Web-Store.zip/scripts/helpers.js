import userSettings from './userSettingsModule.js';

const delay = ms => new Promise((resolve) => {
    setTimeout(resolve, ms);
});

const getStackTrace = () => {
    var err = new Error();
    return err.stack;
}

const domainsAreSame = (domain1, domain2) => {
    if (domain1 === domain2) return true;

    [domain1, domain2].forEach(d => d = d.replace('wwww.', ''));

    const domain1Parts = domain1.split('.');
    const domain2Parts = domain2.split('.');
    const length = domain1Parts.length < domain2Parts.length ? domain1Parts.length : domain2Parts.length

    const domain1trunked = domain1Parts.slice(domain1Parts.length - length, domain1Parts.length + length);
    const domain2trunked = domain2Parts.slice(domain2Parts.length - length, domain2Parts.length + length);

    return domain1trunked.join('.') === domain2trunked.join('.');
}

const onlyUnique = (value, index, self) => self.indexOf(value) === index;

const getPdfTextContent = (pdfUrl) => {
    return new Promise((resolve) => {
        pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('./scripts/pdfjsworker.js');

        var loadingTask = pdfjsLib.getDocument(pdfUrl);
        loadingTask.promise.then(pdf => {
            var maxPages = pdf._pdfInfo.numPages;
            var countPromises = []; // collecting all page promises
            let totalText = '';
            for (var j = 1; j <= maxPages; j++) {
                const promise = new Promise((resolve) => {
                    pdf.getPage(j).then((page) => { // add page promise
                        page.getTextContent().then(text => {
                            let pageText = '';
                            text.items.forEach(t => {
                                pageText += t.str;
                                if (t.hasEOL) {
                                    pageText += ' ';
                                }
                            });
                            totalText += pageText
                            resolve();
                        });
                    })
                })
                countPromises.push(promise);
            }
            // Wait for all pages and join text
            Promise.all(countPromises).then(() => {
                resolve(totalText);
            });
        });
    });
}

async function getUrlRedirectFromCache(originalUrl) {
    try {
      let currentCache = await userSettings.getSettingFromStorageByName('RFBrowserExtensionRedirectCache');
      if (!currentCache) {
        return null;
      }
  
      if (currentCache && currentCache.find(x => x.originalUrl === originalUrl)) { // Item already in cache
        const item = currentCache.find(x => x.originalUrl === originalUrl);
        const now = Date.now();
        const diff = now - item.timestamp;
  
        if (diff <= (1000 * 60 * 60 * 2)) { // If cached item is not older than 2 hours, use item from cache
          return item;
        } else {
          return null;
        }
      } else {
        return null;
      }
    } catch (errr) {
      console.warn('Problem when trying to fetch redirect url from cache', errr);
      return null;
    }
  }
  
  async function addUrlRedirectToCache(originalUrl, redirectToUrl) {
    try {
      chrome.storage.local.get(['RFBrowserExtensionRedirectCache'], items => {
        let currentCache = items['RFBrowserExtensionRedirectCache'] || [];
        
        if (
          currentCache.find(x => x.originalUrl === originalUrl) &&
          currentCache.find(x => x.originalUrl === originalUrl).redirectToUrl &&
          !redirectToUrl
        ) {
          // Existing item in cache has a redirect url, but the new item of the same from-URL has no redirect-URL
          // in which case, skip
          return;
        } else {
          // if old item exists, remove it from cache
          currentCache = currentCache.filter(x => x.originalUrl !== originalUrl);
          currentCache.push({
            originalUrl,
            redirectToUrl,
            timestamp: Date.now()
          });
          // Limit the event log so it doesn't get too big
          currentCache = currentCache.slice(600 * -1);
          let newCache = {};
          newCache['RFBrowserExtensionRedirectCache'] = currentCache;
          chrome.storage.local.set(newCache, () => {
            return;
          });
        }
      });
    } catch (errr) {
      // do nothing, just swallow, so that nothing fails just because it coulnd't log error code
      console.warn('Problem when trying to add redirect url to cache');
      return;
    }
  }

export default {
    delay,
    domainsAreSame,
    onlyUnique,
    getPdfTextContent,
    getStackTrace,
    addUrlRedirectToCache,
    getUrlRedirectFromCache
};