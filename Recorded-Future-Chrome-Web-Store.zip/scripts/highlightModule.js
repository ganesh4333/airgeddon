import utils from "./utilsModule.js";
import userSettings from "./userSettingsModule.js";
import regExpUtil from "./regExpUtilModule.js";
import config from "./configModule.js";

let minimumCriticality = 0;
userSettings.getUserSettings().then((settings) => {
  minimumCriticality =
    settings.highlightingMinimumCriticality !== null
      ? settings.highlightingMinimumCriticality
      : 2;
});

let freemiumAccount = false;
let fetchIocsInProgress = false;
let highlightingInProgress = false;
let fetchedIocRiskScoresTimestamp;
let highlightIocsTimestamp;
let lastFetchedIocs;
let lastHighlightedEntities;

// Override cache is used to remember if the current page is already approved by the user
// to enable highlighting even if it exceeds the max limit
let overrideCache = [];

let riskScoreCache;

const iframeDomain = utils.iframeDomain();

// The value of the constant rfCss will be replaced by the contents of the highlight.css file
// for the output of this file. This is done via a Gulp task.  \"\\25cf\"
const rfCss = `@font-face {
  font-family: "Inter var";
  src: local("chrome-extension://__MSG_@@extension_id__/fonts/Inter.var.woff2") format("woff"), src("chrome-extension://__MSG_@@extension_id__/fonts/Inter.var.woff2") format("woff");
  font-style: normal;
}
.rfHighlightForeignObject .rfBrowextIocHighlightLink {
  display: none;
  position: relative;
}
.rfHighlightForeignObject .rfBrowextIocHighlightLink.rfBrowextIocHighlightLink-highlighted {
  display: inline-block;
}
.rfBrowextUrlHighlightLink__tooltip,
.rfBrowextIocHighlightLink__tooltip {
  background: transparent;
  filter: drop-shadow(rgba(0, 0, 0, 0.3) 0 0 8px);
  position: fixed;
  z-index: 9999999999999;
  visibility: hidden;
}
.rfBrowextUrlHighlightLink__tooltip__inner,
.rfBrowextIocHighlightLink__tooltip__inner {
  clip-path: polygon(0 0, 100% 0, 100% 95%, 54% 95%, 50% 100%, 46% 95%, 0 95%);
  float: left;
  padding: 14px;
  font-family: "Inter var", "Helvetica Neue", Helvetica, Arial, sans-serif;
  background: white;
  width: auto;
  min-width: 310px;
  max-width: 550px;
  color: black;
  cursor: default;
  margin: 0 !important;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipSuspectedMaliciousLinkTitle,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipSuspectedMaliciousLinkTitle {
  margin-bottom: 12px;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipSuspectedMaliciousLinkTitle .image,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipSuspectedMaliciousLinkTitle .image {
  width: 13px;
  float: left;
  height: 13px;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipSuspectedMaliciousLinkTitle .image svg,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipSuspectedMaliciousLinkTitle .image svg {
  fill: #ffce00;
  width: 13px;
  top: -4px;
  position: relative;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipSuspectedMaliciousLinkTitle .title,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipSuspectedMaliciousLinkTitle .title {
  font-size: 13px;
  line-height: 16px;
  font-weight: 600;
  float: left;
  margin-left: 6px;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipSuspectedMaliciousLinkTitle .description,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipSuspectedMaliciousLinkTitle .description {
  color: #777777;
  font-size: 11px;
  line-height: 13px;
  clear: both;
  padding-top: 2px;
  float: left;
  padding-bottom: 12px;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipTitle,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipTitle {
  display: flex;
  width: 100%;
  flex-direction: row;
  align-content: center;
  align-items: center;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipTitle .dot,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipTitle .dot,
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipTitle .riskScore,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipTitle .riskScore,
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipTitle .title,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipTitle .title {
  float: left;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipTitle .dot,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipTitle .dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-top: 3px;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipTitle .dot[criticality="1"],
.rfBrowextIocHighlightLink__tooltip__inner .tooltipTitle .dot[criticality="1"] {
  background: #ccc;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipTitle .dot[criticality="2"],
.rfBrowextIocHighlightLink__tooltip__inner .tooltipTitle .dot[criticality="2"] {
  background: #ffce00;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipTitle .dot[criticality="3"],
.rfBrowextIocHighlightLink__tooltip__inner .tooltipTitle .dot[criticality="3"] {
  background: #cf0a2c;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipTitle .riskScore,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipTitle .riskScore {
  font-weight: 600;
  font-size: 13px;
  line-height: 16px;
  margin-left: 5px;
  margin-top: 0px;
  width: auto;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipTitle .title,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipTitle .title,
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipTitle .redirectsToTitle,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipTitle .redirectsToTitle {
  font-weight: 600;
  font-size: 13px;
  line-height: 16px;
  margin-left: 12px;
  margin-top: 0px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  width: auto;
  max-width: 90%;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipSummary,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipSummary {
  clear: both;
  padding-top: 9px;
  margin-left: 16px;
  float: left;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipSummary .riskRuleElement,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipSummary .riskRuleElement {
  height: 28px;
  border-left-width: 8px;
  border-left-style: solid;
  padding-left: 6px;
  font-weight: 600;
  font-size: 13px;
  line-height: 28px;
  margin-top: 1px;
  float: left;
  clear: both;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipSummary .riskRuleElement.greyedOut,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipSummary .riskRuleElement.greyedOut {
  color: #777777;
  font-weight: 400;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipSummary .riskRuleElement:first-child,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipSummary .riskRuleElement:first-child {
  margin-top: 0px;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipSummary .riskRuleElement[criticality="1"],
.rfBrowextIocHighlightLink__tooltip__inner .tooltipSummary .riskRuleElement[criticality="1"] {
  border-left-color: #ccc;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipSummary .riskRuleElement[criticality="2"],
.rfBrowextIocHighlightLink__tooltip__inner .tooltipSummary .riskRuleElement[criticality="2"] {
  border-left-color: #ffce00;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipSummary .riskRuleElement[criticality="3"],
.rfBrowextIocHighlightLink__tooltip__inner .tooltipSummary .riskRuleElement[criticality="3"] {
  border-left-color: #cf0a2c;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipNavigateLink,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipNavigateLink {
  padding-top: 12px;
  float: left;
  clear: both;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipNavigateLink__link,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipNavigateLink__link {
  font-size: 12px;
  line-height: 15px;
  color: #0071CE;
  text-decoration: none;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipNavigateLink__link:visited,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipNavigateLink__link:visited {
  color: #0071CE;
}
.rfBrowextUrlHighlightLink__tooltip__inner .tooltipNavigateLink__link:hover,
.rfBrowextIocHighlightLink__tooltip__inner .tooltipNavigateLink__link:hover {
  color: #0071CE;
  text-decoration: underline;
}
.rfBrowextUrlHighlightLink.hide {
  background-color: transparent !important;
  padding-right: 0px !important;
}
.rfBrowextUrlHighlightLink__riskplupp {
  padding: 0 5px;
}
.rfBrowextUrlHighlightLink__riskplupp:after {
  content: \"\\25cf\";
}
.rfBrowextUrlHighlightLink__riskplupp[criticality="1"] {
  color: #ccc;
}
.rfBrowextUrlHighlightLink__riskplupp[criticality="2"] {
  color: #fece02;
}
.rfBrowextUrlHighlightLink__riskplupp[criticality="3"] {
  color: #ce1f2c;
}
.rfBrowextUrlHighlightLink__riskScoreWrapper {
  position: absolute;
  background: white;
  top: 5px;
  left: 5px;
  border-radius: 4px;
  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.2);
}
.rfBrowextUrlHighlightLink__disabledIcon svg {
  fill: #222222;
  position: relative;
}
.rfBrowextUrlHighlightLink__risk {
  color: #222222;
}
.rfBrowextUrlHighlightLink__risk:after {
  color: #222222;
  content: attr(riskscore);
}
.rfBrowextUrlHighlightLink.rfBrowextUrlHighlightLink-highlighted {
  background-color: #ffffff !important;
  box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);
  border-radius: 3px;
}
.rfBrowextUrlHighlightLink.rfBrowextUrlHighlightLink-highlighted.disabled {
  cursor: not-allowed !important;
}
.rfBrowextIocHighlightLink {
  background-color: rgba(255, 255, 255, 0);
  transition: background-color 0.3s ease;
  padding-right: 5px;
  display: inline-block;
  white-space: nowrap !important;
  border-radius: 3px;
}
.rfBrowextIocHighlightLink.normal-wrap {
  white-space: normal !important;
}
.rfBrowextIocHighlightLink.hide {
  background-color: transparent !important;
  padding-right: 0px !important;
}
.rfBrowextIocHighlightLink * {
  vertical-align: middle !important;
  display: inline !important;
}
.rfBrowextIocHighlightLink__title {
  padding-left: 3px;
}
.rfBrowextIocHighlightLink__image {
  background-repeat: no-repeat;
  background-position: center center;
  background-size: 16px 16px;
  padding: 0px 0px;
  transition: all 0.3s ease;
  width: 0px;
  height: 16px;
  margin-left: 0;
  display: inline-block !important;
}
.rfBrowextIocHighlightLink__riskplupp {
  padding: 0 5px;
}
.rfBrowextIocHighlightLink__riskplupp:after {
  content: \"\\25cf\";
}
.rfBrowextIocHighlightLink__riskplupp[criticality="1"] {
  color: #ccc;
}
.rfBrowextIocHighlightLink__riskplupp[criticality="2"] {
  color: #fece02;
}
.rfBrowextIocHighlightLink__riskplupp[criticality="3"] {
  color: #ce1f2c;
}
.rfBrowextIocHighlightLink__risk:after {
  content: attr(riskscore);
}
.rfBrowextIocHighlightLink.rfBrowextIocHighlightLink-highlighted {
  background-color: #ffffff;
  box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);
  color: black;
  line-height: initial;
  word-break: break-all !important;
  width: auto !important;
  cursor: pointer;
}
.rfBrowextIocHighlightLink.rfBrowextIocHighlightLink-highlighted.nonClickable {
  cursor: default;
}
.rfBrowextIocHighlightLink.rfBrowextIocHighlightLink-highlighted.nonClickable:hover {
  background-color: #ffffff !important;
}
.rfBrowextIocHighlightLink.rfBrowextIocHighlightLink-highlighted .rfBrowextIocHighlightLink__image {
  width: 16px;
  margin-left: 2px;
}
.rfBrowextUrlHighlightLink-highlighted:hover,
.rfBrowextIocHighlightLink-highlighted:hover {
  background-color: #fff3bf !important;
}
`;

const throttle = (func, limit) => {
  let lastFunc;
  let lastRan;
  return function () {
    const context = this;
    const args = arguments;
    if (!lastRan) {
      func.apply(context, args);
      lastRan = Date.now();
    } else {
      clearTimeout(lastFunc);
      lastFunc = setTimeout(function () {
        if (Date.now() - lastRan >= limit) {
          func.apply(context, args);
          lastRan = Date.now();
        }
      }, limit - (Date.now() - lastRan));
    }
  };
};

if (!window.hasRfResizeEventHandler) {
  window.hasRfResizeEventHandler = true;
  window.addEventListener(
    "resize",
    throttle(function () {
      document
        .querySelectorAll(
          ".rfBrowextIocHighlightLink__tooltip, .rfBrowextUrlHighlightLink__tooltip"
        )
        .forEach((x) => (x.style.visibility = "hidden"));
    }, 300)
  );
}

chrome.storage.local.get(["scope"], (items) => {
  freemiumAccount = items && items.scope && items.scope.includes("FreeData");
});

var bkgPort = chrome.runtime.connect({ name: "port-bkg-cs" });

const riskScores = {};
let currentUrl = window.location.href;

const disableForeginObjectClickStyle = `.rfHighlightForeignObject { pointer-events: none; }`;
const disableForeginObjectClickStyleObject = document.createElement("style");
disableForeginObjectClickStyleObject.id = "rfExtLogRhythmStyle";
disableForeginObjectClickStyleObject.innerHTML = disableForeginObjectClickStyle;

// This is to fix a bug in Logrhytm where the extension highlighting would overlap elements in the page
// so that they would not become clickable RFPD-3209
const keyIsCmdOrCtrl = (ev) =>
  ev.metaKey || ev.ctrlKey || ev.key === "Meta" || ev.key === "Control";
if (currentUrl.includes("logrhythm")) {
  document.addEventListener("keydown", (ev) => {
    if (keyIsCmdOrCtrl(ev)) {
      // CTRL button
      if (!document.getElementById("rfExtLogRhythmStyle"))
        document
          .querySelector("head")
          .appendChild(disableForeginObjectClickStyleObject);
    }
  });
  document.addEventListener("keyup", (ev) => {
    if (keyIsCmdOrCtrl(ev)) {
      // CTRL button
      if (document.getElementById("rfExtLogRhythmStyle"))
        document.getElementById("rfExtLogRhythmStyle").remove();
    }
  });
}

// Selectors for elements that we should skip when looking through DOM for ioc occurences
let ELEMENTS_TO_SKIP = [
  "html",
  "head",
  "script",
  "noscript",
  "style",
  "img",
  "input",
  "video",
  "button",
  "code",
  "svg", // svg related element
  "g", // svg related element
  "rect", // svg related element
  "circle", // svg related element
  "ellipse", // svg related element
  "polygon", // svg related element
  "linearGradient", // svg related element
  "radialGradient", // svg related element
  "defs", // svg related element
  "path", // svg related element
  "mask", // svg related element
  "stop", // svg related element
  "use", // svg related element
  "switch", // svg related element
  "head",
  "title",
  "meta",
  "link",
  /* 'iframe', */
  "textarea",
  "dom-module", // Youtube specific stuff
  "dom-if", // Youtube specific stuff
  "dom-repeat", // Youtube specific stuff
  "yt-icon", // Youtube specific stuff
  "ytd-badge-supported-renderer", // Youtube specific stuff
  "ytd-thumbnail-overlay-now-playing-renderer", // Youtube specific stuff
  "ytd-thumbnail-overlay-time-status-renderer", // Youtube specific stuff
  "ytd-thumbnail-overlay-equalizer", // Youtube specific stuff
  "ytd-thumbnail", // Youtube specific stuff
  "ytd-menu-renderer", // Youtube specific stuff
  "ytd-grid-video-renderer", // Youtube specific stuff
  "ytd-badge-supported-renderer", // Youtube specific stuff
  "yt-interaction", // Youtube specific stuff
  "yt-icon-button", // Youtube specific stuff
  "yt-formatted-string", // Youtube specific stuff
  "tp-yt-paper-tooltip", // Youtube specific stuff
  "yt-img-shadow", // Youtube specific stuff
  "ytd-channel-name", // Youtube specific stuff
  "ytd-rich-grid-media", // youtube specific stuff
  "ytd-rich-item-renderer", // youtube specific stuff
  "ytd-guide-entry-renderer", // youtube specific stuff
  "ytd-video-renderer", // youtube specific stuff
  "ytd-button-renderer", // youtube specific stuff
  "ytd-video-meta-block", // youtube specific stuff
  "template", // Youtube specific stuff
  "clipPath", // Youtube specific stuff
  ".rfBrowextIocHighlightLink",
  ".rfBrowextIocHighlightLink__image",
  ".rfBrowextIocHighlightLink__title",
  ".rfBrowextIocHighlightLink__riskplupp",
  ".rfBrowextIocHighlightLink__tooltip",
  ".rfBrowextIocHighlightLink__risk",
  ".rfBrowextUrlHighlightLink",
  ".rfBrowextUrlHighlightLink__image",
  ".rfBrowextUrlHighlightLink__title",
  ".rfBrowextUrlHighlightLink__riskplupp",
  ".rfBrowextUrlHighlightLink__tooltip",
  ".rfBrowextUrlHighlightLink__risk",
  ".rfBrowextUrlHighlightLink__disabledIcon",
  ".rfBrowextUrlHighlightLink__riskScoreWrapper" /* ,
    '.rfHighlightForeignObject' */,
];

/*
  RFPD-34810
  If user is on Logrhythm, disable highlighting specifically in this element, because it causes an issue (see the Jira)
*/
if (new URL(window.location.href).host.includes("logrhythm")) {
  ELEMENTS_TO_SKIP.push('section[data-testid="mini-inspector"] *');
}

const obfuscationPatterns = {
  ".": /(\s*)\(\.\)(\s*)|(\s*)\[\.\](\s*)/gi,
};

let cachedEntities;
let cachedLinks;

////////////////////////////////////////////////////////////////

const getTextOfElement = (element) => {
  // This function will get the text inside directly inside the element, ignoring child elements
  // See: https://medium.com/@roxeteer/javascript-one-liner-to-get-elements-text-content-without-its-child-nodes-8e59269d1e711
  return [].reduce.call(
    element.childNodes,
    (a, b) => {
      return a + (b.nodeType === 3 ? b.textContent : "");
    },
    ""
  );
};

const deobfuscate = (text) => {
  return Object.keys(obfuscationPatterns).reduce(
    (total, replacement) =>
      (total = total.replace(obfuscationPatterns[replacement], replacement)),
    text
  );
};

const setStylingOfElement = (element) => {
  return new Promise((resolve) => {
    if (!element.getElementById("customRfStyling")) {
      const style = document.createElement("style");
      style.id = "customRfStyling";
      style.innerHTML = rfCss;
      if (element.body) {
        element.body.append(style);
      } else {
        element.append(style);
      }
      resolve();
    } else {
      resolve();
    }
  });
};

const highlightInElement = (element, iocs, query, settings) => {
  // Get elements in body
  const elements = element.querySelectorAll(query);

  iocs = iocs.sort((a, b) => b.name.length - a.name.length);

  // Replace occurences of ioc names with highlight boxes
  elements.forEach((e) => {
    const textOfElement = getTextOfElement(e);
    const deobfuscatedText = deobfuscate(textOfElement);
    const contentIsObfuscated = deobfuscatedText !== textOfElement;
    // Check if the current element is a <text> element which is used for labels inside
    // SVG:s. We cant inject html into a svg-node in the same way, a special solution is needed
    const isTextElement = e.tagName === "text";

    let isInsideTooltip = false;
    let parent = e.parentElement;
    let iterations = 0;
    while (parent) {
      // Traverse up in the DOM tree from the target element to see if it is inside a tooltip
      const classList = parent.classList;
      if (iterations > 7) {
        // To save performacne have a max iteration count
        parent = null;
      } else if (
        classList.contains("rfBrowextIocHighlightLink__tooltip") ||
        classList.contains("rfBrowextUrlHighlightLink__tooltip")
      ) {
        isInsideTooltip = true;
        parent = null;
      } else {
        parent = parent.parentElement;
        iterations++;
      }
    }

    if (!isInsideTooltip) {
      iocs.forEach((ioc) => {
        if (
          deobfuscatedText.toLowerCase().indexOf(ioc.name.toLowerCase()) !== -1
        ) {
          // skip and skip2 are to fix an issue where sometimes a domain name inside a link
          // would get highlighted even though the link should instead be blocked
          // See RFPD-10704
          const entitiesAsList =
            cachedEntities && cachedEntities.matches
              ? cachedEntities.matches.reduce(
                  (total, current) => [...total, ...current.iocs],
                  []
                )
              : cachedEntities;
          const skip =
            e.tagName === "A" &&
            ioc.fromLink &&
            regExpUtil.isUrl(ioc.name) &&
            settings.disableMaliciousLinks &&
            entitiesAsList &&
            entitiesAsList.find((x) => x.name === ioc.name) &&
            entitiesAsList.find((x) => x.name === ioc.name).riskData &&
            entitiesAsList.find((x) => x.name === ioc.name).riskData
              .riskScore >= 65;
          const skip2 =
            e.tagName === "A" &&
            regExpUtil.isUrl(deobfuscatedText) &&
            settings.disableMaliciousLinks &&
            entitiesAsList &&
            entitiesAsList.find((x) => x.name === deobfuscatedText) &&
            entitiesAsList.find((x) => x.name === deobfuscatedText).riskData &&
            entitiesAsList.find((x) => x.name === deobfuscatedText).riskData
              .riskScore >= 65;
          if (!skip && !skip2) {
            // Special case for if parent element word-break: break-word style
            const parentStyle = getComputedStyle(e);
            const specialCaseStyle =
              parentStyle.wordBreak === "break-word"
                ? "white-space: normal !important;"
                : "";

            const uniqueId = Math.round(Math.random() * 10000000000000);
            let additionalClasses = "";

            if (currentUrl.includes("app.recordedfuture.com")) {
              additionalClasses = "normal-wrap";
            }

            let markup =
              `<div class=\"rfBrowextIocHighlightLink ${additionalClasses}\" unique-id=\"${uniqueId}\" key=\"${ioc.name}\" link=\"${ioc.link}\" style=\"${specialCaseStyle}"\>` +
              //`<span class="rfBrowextIocHighlightLink__image" style="background-image: url('${logoUrl}')"></span>` +
              `<span class="rfBrowextIocHighlightLink__title">${ioc.name}</span>` +
              `</div>`;

            if (isTextElement) {
              const bbox = e.getBBox();
              const width = Math.round(bbox.width);
              const height = Math.round(bbox.height);
              const xOffset = Math.round(bbox.x);
              const yOffset = Math.round(bbox.y);

              markup =
                `<div class=\"rfBrowextIocHighlightLink ${additionalClasses}\" unique-id=\"${uniqueId}\" key=\"${ioc.name}\" link=\"${ioc.link}\" style=\"${specialCaseStyle}"\ style="width: ${width}px !important;">` +
                //`<span class="rfBrowextIocHighlightLink__image" style="background-image: url('${logoUrl}')"></span>` +
                `<span class="rfBrowextIocHighlightLink__title">${ioc.name}</span>` +
                `</div>`;

              // If the element is a <text> element that means it is inside a SVG-element
              // In that case we need to wrap our highlight div inside a foreignObject element
              // Check https://developer.mozilla.org/en-US/docs/Web/SVG/Element/foreignObject
              const foreignObject = document.createElementNS(
                "http://www.w3.org/2000/svg",
                "foreignObject"
              );
              foreignObject.innerHTML = markup;
              foreignObject.setAttribute("class", "rfHighlightForeignObject");
              foreignObject.setAttribute("x", xOffset);
              foreignObject.setAttribute("y", yOffset);
              foreignObject.setAttribute("width", `${width}`);
              foreignObject.setAttribute("height", `${height}`);
              foreignObject.setAttribute(
                "style",
                `font-size: ${height - 3}px; width: ${width};`
              );
              foreignObject.style.display = "none";

              if (e.parentNode) {
                e.parentNode.insertBefore(foreignObject, e.nextSibling);
                const svgParent = e.closest("svg");
                if (svgParent) {
                  svgParent.style.overflow = "visible";
                }
              }
            } else {
              // TODO maybe clean innerHTML here?
              let innerHTML = e.innerHTML;

              // Gmail links inserts <wbr> elements inside URLs which messes up highlighting
              // RFPD-22472
              innerHTML = innerHTML.replaceAll(new RegExp("<wbr>", "g"), ""); // Replace all <wbr> elements

              const EMAILPLACEHOLDER = "EMAILPLACEHOLDER";
              const emailRegex =
                /(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})/gi;
              const containsEmails = emailRegex.test(e.innerHTML);
              let emails;
              if (containsEmails) {
                emails = innerHTML.match(emailRegex);
                innerHTML = innerHTML.replace(emailRegex, EMAILPLACEHOLDER);
              }

              // If the innerHTML contains <a>-tags for links then it could cause problems if an IoC within a href-attribute
              // would be replaced with a highlight div. Therefore we do this do ignore <a>-links so that they are unaffected
              const LINKPLACEHOLDER = "LINKTAGPLACEHOLDER";
              /* eslint-disable no-control-regex */
              const linkRegex = new RegExp(
                "<s*a[^>]*>((.|\n)*?)<s*/s*a>",
                "gm"
              );
              /* eslint-enable no-control-regex */
              const containsLinks = linkRegex.test(e.innerHTML);
              let links;
              if (containsLinks) {
                // innerHTML contains <a>-tags, replace these temporarily with placeholders
                // so that we can retain their original values and not affect them
                links = innerHTML.match(linkRegex);
                innerHTML = innerHTML.replace(linkRegex, LINKPLACEHOLDER);
              }

              // Ignore textareas
              const TEXTAREAPLACEHOLDER = "TEXTAREAPLACEHOLDER";
              /* eslint-disable no-control-regex */
              const textareaRegex = new RegExp(
                "<s*textarea[^>]*>((.|\n)*?)<s*/s*textarea>",
                "gm"
              );
              /* eslint-enable no-control-regex */
              const containsTextareas = textareaRegex.test(e.innerHTML);
              let textareas;
              if (containsTextareas) {
                textareas = innerHTML.match(textareaRegex);
                innerHTML = innerHTML.replace(
                  textareaRegex,
                  TEXTAREAPLACEHOLDER
                );
              }

              const RF_SCRIPTSPLACEHOLDER = "RF_SCRIPTSPLACEHOLDER";
              /* eslint-disable no-control-regex */
              const scriptsRegex = new RegExp(
                "<s*script[^>]*>((.|\n)*?)<s*/s*script>",
                "gm"
              );
              /* eslint-enable no-control-regex */
              const containsScripts = scriptsRegex.test(e.innerHTML);
              let rfScripts;
              if (containsScripts) {
                rfScripts = innerHTML.match(scriptsRegex);
                innerHTML = innerHTML.replace(
                  scriptsRegex,
                  RF_SCRIPTSPLACEHOLDER
                );
              }

              // Similar fix to prevent that .rfBrowextIocHighlightLink elements are nested inside each other
              const RF_LINKPLACEHOLDER = "RF_HIGHLIGHT_BOX_PLACEHOLDER";
              /* eslint-disable no-control-regex */
              const rfLinkRegex = new RegExp(
                '<s*(div class="rfBrowextIocHighlightLink)[^>]*>((.|\n)*?)<s*/s*div>',
                "gm"
              );
              /* eslint-enable no-control-regex */
              const containsRFHighlightBoxes = rfLinkRegex.test(e.innerHTML);
              let rfLinks;
              if (containsRFHighlightBoxes) {
                rfLinks = innerHTML.match(rfLinkRegex);
                innerHTML = innerHTML.replace(rfLinkRegex, RF_LINKPLACEHOLDER);
              }

              if (contentIsObfuscated) {
                innerHTML = deobfuscate(innerHTML);
              }
              innerHTML = innerHTML.replaceAll(ioc.name, markup);

              if (containsLinks) {
                // Add link elements that have been saved from before and therefore remain unaffected
                let index = 0;
                innerHTML = innerHTML.replace(
                  new RegExp(LINKPLACEHOLDER, "gm"),
                  (...args) => {
                    const tag = links[index];
                    index++;
                    return tag;
                  }
                );
              }
              if (containsTextareas) {
                let index = 0;
                innerHTML = innerHTML.replace(
                  new RegExp(TEXTAREAPLACEHOLDER, "gm"),
                  (...args) => {
                    const tag = textareas[index];
                    index++;
                    return tag;
                  }
                );
              }
              if (containsEmails) {
                let index = 0;
                innerHTML = innerHTML.replace(
                  new RegExp(EMAILPLACEHOLDER, "ig"),
                  (...args) => {
                    const tag = emails[index];
                    index++;
                    return tag;
                  }
                );
              }
              if (containsRFHighlightBoxes) {
                // Add link elements that have been saved from before and therefore remain unaffected
                let index = 0;
                innerHTML = innerHTML.replace(
                  new RegExp(RF_LINKPLACEHOLDER, "gm"),
                  (...args) => {
                    const tag = rfLinks[index];
                    index++;
                    return tag;
                  }
                );
              }
              if (containsScripts) {
                let index = 0;
                innerHTML = innerHTML.replace(
                  new RegExp(RF_SCRIPTSPLACEHOLDER, "gm"),
                  (...args) => {
                    const tag = rfScripts[index];
                    index++;
                    return tag;
                  }
                );
              }
              e.innerHTML = innerHTML;
            }
          }
        }
      });
    }
    if (e.shadowRoot) {
      highlightInElement(e.shadowRoot, iocs, query, settings);
    }
  });
  setStylingOfElement(element);
};

const highlightInShadowDoms = (query, doc, iocsSimplified, settings) => {
  doc.querySelectorAll(query).forEach((el) => {
    if (el.shadowRoot) {
      highlightInElement(el.shadowRoot, iocsSimplified, query, settings);
      highlightInShadowDoms(query, el.shadowRoot, iocsSimplified, settings);
    }
  });
};

const getRiskScores = (iocs, settings) => {
  let iocsClone = iocs.slice(0);
  // Only fetch risk scores for unknown IOC:s
  const unknownIocs = iocsClone.filter((x) => !riskScores[x.name]);
  // RFPD-8784 This is to fix a bug where the user has a brand new installed version of BE with URL disabled
  // If the IoCs found that are unknown are all URLs but URL entity type is disabled, a message should not be posted
  // to background to try tro fetch risk scores for these that should be ignored anyway
  const skip =
    !settings.entityTypesToShow.url &&
    unknownIocs.every((x) => regExpUtil.isUrl(x.name));
  if (!skip && unknownIocs.length > 0) {
    bkgPort.postMessage({ getRiskScores: true, iocs: unknownIocs });
  } else if (unknownIocs.length === 0 || skip) {
    // we already have all risk data in memory
    if (!settings.disableMaliciousLinks) {
      removeUrlHighlightBoxes();
    }
    fetchedIocRiskScoresResponse({
      iocs: iocsClone,
    });
  }
};

function arraysEqual(a, b) {
  return (
    a &&
    b &&
    a.length === b.length &&
    a.every((x) => b.includes(x)) &&
    b.every((x) => a.includes(x))
  );
}

const getIframeBody = iframe => {
  let body;
  if (iframe.contentDocument) {
    body = iframe.contentDocument;
  } else {
    try {
      body = iframe.contentWindow.document;
    } catch (err) {
      console.warn('Could not get contentWindow.document of iframe', err);
    }
  }
  return body;
}

const removeHighlightBoxes = (
  doNotRemoveBoxesWithRiskScores = false,
  settings = null,
  removeList = null
) => {
  const removeBoxesInElement = (element) => {
    element.querySelectorAll(".rfBrowextIocHighlightLink").forEach((e) => {
      const key = e.getAttribute("key");
      const keyShouldBeShown =
        (key &&
          settings &&
          regExpUtil.isIdn(key) &&
          settings &&
          settings.entityTypesToShow.domain) ||
        (regExpUtil.isCve(key) &&
          settings &&
          settings.entityTypesToShow.vulnerability) ||
        (regExpUtil.isUrl(key) && settings && settings.entityTypesToShow.url) ||
        (regExpUtil.isIPAddress(key) &&
          settings &&
          settings.entityTypesToShow.ip) ||
        (regExpUtil.isHash(key) && settings && settings.entityTypesToShow.hash);

      const doNotRemove =
        keyShouldBeShown &&
        doNotRemoveBoxesWithRiskScores &&
        e.querySelector(".rfBrowextIocHighlightLink__risk");
      // removeList can be used to specify if you only want to remove a specific subset of IoC highlights
      const doNotRemove2 =
        removeList && removeList.length > 0 && !removeList.includes(key);

      if (!doNotRemove && !doNotRemove2) {
        e.outerHTML = e.querySelector(
          ".rfBrowextIocHighlightLink__title"
        ).textContent;
      }
    });
    element.querySelectorAll(".rfHighlightForeignObject").forEach((e) => {
      const key = e.getAttribute("key");
      const keyShouldBeShown =
        (key &&
          settings &&
          regExpUtil.isIdn(key) &&
          settings &&
          settings.entityTypesToShow.domain) ||
        (regExpUtil.isCve(key) &&
          settings &&
          settings.entityTypesToShow.vulnerability) ||
        (regExpUtil.isUrl(key) && settings && settings.entityTypesToShow.url) ||
        (regExpUtil.isIPAddress(key) &&
          settings &&
          settings.entityTypesToShow.ip) ||
        (regExpUtil.isHash(key) && settings && settings.entityTypesToShow.hash);
      const doNotRemove =
        keyShouldBeShown &&
        doNotRemoveBoxesWithRiskScores &&
        e.querySelector(".rfBrowextIocHighlightLink__risk");
      if (!doNotRemove) {
        e.remove();
      }
    });
    element
      .querySelectorAll(".rfBrowextIocHighlightLink__tooltip")
      .forEach((e) => {
        const key = e.getAttribute("for");
        const uniqueId = e.getAttribute("unique-id");
        const highlightBox = element.querySelector(
          `.rfBrowextIocHighlightLink[unique-id="${uniqueId}"]`
        );
        const keyShouldBeShown =
          (key &&
            highlightBox &&
            settings &&
            regExpUtil.isIdn(key) &&
            settings &&
            settings.entityTypesToShow.domain) ||
          (regExpUtil.isCve(key) &&
            settings &&
            settings.entityTypesToShow.vulnerability) ||
          (regExpUtil.isUrl(key) &&
            settings &&
            settings.entityTypesToShow.url) ||
          (regExpUtil.isIPAddress(key) &&
            settings &&
            settings.entityTypesToShow.ip) ||
          (regExpUtil.isHash(key) &&
            settings &&
            settings.entityTypesToShow.hash);
        const doNotRemove = keyShouldBeShown && doNotRemoveBoxesWithRiskScores;

        if (!doNotRemove) {
          e.remove();
        }
      });
  };

  removeBoxesInElement(document);

  const containsFrames = document.body.innerHTML.includes("<frame");
  if (containsFrames) {
    document
      .querySelectorAll("frame")
      .forEach((frame) => removeBoxesInElement(frame.contentDocument));
  }
  // Remove from iframes too
  if (iframeDomain) {
    const iframes = getAllIframes();
    iframes.forEach((iframe) => {
      const body = getIframeBody(iframe);
      if (body) {
        removeBoxesInElement(body);
      }
    });
  }
  const removeFromShadowElements = (el) => {
    const query = ELEMENTS_TO_SKIP.reduce(
      (total, current) => `${total}:not(${current})`,
      "*"
    );
    el.querySelectorAll(query).forEach((e) => {
      if (e.shadowRoot) {
        removeBoxesInElement(e.shadowRoot);
        removeFromShadowElements(e.shadowRoot);
      }
    });
  };
  if (!doNotRemoveBoxesWithRiskScores) {
    // Remove from shadow elements, recursive function for removing from shadow dom
    removeFromShadowElements(document);
  }
};

const highlightUrls = (links) => {
  cachedLinks = links;

  userSettings.getUserSettings().then((settings) => {
    //removeHighlightBoxes(false, settings, links);
    removeUrlHighlightBoxes(true);

    if (settings.disableMaliciousLinks) {
      highlightLinksInElement(document, cachedLinks);

      const containsFrames = document.body.innerHTML.includes("<frame");

      if (iframeDomain) {
        const iframes = getAllIframes();
        iframes.forEach((iframe) => {
          const body = getIframeBody(iframe);
          if (body) {
            highlightLinksInElement(body, cachedLinks);
          }
        });
      }
      if (containsFrames) {
        document
          .querySelectorAll("frame")
          .forEach((frame) =>
            highlightLinksInElement(frame.contentDocument, cachedLinks)
          );
      }

      highlightUrlsInShadowDoms(document, cachedLinks);
      if (cachedLinks) {
        let list;
        if (!cachedLinks.iocs && Array.isArray(cachedLinks)) {
          list = cachedLinks;
        } else if (cachedLinks.iocs) {
          list = cachedLinks.iocs;
        }
        getRiskScores(list, settings);
      }
    }
  });
};

const removeUrlHighlightBoxes = (doNotRemoveBoxesWithRiskScores = false) => {
  const removeBoxesInElement = (element) => {
    element.querySelectorAll(".rfBrowextUrlHighlightLink").forEach((e) => {
      const doNotRemove =
        doNotRemoveBoxesWithRiskScores &&
        e.querySelector(".rfBrowextUrlHighlightLink__risk");

      if (!doNotRemove) {
        if (e.getAttribute("ref-backup")) {
          e.setAttribute("href", e.getAttribute("ref-backup"));
        }
        e.classList.remove("rfBrowextUrlHighlightLink-highlighted");
        if (e.querySelector(".rfBrowextUrlHighlightLink__risk")) {
          e.querySelector(".rfBrowextUrlHighlightLink__risk").remove();
        }
        if (e.querySelector(".rfBrowextUrlHighlightLink__riskplupp")) {
          e.querySelector(".rfBrowextUrlHighlightLink__riskplupp").remove();
        }
        if (e.querySelector(".rfBrowextUrlHighlightLink__disabledIcon")) {
          e.querySelectorAll(
            ".rfBrowextUrlHighlightLink__disabledIcon"
          ).forEach((x) => x.remove());
        }
        if (e.querySelector(".rfBrowextUrlHighlightLink__riskScoreWrapper")) {
          e.querySelectorAll(
            ".rfBrowextUrlHighlightLink__riskScoreWrapper"
          ).forEach((x) => x.remove());
        }
      }
    });
    if (!doNotRemoveBoxesWithRiskScores) {
      element
        .querySelectorAll(".rfBrowextUrlHighlightLink__tooltip")
        .forEach((e) => {
          e.remove();
        });
    }
  };

  removeBoxesInElement(document);

  const containsFrames = document.body.innerHTML.includes("<frame");
  if (containsFrames) {
    document
      .querySelectorAll("frame")
      .forEach((frame) => removeBoxesInElement(frame.contentDocument));
  }
  // Remove from iframes too
  if (iframeDomain) {
    const iframes = getAllIframes();
    iframes.forEach((iframe) => {
      const body = getIframeBody(iframe);
      if (body) {
        removeBoxesInElement(body);
      }
    });
  }
  // Remove from shadow elements, recursive function for removing from shadow dom
  const removeFromShadowElements = (el) => {
    const query = ELEMENTS_TO_SKIP.reduce(
      (total, current) => `${total}:not(${current})`,
      "*"
    );
    el.querySelectorAll(query).forEach((e) => {
      if (e.shadowRoot) {
        removeBoxesInElement(e.shadowRoot);
        removeFromShadowElements(e.shadowRoot);
      }
    });
  };
  removeFromShadowElements(document);
};

const getAllIframes = () => {
  const iframes = document.getElementsByTagName("iframe");
  const getIframesInsideShadowDoms = (root) => {
    let list = [];
    [...root.querySelectorAll("*")].forEach((x) => {
      if (x.shadowRoot) {
        list = [
          ...list,
          ...[...x.shadowRoot.querySelectorAll("iframe")],
          ...[...getIframesInsideShadowDoms(x.shadowRoot)],
        ];
      }
    });
    return list;
  };
  const iframesInShadowDoms = getIframesInsideShadowDoms(document);
  return [...iframes, ...iframesInShadowDoms];
};

const highlightLinksInElement = (element, links) => {
  let list;
  if (!links.iocs && Array.isArray(links) && links.length > 0) {
    list = links;
  } else if (links.iocs) {
    list = links.iocs;
  }

  if (list) {
    list.forEach((link) => {
      const linkElements = element.querySelectorAll(
        `a[href^='${link.name}']:not(.tooltipNavigateLink__link)`
      );
      linkElements.forEach((linkElement) => {
        const linkContainsIocHighlight = linkElement.querySelector(
          ".rfBrowextIocHighlightLink"
        );
        if (!linkContainsIocHighlight) {
          linkElement.classList.add("rfBrowextUrlHighlightLink");
          linkElement.setAttribute("key", link.name);
          linkElement.setAttribute(
            "unique-id",
            Math.round(Math.random() * 10000000000000)
          );
          linkElement.setAttribute("link", link.link);
        }
      });
    });
    setStylingOfElement(element);
  }
};

const highlightUrlsInShadowDoms = (element, links) => {
  element
    .querySelectorAll("a:not(.tooltipNavigateLink__link)")
    .forEach((el) => {
      if (el.shadowRoot) {
        highlightLinksInElement(el.shadowRoot, links);
        highlightUrlsInShadowDoms(el.shadowRoot, links);
      }
    });
};

const cacheIocs = (entities) => {
  cachedEntities = entities;
};

const highlightIocs = (
  entities,
  forceHighlight = false,
  url = null,
  ignoreTooManyHits = false,
  doNotAskForRiskScores = false,
  overrideMaxLevelBlock = false,
  callback = null
) => {
  if (overrideMaxLevelBlock) {
    if (!overrideCache.includes(window.location.href)) {
      overrideCache.push(window.location.href);
    }
  }

  if (highlightingInProgress && !ignoreTooManyHits) {
    return;
  }
  if (!entities) {
    return;
  }

  let iocsSimplified = entities.matches
    ? entities.matches.reduce(
        (total, current) => [...total, ...current.iocs],
        []
      )
    : entities;

  // Place URLs before anything else
  iocsSimplified.sort((a, b) => {
    if (regExpUtil.isUrl(b.name) && !regExpUtil.isUrl(a.name)) return -1;
    if (regExpUtil.isUrl(a.name) && !regExpUtil.isUrl(b.name)) return 1;
    return 0;
  });

  let override = overrideMaxLevelBlock;
  if (
    overrideCache.length > 0 &&
    overrideCache.includes(window.location.href)
  ) {
    override = true;
  }

  if (
    !override &&
    iocsSimplified.length > config.MAX_AMOUNT_OF_ENTITIES_FOR_HIGHLIGHTING
  ) {
    return;
  }

  const timestamp = Date.now();
  const diff = highlightIocsTimestamp
    ? timestamp - highlightIocsTimestamp
    : null;
  const iocsNames = iocsSimplified.map((x) => x.name);
  const previosIocsNames = lastHighlightedEntities
    ? lastHighlightedEntities.map((x) => x.name)
    : [];
  const identical =
    iocsNames.length === previosIocsNames.length &&
    previosIocsNames.every((x) => iocsNames.includes(x));

  // If the new IoCs are identical to the last time highlighting occured, and it was less than 900 ms since
  // last time highiglight occured, then we can skip this. This is to avoid unnecessary highlighting if page was already
  // highlighted
  if (
    identical &&
    diff &&
    diff < 900 &&
    document.querySelectorAll(".rfBrowextIocHighlightLink").length !== 0
  ) {
    return;
  }
  highlightingInProgress = true;
  if (url) {
    currentUrl = url;
  }

  highlightIocsTimestamp = Date.now();
  lastHighlightedEntities = iocsSimplified;

  const host = new URL(currentUrl).hostname;
  // The following is to fix an issue where sometimes you get two (almost) identical idns, only difference
  // being that one starts with 'www.'. For instance 'google.com' and 'www.google.com'. This would
  // cause an issue where the same text would get highlighted several times, creating an undesired visual bug
  /* iocsSimplified.forEach(ioc => {
    if (ioc.name.startsWith('www.')) {
      // For instance, if found 'www.google.com', then remove 'google.com' from the ioc list
      const shortenedName = ioc.name.replace('www.', '');
      iocsSimplified = iocsSimplified.filter(x => x.name !== shortenedName);
    }
  }); */
  let cachedIocNames;

  if (cachedEntities) {
    if (cachedEntities.matches) {
      cachedIocNames = cachedEntities.matches
        .reduce((total, current) => [...total, ...current.iocs], [])
        .map((x) => x.name);
    } else {
      cachedIocNames = cachedEntities.map((x) => x.name);
    }
  } else {
    cachedIocNames = null;
  }

  // Do not highlight if entities are the same as the cached ones that are already highlighted
  if (!forceHighlight && arraysEqual(iocsNames, cachedIocNames)) {
    highlightingInProgress = false;
    return;
  }

  // Cache entities. Useful if user manually enables/disables highlighting from option menu
  // Then we don't have to rescrape iocs from the dom
  if (
    Array.isArray(entities) &&
    entities.every((x) => x.fromLink || x.fromPlainText)
  ) {
    cachedLinks = entities;
  } else {
    cachedEntities = entities;
  }

  if (
    !ignoreTooManyHits &&
    !override &&
    iocsSimplified.length > config.MAX_AMOUNT_OF_ENTITIES_FOR_HIGHLIGHTING
  ) {
    return;
  }

  userSettings.getUserSettings().then((settings) => {
    removeHighlightBoxes(true, settings);

    const siteIsBlacklisted =
      settings.userCustomBlacklist &&
      settings.userCustomBlacklist.some((url) =>
        host.match(new RegExp(url, "g"))
      );

    if (
      !settings.entityTypesToShow.url &&
      entities.matches &&
      entities.matches.find((e) => e.type === "urls")
    ) {
      iocsSimplified = iocsSimplified.filter(
        (x) => !entities.matches.find((e) => e.type === "urls").iocs.includes(x)
      );
    }

    if ((settings.highlightingEnabled && !siteIsBlacklisted) || override) {
      // Build up a selector query
      let query = ELEMENTS_TO_SKIP.reduce(
        (total, current) => `${total}:not(${current})`,
        "*"
      );

      highlightInElement(document, iocsSimplified, query, settings);

      const containsFrames = document.body.innerHTML.includes("<frame");
      if (containsFrames) {
        document
          .querySelectorAll("frame")
          .forEach((frame) =>
            highlightInElement(
              frame.contentDocument,
              iocsSimplified,
              query,
              settings
            )
          );
      }
      if (utils.iframeDomain()) {
        const iframes = getAllIframes();
        iframes.forEach((iframe) => {
          const body = getIframeBody(iframe);
          if (body) {
            highlightInElement(
              body,
              iocsSimplified,
              query,
              settings
            );
          }
        });
      }

      highlightInShadowDoms(query, document, iocsSimplified, settings);
      if (!doNotAskForRiskScores) {
        getRiskScores(iocsSimplified, settings);
      }

      if (callback) {
        callback();
      }
    }
    highlightingInProgress = false;
  });
};

const removeHighlightStyling = () => {
  const removeElementByIdInParent = (parent, id) => {
    let el = parent.getElementById(id);
    if (el) {
      el.remove();
    }
  };
  removeElementByIdInParent(document, "customRfStyling");
  const containsFrames = document.body.innerHTML.includes("<frame");
  if (containsFrames) {
    document
      .querySelectorAll("frame")
      .forEach((frame) =>
        removeElementByIdInParent(frame.contentDocument, "customRfStyling")
      );
  }
  if (iframeDomain) {
    const iframes = getAllIframes();
    iframes.forEach((iframe) => {
      const body = getIframeBody(iframe);
      if (body) {
        removeElementByIdInParent(body, "customRfStyling");
      }
    });
  }
};

const createElementWithClass = (elementType, classToAdd) => {
  const el = document.createElement(elementType);
  el.classList.add(classToAdd);
  return el;
};

const fetchedIocRiskScoresResponse = (request) => {
  // Save risk data in memory
  request.iocs
    .filter((x) => !!x.riskData)
    .forEach((ioc) => {
      riskScores[ioc.name] = { riskData: ioc.riskData, link: ioc.link };
    });

  const timestamp = Date.now();
  const diff = fetchedIocRiskScoresTimestamp
    ? timestamp - fetchedIocRiskScoresTimestamp
    : null;
  if (
    lastFetchedIocs &&
    arraysEqual(request.iocs, lastFetchedIocs) &&
    diff &&
    diff < 800
  ) {
    return;
  }
  fetchedIocRiskScoresTimestamp = Date.now();
  lastFetchedIocs = request.iocs;

  // Sometimes this happens before IoCs are highlighted. In that case we need to highlight first
  // before managing IoC risk scores. See Jira: https://recordedfuture.atlassian.net/browse/RF-64881
  if (
    /* [...document.querySelectorAll('.rfBrowextIocHighlightLink')].length === 0 &&  */ request
      .iocs.length > 0
  ) {
    highlightIocs(request.iocs, true, currentUrl, true, true);
  }
  if (fetchIocsInProgress) {
    return;
  }
  fetchIocsInProgress = true;

  const setRiskAttributesInElement = (element, key) => {
    const setRiskData = (el, key, settings) => {
      let currentSettings = settings;
      if (riskScores[key].riskData.criticality < minimumCriticality) {
        el.querySelectorAll(`.rfBrowextIocHighlightLink[key="${key}"]`).forEach(
          (e) => {
            e.outerHTML = e.querySelector(
              ".rfBrowextIocHighlightLink__title"
            ).textContent;
            e.classList.remove("rfBrowextIocHighlightLink-highlighted");
          }
        );
        return;
      }

      const setHighlight = (element, className) => {
        if (!key.includes('">')) {
          element
            .querySelectorAll(`.${className}[key="${key}"]`)
            .forEach((e) => {
              if (
                (className === "rfBrowextUrlHighlightLink" &&
                  riskScores[key].riskData.riskScore < 65) ||
                (className === "rfBrowextUrlHighlightLink" &&
                  !currentSettings.disableMaliciousLinks)
              ) {
                e.classList.remove("rfBrowextUrlHighlightLink");
                e.classList.remove("rfBrowextUrlHighlightLink-highlighted");
                return;
              }
              if (
                className === "rfBrowextIocHighlightLink" &&
                regExpUtil.isUrl(key) &&
                !currentSettings.entityTypesToShow.url
              ) {
                e.outerHTML = e.querySelector(
                  ".rfBrowextIocHighlightLink__title"
                ).textContent;
                return;
              }
              if (
                className === "rfBrowextIocHighlightLink" &&
                !currentSettings.highlightingEnabled
              ) {
                return;
              }

              let criticality = riskScores[key].riskData.criticality;
              let riskScore = riskScores[key].riskData.riskScore;
              let riskRules = riskScores[key].riskData.riskRules;

              const iocObject = request.iocs.find((x) => x.name === key);

              if (iocObject && iocObject.redirect && iocObject.redirect.risk) {
                riskScore =
                  iocObject.redirect.risk.score ||
                  iocObject.redirect.risk.riskScore;
                criticality = iocObject.redirect.risk.level;
                riskRules =
                  iocObject.redirect.risk.rule ||
                  iocObject.redirect.risk.riskRules;
              } else if (
                iocObject &&
                iocObject.redirect &&
                iocObject.redirect.redirectsTo &&
                riskScoreCache[iocObject.redirect.redirectsTo]
              ) {
                riskScore =
                  riskScoreCache[iocObject.redirect.redirectsTo].riskScore;
                criticality =
                  riskScoreCache[iocObject.redirect.redirectsTo].level;
                riskRules =
                  riskScoreCache[iocObject.redirect.redirectsTo].riskRules;
              } else if (
                riskScores[key].riskData.redirect &&
                riskScores[key].riskData.redirect.risk
              ) {
                riskScore = riskScores[key].riskData.redirect.risk.score;
                criticality = riskScores[key].riskData.redirect.risk.level;
                riskRules = riskScores[key].riskData.redirect.risk.rule;
              }

              e.setAttribute("risk-score", riskScore);

              const uniqueId = e.getAttribute("unique-id");

              const doNotUpdate = e.querySelector(
                ".rfBrowextIocHighlightLink__risk"
              );

              if (!doNotUpdate && riskScore > 0) {
                if (riskScore >= 65) {
                  criticality = 3;
                } else if (riskScore >= 25) {
                  criticality = 2;
                } else {
                  criticality = 1;
                }
                if (criticality < 1) {
                  criticality = 1;
                } else if (criticality > 3) {
                  criticality = 3;
                }
                [
                  `.${className}__risk`,
                  `.${className}__riskplupp`,
                  `.${className}__tooltip`,
                  `.${className}__disabledIcon`,
                  `.${className}__riskScoreWrapper`,
                ].forEach((c) => {
                  const el = e.querySelectorAll(c);
                  if (el) {
                    el.forEach((x) => x.remove());
                  }
                });

                if (
                  e.parentElement &&
                  e.parentElement.nodeName === "foreignObject" &&
                  e.parentElement.classList.contains("rfHighlightForeignObject")
                ) {
                  e.parentElement.style.display = "block";
                }

                e.classList.add(`${className}-highlighted`);

                const isSuspiciousLink =
                  className === "rfBrowextUrlHighlightLink" &&
                  regExpUtil.isUrl(key) &&
                  riskScore >= 65;

                const risk = createElementWithClass(
                  "span",
                  `${className}__risk`
                );
                risk.setAttribute("riskscore", riskScore);

                const plupp = createElementWithClass(
                  "span",
                  `${className}__riskplupp`
                );
                plupp.setAttribute("criticality", criticality);

                const tooltipAlreadyExists = element.querySelector(
                  `.${className}__tooltip[unique-id="${uniqueId}"]`
                );

                if (!tooltipAlreadyExists) {
                  const tooltip = createElementWithClass(
                    "div",
                    `${className}__tooltip`
                  );
                  tooltip.setAttribute("for", key);
                  tooltip.setAttribute("unique-id", uniqueId);
                  const tooltipInner = createElementWithClass(
                    "div",
                    `${className}__tooltip__inner`
                  );

                  let tooltipSuspectedMaliciousLinkTitle;
                  if (isSuspiciousLink) {
                    tooltipSuspectedMaliciousLinkTitle = createElementWithClass(
                      "div",
                      "tooltipSuspectedMaliciousLinkTitle"
                    );
                    const image = createElementWithClass("div", "image");
                    image.innerHTML = `
                      <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24">
                        <path d="M0 0h24v24H0V0z" fill="none"/>
                        <path d="M2.73 21h18.53c.77 0 1.25-.83.87-1.5l-9.27-16c-.39-.67-1.35-.67-1.73 0l-9.27 16c-.38.67.1 1.5.87 1.5zM13 
                        18h-2v-2h2v2zm-1-4c-.55 0-1-.45-1-1v-2c0-.55.45-1 1-1s1 .45 1 1v2c0 .55-.45 1-1 1z"/>
                      </svg>`;
                    const maliciousLinkTitle = createElementWithClass(
                      "div",
                      "title"
                    );
                    maliciousLinkTitle.innerText = "Suspected malicious link";
                    const description = createElementWithClass(
                      "div",
                      "description"
                    );
                    description.innerText =
                      "Automatically disabled by Recorded Future Browser Extension";
                    tooltipSuspectedMaliciousLinkTitle.append(image);
                    tooltipSuspectedMaliciousLinkTitle.append(
                      maliciousLinkTitle
                    );
                    tooltipSuspectedMaliciousLinkTitle.append(description);
                  }

                  const tooltipTitle = createElementWithClass(
                    "div",
                    "tooltipTitle"
                  );
                  const dot = createElementWithClass("div", "dot");
                  dot.setAttribute("criticality", criticality);
                  const riskScoreElement = createElementWithClass(
                    "div",
                    "riskScore"
                  );
                  riskScoreElement.innerText = riskScore;
                  const title = createElementWithClass("div", "title");
                  title.innerText = key;
                  tooltipTitle.append(dot);
                  tooltipTitle.append(riskScoreElement);
                  tooltipTitle.append(title);

                  if (
                    (iocObject && iocObject.redirect) ||
                    riskScores[key].riskData.redirect
                  ) {
                    let redirectsTo;
                    if (
                      iocObject &&
                      iocObject.redirect &&
                      iocObject.redirect.redirectsTo
                    )
                      redirectsTo = iocObject.redirect.redirectsTo;
                    if (
                      !redirectsTo &&
                      riskScores[key] &&
                      riskScores[key].riskData.redirect &&
                      riskScores[key].riskData.redirect.redirectsTo
                    )
                      redirectsTo =
                        riskScores[key].riskData.redirect.redirectsTo;

                    const arrow = createElementWithClass(
                      "div",
                      "redirectArrow"
                    );
                    arrow.innerHTML = `
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <g id="arrow_right_alt">
                  <path id="Vector" d="M16.01 11H4V13H16.01V16L20 12L16.01 8V11Z" fill="#222222"/>
                  </g>
                  <defs>
                  <clipPath id="clip0_1501_2776">
                  <rect width="24" height="24" fill="white"/>
                  </clipPath>
                  </defs>
                  </svg>
                  `;
                    tooltipTitle.appendChild(arrow);

                    const redirectsToTitle = createElementWithClass(
                      "div",
                      "redirectsToTitle"
                    );
                    redirectsToTitle.innerText = redirectsTo;
                    tooltipTitle.append(redirectsToTitle);
                  }

                  const tooltipSummary = createElementWithClass(
                    "div",
                    "tooltipSummary"
                  );

                  if (freemiumAccount || !riskRules.evidence) {
                    const riskRuleElement = createElementWithClass(
                      "div",
                      "riskRuleElement"
                    );
                    let level;
                    if (riskScore) {
                      if (riskScore >= 65) {
                        level = 3;
                      } else if (riskScore >= 25) {
                        level = 2;
                      } else {
                        level = 1;
                      }
                    } else {
                      const sortedSummary = riskRules.summary
                        .filter((x) => x.count > 0)
                        .sort((a, b) => b.level - a.level);
                      if (sortedSummary && sortedSummary[0]) {
                        level = sortedSummary[0].level;
                      }
                    }
                    if (level > 3) {
                      level = 3;
                    }
                    riskRuleElement.setAttribute("criticality", level);
                    const mostCritical =
                      riskRules.mostCriticalRule || riskRules.mostCritical;
                    riskRuleElement.innerText = mostCritical;
                    if (mostCritical) {
                      tooltipSummary.append(riskRuleElement);
                    }

                    let newSummary = riskRules.summary;
                    if (newSummary.length > 0) {
                      newSummary = newSummary.sort((a, b) => b.level - a.level);
                      newSummary[0].count--;
                      newSummary = newSummary.filter((x) => x.count > 0);
                      newSummary.forEach((x) => {
                        if (x.level > 3) {
                          x.level = 3;
                        } else if (x.level < 1) {
                          x.level = 1;
                        }
                      });

                      newSummary.forEach((x) => {
                        const riskRuleElement = createElementWithClass(
                          "div",
                          "riskRuleElement"
                        );
                        riskRuleElement.classList.add("greyedOut");
                        riskRuleElement.setAttribute("criticality", x.level);
                        riskRuleElement.innerText = `${x.count} More Risk Rule${
                          x.count > 1 ? "s" : ""
                        }`;
                        tooltipSummary.append(riskRuleElement);
                      });
                    }
                  } else if (riskRules.evidence) {
                    let evidence = Object.values(riskRules.evidence);
                    evidence = evidence.sort((a, b) => b.level - a.level);
                    evidence.forEach((e) => {
                      const riskRuleElement = createElementWithClass(
                        "div",
                        "riskRuleElement"
                      );
                      let level = e.level;
                      if (level > 3) {
                        level = 3;
                      }
                      if (level < 1) {
                        level = 1;
                      }
                      riskRuleElement.setAttribute("criticality", level);
                      riskRuleElement.innerText = e.rule;
                      tooltipSummary.append(riskRuleElement);
                    });
                  }

                  let tooltipNavigateLink;
                  if (isSuspiciousLink) {
                    tooltipNavigateLink = createElementWithClass(
                      "div",
                      "tooltipNavigateLink"
                    );
                  }

                  if (isSuspiciousLink) {
                    tooltipInner.append(tooltipSuspectedMaliciousLinkTitle);
                  }
                  tooltipInner.append(tooltipTitle);
                  tooltipInner.append(tooltipSummary);

                  if (isSuspiciousLink) {
                    const link = createElementWithClass("div");
                    link.style.fontSize = "12px";
                    link.style.lineHeight = "15px";
                    link.style.whiteSpace = "nowrap";
                    link.style.overflow = "hidden";
                    link.style.textOverflow = "ellipsis";
                    link.style.maxWidth = "69%";
                    link.style.float = "left";

                    link.textContent = key;
                    tooltipNavigateLink.append(link);
                    const clipBoard = createElementWithClass(
                      "div",
                      "tooltipNavigateLink__link"
                    );
                    clipBoard.style.cursor = "pointer";
                    clipBoard.style.float = "left";
                    clipBoard.style.paddingLeft = "10px";
                    clipBoard.textContent = "Copy to Clipboard";

                    clipBoard.addEventListener("click", () => {
                      const el = document.createElement("textarea");
                      el.value = key;
                      el.setAttribute("readonly", "");
                      el.style.position = "absolute";
                      el.style.left = "-9999px";
                      el.style.opacity = "0";
                      document.body.appendChild(el);
                      el.select();
                      document.execCommand("copy");
                      document.body.removeChild(el);
                      clipBoard.textContent = "Copied";
                      clipBoard.style.textDecoration = "none";

                      setTimeout(() => {
                        clipBoard.textContent = "Copy to Clipboard";
                      }, 4000);
                    });

                    tooltipNavigateLink.append(clipBoard);
                    tooltipInner.append(tooltipNavigateLink);
                  }
                  tooltip.append(tooltipInner);

                  const outEvent = (event) => {
                    if (event.srcElement) {
                      let element = event.srcElement;
                      if (
                        !(
                          element.classList.contains(
                            "rfBrowextIocHighlightLink__tooltip"
                          ) ||
                          element.classList.contains(
                            "rfBrowextUrlHighlightLink__tooltip"
                          )
                        )
                      ) {
                        while (
                          element.parentElement &&
                          !(
                            element.classList.contains(
                              "rfBrowextIocHighlightLink__tooltip"
                            ) ||
                            element.classList.contains(
                              "rfBrowextUrlHighlightLink__tooltip"
                            )
                          )
                        ) {
                          element = element.parentElement;
                        }
                        const tooltipBounds = element.getBoundingClientRect();
                        const mouseX = event.clientX;
                        const mouseY = event.clientY;

                        const mouseIsInsideTooltip =
                          mouseX >= tooltipBounds.x &&
                          mouseX <= tooltipBounds.x + tooltipBounds.width &&
                          mouseY >= tooltipBounds.y &&
                          mouseY <= tooltipBounds.y + tooltipBounds.height;

                        if (!mouseIsInsideTooltip) {
                          tooltip.style.visibility = "hidden";
                        }
                      }
                    }
                  };

                  tooltip.addEventListener("mouseout", outEvent);
                  if (element.nodeName === "#document-fragment") {
                    // element is shadow dom
                    document.querySelector("body").append(tooltip); // append element to body
                  } else {
                    element.children[0].append(tooltip); // Add element to top top element instead of inside the link div
                  }
                }

                const computedStyled = getComputedStyle(e);
                let fontSize = computedStyled.fontSize;

                if (className === "rfBrowextUrlHighlightLink") {
                  let color = computedStyled.color;
                  [...e.children].forEach((child) => {
                    const childFontSize = getComputedStyle(child).fontSize;
                    if (childFontSize > fontSize) {
                      fontSize = childFontSize;
                    }
                  });
                  if (
                    color === "white" ||
                    color === "#fff" ||
                    color === "#ffffff" ||
                    color === "rgb(255, 255, 255)"
                  ) {
                    e.style.color = "black";
                  }
                  if (computedStyled.overflow === "hidden") {
                    e.style.overflow = "visible";
                  }
                  risk.style.fontSize = fontSize;
                  plupp.style.fontSize = fontSize;
                }

                let icon;

                const linkHasImage = e.querySelector("img");

                if (isSuspiciousLink && settings.disableMaliciousLinks) {
                  icon = createElementWithClass(
                    "span",
                    `${className}__disabledIcon`
                  );
                  icon.innerHTML = `
                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24">
                      <path d="M0 0h24v24H0V0z" fill="none"/>
                      <path d="M21.94 11.23C21.57 8.76 19.32 7 16.82 7h-2.87c-.52 0-.95.43-.95.95s.43.95.95.95h2.9c1.6 0 3.04 1.14 3.22 2.73.17 1.43-.64 2.69-1.85 3.22l1.4 1.4c1.63-1.02 2.64-2.91 2.32-5.02zM4.12 3.56c-.39-.39-1.02-.39-1.41 0s-.39 1.02 0 1.41l2.4 2.4c-1.94.8-3.27 2.77-3.09 5.04C2.23 15.05 4.59 17 7.23 17h2.82c.52 0 .95-.43.95-.95s-.43-.95-.95-.95H7.16c-1.63 0-3.1-1.19-3.25-2.82-.15-1.72 1.11-3.17 2.75-3.35l2.1 2.1c-.43.09-.76.46-.76.92v.1c0 .52.43.95.95.95h1.78L13 15.27V17h1.73l3.3 3.3c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L4.12 3.56zM16 11.95c0-.52-.43-.95-.95-.95h-.66l1.49 1.49c.07-.13.12-.28.12-.44v-.1z"/>
                    </svg>`;
                  if (linkHasImage) {
                    const wrapper = createElementWithClass(
                      "div",
                      `${className}__riskScoreWrapper`
                    );
                    wrapper.append(icon);
                    wrapper.append(plupp);
                    wrapper.append(risk);
                    e.append(wrapper);
                  } else {
                    e.append(icon);
                  }
                }
                if (!linkHasImage) {
                  e.append(plupp);
                  e.append(risk);
                }

                if (isSuspiciousLink && settings.disableMaliciousLinks) {
                  const bounds = e.getBoundingClientRect();
                  const svg = icon.querySelector("svg");
                  let iconSize = bounds.height >= 16 ? bounds.height : 16;
                  if (iconSize > 90) {
                    iconSize = 90;
                  }
                  if (!linkHasImage) {
                    svg.style.width = iconSize + "px";
                    svg.style.height = iconSize + "px";
                    svg.style.top = Math.floor(iconSize / 5);
                  } else {
                    const imageBounds = linkHasImage.getBoundingClientRect();
                    const wrapper = e.querySelector(
                      `.${className}__riskScoreWrapper`
                    );

                    icon.style.position = "absolute";
                    const svgBounds = svg.getBoundingClientRect();
                    e.querySelector(
                      `.${className}__riskPlupp`
                    ).style.marginLeft = svgBounds.width + "px";

                    const wrapperBounds = wrapper.getBoundingClientRect();
                    svg.style.height = wrapperBounds.height;
                    e.querySelector(
                      `.${className}__riskPlupp`
                    ).style.paddingLeft = "0px";
                    e.querySelector(`.${className}__risk`).style.paddingRight =
                      "5px";

                    wrapper.style.top =
                      Math.abs(bounds.y - imageBounds.y) + 4 + "px";
                  }

                  if (!e.getAttribute("ref-backup")) {
                    e.setAttribute("ref-backup", e.getAttribute("href"));
                  }
                  e.setAttribute("href", "javascript: void(0)");
                  e.removeAttribute("target");
                  e.removeAttribute("data-saferedirecturl");
                  e.classList.add("disabled");
                } else if (
                  isSuspiciousLink &&
                  !settings.disableMaliciousLinks
                ) {
                  const refBackup = e.getAttribute("ref-backup");
                  if (refBackup) {
                    e.setAttribute("href", refBackup);
                  }
                  e.classList.remove("disabled");
                }

                if (!tooltipAlreadyExists) {
                  positionLinkTooltip(e);
                }
              } else if (
                !doNotUpdate &&
                riskScore === 0 &&
                minimumCriticality === 0
              ) {
                e.classList.add(`${className}-highlighted`);
              }
            });
        }
      };

      const mouseOverEvent = (event) => {
        if (event.srcElement) {
          let element = event.srcElement;
          if (
            !(
              element.classList.contains("rfBrowextUrlHighlightLink") ||
              element.classList.contains("rfBrowextIocHighlightLink")
            )
          ) {
            while (
              element.parentElement &&
              !(
                element.classList.contains("rfBrowextUrlHighlightLink") ||
                element.classList.contains("rfBrowextIocHighlightLink")
              )
            ) {
              element = element.parentElement;
            }
          }

          let topParent = element.parentElement;
          while (!!topParent && !!topParent.parentElement) {
            topParent = topParent.parentElement;
          }

          if (
            topParent &&
            topParent.parentNode.nodeName === "#document-fragment"
          ) {
            // shadow root
            topParent = document.querySelector("body");
          }

          const key = element.getAttribute("key");
          const uniqueId = element.getAttribute("unique-id");
          // Only try to position if element has tooltip
          if (
            element &&
            key &&
            (topParent.querySelector(
              `.rfBrowextIocHighlightLink__tooltip[for="${key}"][unique-id="${uniqueId}"]`
            ) ||
              topParent.querySelector(
                `.rfBrowextUrlHighlightLink__tooltip[for="${key}"][unique-id="${uniqueId}"]`
              ))
          ) {
            positionLinkTooltip(element);
            let tooltip = topParent.querySelector(
              `.rfBrowextIocHighlightLink__tooltip[for="${key}"][unique-id="${uniqueId}"]`
            );
            if (!tooltip) {
              tooltip = topParent.querySelector(
                `.rfBrowextUrlHighlightLink__tooltip[for="${key}"][unique-id="${uniqueId}"]`
              );
            }
            // Hide all other tooltips first
            topParent
              .querySelectorAll(
                ".rfBrowextIocHighlightLink__tooltip, .rfBrowextUrlHighlightLink__tooltip"
              )
              .forEach((x) => (x.style.visibility = "hidden"));
            if (tooltip.querySelector(".tooltipNavigateLink__link")) {
              tooltip.querySelector(".tooltipNavigateLink__link").textContent =
                "Copy to Clipboard";
            }
            tooltip.style.visibility = "visible";
          }
        }
      };

      const mouseOutEvent = (event) => {
        if (event.srcElement) {
          let element = event.srcElement;
          if (
            !(
              element.classList.contains("rfBrowextUrlHighlightLink") ||
              element.classList.contains("rfBrowextIocHighlightLink")
            )
          ) {
            while (
              element.parentElement &&
              !(
                element.classList.contains("rfBrowextUrlHighlightLink") ||
                element.classList.contains("rfBrowextIocHighlightLink")
              )
            ) {
              element = element.parentElement;
            }
          }

          let topParent = element.parentElement;
          while (!!topParent && !!topParent.parentElement) {
            topParent = topParent.parentElement;
          }

          // handle shadow dom
          if (
            topParent &&
            topParent.parentNode.nodeName === "#document-fragment"
          ) {
            topParent = document.querySelector("body");
          }

          const key = element.getAttribute("key");
          const uniqueId = element.getAttribute("unique-id");
          // Only try to position if element has tooltip
          if (
            element &&
            key &&
            (topParent.querySelector(
              `.rfBrowextIocHighlightLink__tooltip[for="${key}"][unique-id="${uniqueId}"]`
            ) ||
              topParent.querySelector(
                `.rfBrowextUrlHighlightLink__tooltip[for="${key}"][unique-id="${uniqueId}"]`
              ))
          ) {
            let tooltip = topParent.querySelector(
              `.rfBrowextIocHighlightLink__tooltip[for="${key}"][unique-id="${uniqueId}"]`
            );
            if (!tooltip) {
              tooltip = topParent.querySelector(
                `.rfBrowextUrlHighlightLink__tooltip[for="${key}"][unique-id="${uniqueId}"]`
              );
            }

            const mouseX = event.clientX;
            const mouseY = event.clientY;
            const tooltipBounds = tooltip.getBoundingClientRect();

            const mouseIsInsideTooltip =
              mouseX >= tooltipBounds.x - 2 &&
              mouseX <= tooltipBounds.x + tooltipBounds.width + 2 &&
              mouseY >= tooltipBounds.y - 2 &&
              mouseY <= tooltipBounds.y + tooltipBounds.height + 2;

            if (!mouseIsInsideTooltip) {
              tooltip.style.visibility = "hidden";
            }
          }
        }
      };

      setHighlight(el, "rfBrowextIocHighlightLink");
      // RF-83330
      // If the highlighted element is inside a link or inside a highlighted URL we should remove the highlight box
      // before highlighting links
      // This is to avoid conflicts between IoCs and links
      if (
        regExpUtil.isUrl(key) &&
        currentSettings.disableMaliciousLinks &&
        riskScores[key] &&
        riskScores[key].riskData &&
        riskScores[key].riskData.riskScore >= 65 // This is a malicious link
      ) {
        el.querySelectorAll(`.rfBrowextIocHighlightLink[key="${key}"]`).forEach(
          (e) => {
            let iterations = 0;
            let insideLink = false;
            let parent = e.parentElement;
            while (parent) {
              // Traverse up in the DOM tree from the target element to see if it is inside a tooltip
              if (iterations > 7) {
                // To save performacne have a max iteration count
                parent = null;
              } else if (parent.nodeName === "A") {
                insideLink = true;
                parent = null;
              } else {
                parent = parent.parentElement;
                iterations++;
              }
            }
            if (insideLink) {
              e.outerHTML = e.querySelector(
                ".rfBrowextIocHighlightLink__title"
              ).textContent;
            }
          }
        );
      }
      setHighlight(el, "rfBrowextUrlHighlightLink");

      el.querySelectorAll(".rfBrowextUrlHighlightLink").forEach((e) => {
        if (
          e.getAttribute("risk-score") &&
          Number(e.getAttribute("risk-score")) > 0
        ) {
          e.classList.add("rfBrowextUrlHighlightLink-highlighted");
          if (!e.hasRfMouseOverEventHandler) {
            e.hasRfMouseOverEventHandler = true;
            e.addEventListener("mouseover", mouseOverEvent);
          }
          if (!e.hasRfMouseOutEventHandler) {
            e.hasRfMouseOutEventHandler = true;
            e.addEventListener("mouseout", mouseOutEvent);
          }
        }
      });
      el.querySelectorAll(".rfBrowextIocHighlightLink").forEach((e) => {
        let link = e.getAttribute("link");
        if (link && link.includes("?")) {
          link = link + "&t_origin=BrowserExtensionChip";
        } else {
          link = link + "?t_origin=BrowserExtensionChip";
        }

        const event = (ev) => {
          ev.preventDefault();

          // User clicks a highlight box
          // Log this activity timestamp
          chrome.storage.local.set({ lastUsage: Date.now() });

          let element = ev.srcElement;
          while (!element.classList.contains("rfBrowextIocHighlightLink")) {
            element = element.parentNode;
          }
          if (
            // If element does not have any of these classes then it is not highlighted and should not handle click events
            !(
              element.classList.contains(
                "rfBrowextIocHighlightLink-highlighted"
              ) ||
              element.classList.contains(
                "rfBrowextUrlHighlightLink-highlighted"
              )
            )
          ) {
            return;
          }

          // metaKey = Cmd-key on Mac
          // ctrlKey = Ctrl-key on Windows
          if (ev.metaKey || ev.ctrlKey) {
            const key = element.getAttribute("key");
            const keyIsUrl =
              key.startsWith("http://") || key.startsWith("https://");
            const parentIsALink =
              element.parentElement &&
              element.parentElement.nodeName.toLowerCase() === "a";

            if (parentIsALink) {
              let href = element.parentElement.getAttribute("href");
              window.open(href, "_blank");
            } else if (keyIsUrl) {
              window.open(key, "_blank");
            }
          } else {
            window.open(link, "_blank");
          }
        };
        if (!freemiumAccount) {
          if (!e.hasRfClickEventHandler) {
            e.addEventListener("click", event);
            e.hasRfClickEventHandler = true;
          }
        } else {
          e.classList.add("nonClickable");
          if (!e.hasRfClickEventHandler) {
            e.addEventListener("click", (ev) => ev.preventDefault());
          }
        }
        if (!e.hasRfMouseOverEventHandler) {
          e.hasRfMouseOverEventHandler = true;
          e.addEventListener("mouseover", mouseOverEvent);
        }
        if (!e.hasRfMouseOutEventHandler) {
          e.hasRfMouseOutEventHandler = true;
          e.addEventListener("mouseout", mouseOutEvent);
        }
      });
    };

    const setRiskDataForShadowElements = (el, key, settings) => {
      const query = ELEMENTS_TO_SKIP.reduce(
        (total, current) => `${total}:not(${current})`,
        "*"
      );
      el.querySelectorAll(query).forEach((e) => {
        if (e.shadowRoot) {
          setRiskData(e.shadowRoot, key, settings);
          setRiskDataForShadowElements(e.shadowRoot, key, settings);
        }
      });
    };

    userSettings.getUserSettings().then((settings) => {
      setRiskData(element, key, settings);
      setRiskDataForShadowElements(element, key, settings);

      // Remove highlight boxes that we dont have risk score data for (unless minimum criticality is 0)
      if (minimumCriticality > 0) {
        element.querySelectorAll(`.rfBrowextIocHighlightLink`).forEach((e) => {
          const key = e.getAttribute("key");
          if (!riskScores[key]) {
            e.outerHTML = e.querySelector(
              ".rfBrowextIocHighlightLink__title"
            ).textContent;
          }
        });
      }
    });
  };

  const keys = Object.keys(riskScores).sort((a, b) => b.length - a.length);

  // UPDATE: 14/11/2023 - Removed the following solution because it caused the problem RFPD-34999
  // Still keeping the solution but commented out in case it will be needed again someday

  // This is to fix an issue where domains and URLs conflict
  // See RF-65785
  //keys.forEach(key => {
  //  if (
  //    riskScores[key].riskData.riskScore === 0 && !(key.includes('">')) ||
  //    riskScores[key].riskData.redirect && riskScores[key].riskData.redirect.risk && riskScores[key].riskData.redirect.risk.score === 0 && !(key.includes('">'))
  //  ) {
  //    try {
  //      document.querySelectorAll(`.rfBrowextIocHighlightLink[key="${key}"]`).forEach(e => {
  //        let alternativeKey = keys.find(x => x !== key && key.includes(x));
  //
  //        if (!alternativeKey && riskScores[key].riskData.redirect && riskScores[key].riskData.redirect.redirectsTo) {
  //          alternativeKey = keys.find(x => x !== riskScores[key].riskData.redirect.redirectsTo && riskScores[key].riskData.redirect.redirectsTo.includes(x));
  //        }
  //
  //        if (alternativeKey && riskScores[alternativeKey].riskData.riskScore > 0) {
  //          const parent = e.parentElement;
  //          if (parent) {
  //            e.outerHTML = e.querySelector('.rfBrowextIocHighlightLink__title').textContent;
  //
  //            const uniqueId = Math.round(Math.random() * 10000000000000);
  //            const ioc = request.iocs.find(x => x.name === alternativeKey) || riskScores[key];
  //            let markup =
  //              `<div class=\"rfBrowextIocHighlightLink\" unique-id=\"${uniqueId}\" key=\"${alternativeKey}\" link=\"${ioc.link}\" \>` +
  //              `<span class="rfBrowextIocHighlightLink__title">${alternativeKey}</span>` +
  //              `</div>`;
  //
  //            // Fix for https://recordedfuture.atlassian.net/browse/RFPD-18583
  //            // Fixed an issue where BE would try to highlight the IoC found in the
  //            // link attribute of a highlight element, which injected HTML into the page
  //            // as text
  //            let innerHTML = parent.innerHTML;
  //            // TODO maybe clean innerHTML here?
  //
  //            // Similar fix to prevent that .rfBrowextIocHighlightLink elements are nested inside each other
  //            const RF_LINKPLACEHOLDER = 'RF_HIGHLIGHT_BOX_PLACEHOLDER';
  //            const rfLinkRegex = new RegExp('<\s*(div class="rfBrowextIocHighlightLink)[^>]*>((.|\n)*?)<\s*/\s*div>', 'gm');
  //            const containsRFHighlightBoxes = rfLinkRegex.test(e.innerHTML);
  //            let rfLinks;
  //            if (containsRFHighlightBoxes) {
  //              rfLinks = innerHTML.match(rfLinkRegex);
  //              innerHTML = innerHTML.replace(rfLinkRegex, RF_LINKPLACEHOLDER);
  //            }
  //
  //            const LINK_PLACEHOLDER = 'RF_LINK_PLACEHOLDER';
  //            const linkAttributeRegex = new RegExp('link="(.*)" ', 'g');
  //            const containsLinkTags = linkAttributeRegex.test(innerHTML);
  //            let tags;
  //            if (containsLinkTags) {
  //              tags = innerHTML.match(linkAttributeRegex);
  //              innerHTML = innerHTML.replace(linkAttributeRegex, LINK_PLACEHOLDER);
  //            }
  //            innerHTML = innerHTML.replaceAll(new RegExp(`(?<!key="|idn:|key="http://|key="https://)(${alternativeKey})`, 'g'), markup);
  //            if (containsLinkTags) {
  //              let index = 0;
  //              innerHTML = innerHTML.replace(new RegExp(LINK_PLACEHOLDER, 'gm'), (...args) => {
  //                const tag = tags[index];
  //                index++;
  //                return tag;
  //              });
  //            }
  //            if (containsRFHighlightBoxes) {
  //              // Add link elements that have been saved from before and therefore remain unaffected
  //              let index = 0;
  //              innerHTML = innerHTML.replace(new RegExp(RF_LINKPLACEHOLDER, 'gm'), (...args) => {
  //                const tag = rfLinks[index];
  //                index++;
  //                return tag;
  //              });
  //            }
  //
  //            parent.innerHTML = innerHTML;
  //          }
  //        }
  //      });
  //    } catch (err) {
  //      console.error(err);
  //    }
  //  }
  //});

  keys.forEach((key) => setRiskAttributesInElement(document, key));

  const containsFrames = document.body.innerHTML.includes("<frame");
  if (containsFrames) {
    document.querySelectorAll("frame").forEach((frame) => {
      keys.forEach((key) =>
        setRiskAttributesInElement(frame.contentDocument, key)
      );
    });
  }
  if (iframeDomain) {
    const iframes = getAllIframes();
    iframes.forEach((iframe) => {
      const body = getIframeBody(iframe);
      if (body) {
        keys.forEach((key) =>
          setRiskAttributesInElement(body, key)
        );
      }
    });
  }
  fetchIocsInProgress = false;
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "checkIfPageIsAllowed") {
    // Check if the user has already manually enabled highlighting on this page,
    // overriding the max limit
    const isAllowed = overrideCache.includes(window.location.href);
    sendResponse(isAllowed);
  } else if (request.action === "setHighlighting") {
    if (request.value) {
      if (request.entities) cachedEntities = request.entities;

      const entitiesAsList = cachedEntities.matches
        ? cachedEntities.matches.reduce(
            (total, current) => [...total, ...current.iocs],
            []
          )
        : cachedEntities;
      let overrideMaxLevelBlock = request.overrideMaxLevelBlock;

      if (overrideMaxLevelBlock) {
        if (!overrideCache.includes(window.location.href)) {
          overrideCache.push(window.location.href);
        }
      }

      if (
        entitiesAsList.length <=
          config.MAX_AMOUNT_OF_ENTITIES_FOR_HIGHLIGHTING ||
        overrideMaxLevelBlock
      ) {
        if (overrideMaxLevelBlock) {
          if (request.ignoreTooManyHits) {
            highlightIocs(
              cachedEntities,
              true,
              currentUrl,
              false,
              false,
              overrideMaxLevelBlock
            );
          } else {
            highlightIocs(
              cachedEntities,
              true,
              currentUrl,
              false,
              false,
              overrideMaxLevelBlock,
              () => {
                if (cachedEntities) {
                  const entitiesAsList = cachedEntities.matches
                    ? cachedEntities.matches.reduce(
                        (total, current) => [...total, ...current.iocs],
                        []
                      )
                    : cachedEntities;
                  fetchedIocRiskScoresResponse({
                    iocs: entitiesAsList,
                  });
                }
              }
            );
          }
        } else {
          highlightIocs(
            cachedEntities,
            true,
            currentUrl,
            false,
            false,
            overrideMaxLevelBlock
          );
        }
      }
    } else {
      if (overrideCache.includes(window.location.href)) {
        overrideCache = overrideCache.filter((x) => x !== window.location.href);
      }
      removeHighlightBoxes();
    }
  } else if (request.action === "setUrlHighlighting") {
    if (request.value) {
      const links = cachedLinks
        ? cachedLinks
        : cachedEntities.filter((x) => x.fromLink);
      highlightUrls(links);
    } else {
      removeUrlHighlightBoxes();
    }
  } else if (request.action === "setHighlightingCriticality") {
    minimumCriticality = request.criticality;
    removeHighlightBoxes();
    setTimeout(() => {
      if (request.ignoreTooManyHits) {
        highlightIocs(cachedEntities, true, currentUrl, true);
      } else {
        highlightIocs(cachedEntities, true, currentUrl, false);
      }
    }, 400);
  } else if (request.action === "signedIn") {
    freemiumAccount = request.scope.includes("FreeData");
  } else if (request.action === "fetchedIocRiskScores") {
    bkgPort.postMessage({ fetchRiskScoreCache: true });
    fetchedIocRiskScoresResponse(request);
  } else if (request.action === "fetchedRiskScoreCache") {
    riskScoreCache = request.cache;
  }
});

const getClipPolygonPath = (tooltipBounds, screenBounds, linkBounds) => {
  const response = {
    clipPath: undefined,
    paddingKey: undefined,
    paddingValue: undefined,
    toolTipLeft: undefined,
    toolTipTop: undefined,
  };

  const TRIANGLE_WIDTH = 10;
  response.paddingValue = TRIANGLE_WIDTH * 2.4;

  // Adjust screen width based on margin
  let screenWidth = screenBounds.width;
  if (screenBounds.right > screenWidth) {
    screenWidth = screenBounds.right + screenBounds.left;
  }
  // INITIAL VALUES
  response.toolTipLeft =
    linkBounds.x + linkBounds.width / 2 - tooltipBounds.width / 2;
  response.toolTipTop = linkBounds.y - tooltipBounds.height;

  let arrowXMiddle = tooltipBounds.width / 2;
  if (tooltipBounds.width + response.toolTipLeft > screenWidth) {
    // Tooltip clips at the right side of the screen edge
    response.toolTipLeft = screenWidth - tooltipBounds.width;
    arrowXMiddle = tooltipBounds.width - linkBounds.width / 2;
  } else if (response.toolTipLeft <= 0) {
    response.toolTipLeft = 0;
    arrowXMiddle = linkBounds.right - linkBounds.right / 2;
  }

  if (response.toolTipTop < 0) {
    // Tooltip is too high up, will be clipped at top, show below link instead
    response.toolTipTop = linkBounds.y + linkBounds.height;
    response.paddingKey = "paddingTop";
    response.clipPath = `polygon(
        0 ${TRIANGLE_WIDTH}px,
        ${arrowXMiddle - TRIANGLE_WIDTH}px ${TRIANGLE_WIDTH}px,
        ${arrowXMiddle}px 0,
        ${arrowXMiddle + TRIANGLE_WIDTH}px ${TRIANGLE_WIDTH}px,
        100% ${TRIANGLE_WIDTH}px,
        100% 100%,
        0 100%
      )`;
  } else {
    // Tooltip fits above link
    response.paddingKey = "paddingBottom";
    response.clipPath = `polygon(
        0 0,
        100% 0,
        100% ${tooltipBounds.height - TRIANGLE_WIDTH}px,
        ${arrowXMiddle + TRIANGLE_WIDTH}px ${
      tooltipBounds.height - TRIANGLE_WIDTH
    }px,
        ${arrowXMiddle}px 100%,
        ${arrowXMiddle - TRIANGLE_WIDTH}px ${
      tooltipBounds.height - TRIANGLE_WIDTH
    }px,
        0 ${tooltipBounds.height - TRIANGLE_WIDTH}px
      )`;
  }
  return response;
};

const positionLinkTooltip = (linkElement) => {
  const key = linkElement.getAttribute("key");
  const uniqueId = linkElement.getAttribute("unique-id");
  let topParent = linkElement.parentElement;
  while (topParent.parentElement) {
    topParent = topParent.parentElement;
  }

  if (topParent && topParent.parentNode.nodeName === "#document-fragment") {
    // shadow root
    topParent = document.querySelector("body");
  }

  const screenBounds = topParent.getBoundingClientRect(); // bounds of top child element which is usually the html tag itself
  const linkBounds = linkElement.getBoundingClientRect();

  let tooltip = topParent.querySelector(
    `.rfBrowextUrlHighlightLink__tooltip[for="${key}"][unique-id="${uniqueId}"]`
  );
  if (!tooltip) {
    tooltip = topParent.querySelector(
      `.rfBrowextIocHighlightLink__tooltip[for="${key}"][unique-id="${uniqueId}"]`
    );
  }
  const tooltipBounds = tooltip.children[0].getBoundingClientRect();

  const positionParameters = getClipPolygonPath(
    tooltipBounds,
    screenBounds,
    linkBounds
  );

  tooltip.children[0].style[positionParameters.paddingKey] =
    positionParameters.paddingValue + "px";
  tooltip.children[0].style.clipPath = positionParameters.clipPath;
  tooltip.style.top = positionParameters.toolTipTop + "px";
  tooltip.style.left = positionParameters.toolTipLeft + "px";
};

export default {
  highlightIocs,
  highlightUrls,
  removeHighlightBoxes,
  removeUrlHighlightBoxes,
  removeHighlightStyling,
  cacheIocs,
};
