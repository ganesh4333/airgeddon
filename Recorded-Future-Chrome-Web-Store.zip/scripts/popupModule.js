import config from './configModule.js';
import eventLog from './eventLogModule.js';
import regExpUtil from './regExpUtilModule.js';
import safeResponse from './safeResponseModule.js';
import userSettings from './userSettingsModule.js';
import browserModule from './browserModule.js';
import helpers from './helpers.js';
import alexa1000 from './alexa1000.js';

window.printLog = eventLog.printLog;
window.printLogAsString = eventLog.printLogAsString;
window.printErrorCodes = eventLog.printErrorCodes;
window.getSimplifiedErrorCodeLog = eventLog.getSimplifiedErrorCodeLog;
window.clearRedirectUrlCache = () => {
  chrome.storage.local.get(['RFBrowserExtensionRedirectCache'], items => {
    let newCache = {};
    newCache['RFBrowserExtensionRedirectCache'] = null;
    chrome.storage.local.set(newCache);
  });
};

let timers = [];

function startTimer (id) {
  console.log('Start timer for '+ id);
  if (timers.find(x => x.id === id)) {
    const currentItem = timers.find(x => x.id === id);
    currentItem.currentTimestamp = Date.now();
  } else {
    timers.push({
      currentTimestamp: Date.now(),
      id
    });
  }
}

function endTimer (id) {
  const now = Date.now();

  const timer = timers.find(x => x.id === id);

  if (timer) {
    const diff = (now - timer.currentTimestamp) / 1000;
    console.log('Time taken for ' + id + ': ' + diff + 's');
  }
}

var popupCodeJustForSafariToWork = popupCodeJustForSafariToWork || {};

let modules;

let userClickedExportButton = false;
let userClickedSettingsButton = false;
let isPdf = false;
let cachedIocResult;
let ignoreTooManyHits = false;
let showAdvancedSettings = false;
let forceShowUrlTab = false;
let userClickedUrlTabEnableButton = false;
let currentSelectedTab = {
  index: 0,
  label: 'all'
};
let keepMenuOpen = false;
let currentIocs = null;
let pageContainsTooManyEntitiesForHighlighting = false;
let showTooManyEntitiesForHighlightingMessage = false;
let isLocalFile;

let urlScanIsInProgress = false;

let userHoveringTooltip = false;

const isFirefox = typeof InstallTrigger !== 'undefined';
let showNewFeatureIntro;
let hasSeenDomainAbuseAlertsIntro

(async () => {
  hasSeenDomainAbuseAlertsIntro = await userSettings.getSettingFromStorageByName('hasSeenDomainAbuseAlertsIntro');
  showNewFeatureIntro = !hasSeenDomainAbuseAlertsIntro && !isFirefox;
})();

const toggleNotificationsToggle = (enabled) => {
  if (enabled) {
    document.querySelector('#notifications-toggle .switch').classList.add('active');
    document.querySelectorAll('.menuToggle.alertType').forEach(x => {
      x.classList.remove('disabled');
    });
  } else {
    document.querySelector('#notifications-toggle .switch').classList.remove('active');
    document.querySelectorAll('.menuToggle.alertType').forEach(x => {
      x.classList.add('disabled');
    });
  }
}

let userHasGrantedNotificationsPermission = false;
chrome.storage.local.get(['userHasGrantedNotificationsPermission'], (items) => {
  const allowed = items.userHasGrantedNotificationsPermission;
  if (allowed === true) { // First check local storage
    userHasGrantedNotificationsPermission = true;
  } else if (allowed === false) { // Flag exists in storage but is false
    userHasGrantedNotificationsPermission = false;
  } else { // If not there, set to true as default
    userHasGrantedNotificationsPermission = true;
  }
  toggleNotificationsToggle(userHasGrantedNotificationsPermission);
});

(function () {
  'use strict';

  // If the extension is currently exporting in the background, update the UI upon open so that the loader is shown immediately
  chrome.runtime.sendMessage({ action: 'getExportStatus' }, status => {
    if (status) {
      document.getElementById('exportButton').classList.add('loading');
    } else {
      document.getElementById('exportButton').classList.remove('loading');
    }
  });

  let fullAccessList;
  chrome.runtime.sendMessage({ action: 'getFullAccessList' }, resp => {
    fullAccessList = resp;
    //console.log('fullAccessList', fullAccessList);
  });

  let riskScoreCache;
  let iocsCache;

  // The following snippet is inspired by a workaround that can be ound here:
  // https://stackoverflow.com/questions/56500742/why-is-my-google-chrome-extensions-popup-ui-laggy-on-external-monitors-but-not/64113061#64113061
  // It is used to fix an error when using an external monitor with a Mac
  // Info on the error can be found here: https://bugs.chromium.org/p/chromium/issues/detail?id=971701
  if (
    window.screenLeft < 0 ||
    window.screenTop < 0 ||
    window.screenLeft > window.screen.width ||
    window.screenTop > window.screen.height
  ) {
    chrome.runtime.getPlatformInfo((data) => {
      if (data.os === "mac") {
        const fontStyling = new CSSStyleSheet();
        fontStyling.insertRule(`
          @keyframes draw {
            0% {
              opacity: 1;
            }
            100% {
              opacity: .99;
            }
          }
        `);
        fontStyling.insertRule(`
          html {
            animation: draw 1s linear infinite;
          }
        `);
        document.adoptedStyleSheets = [
          ...document.adoptedStyleSheets,
          fontStyling,
        ];
      }
    });
  }

  // hard-code localFileAccessAllowed to false, because since migrating to MV3 pdfjs does no
  // longer work on local pdf files. So local pdf-file scanning should never happen even if
  // isAllowedFileSchemeAccess is manually turned on by the user
  let localFileAccessAllowed = false;
  /* chrome.extension.isAllowedFileSchemeAccess(isAllowedAccess => {
    localFileAccessAllowed = isAllowedAccess;
  }); */

  let userHasGrantedDownloadsPermission = false;
  let currentTab;
  let currentPageHasAllowedHighlightingDespiteExceedingEntityLimit = false;

  function checkIfPageHasAllowedHighlighting() {
    if (currentTab) {
      // Check if the user previously allowed highlighting on this page, overriding the max limit
      chrome.tabs.sendMessage(currentTab.id, {action: 'checkIfPageIsAllowed'}, resp => {
        if (resp) {
          hideTooManyEntitiesForHighlightingMessage();
        }
        currentPageHasAllowedHighlightingDespiteExceedingEntityLimit = resp;
      });
    }
  }

  chrome.tabs.query({active: true, currentWindow: true}, async tabs => {
    if (tabs.length > 0 && tabs[0]) {
      currentTab = tabs[0];
      await handleIfPdf();
      checkIfPageHasAllowedHighlighting();
      chrome.permissions.contains({
        permissions: ['downloads'],
        origins: ['http://*/*', 'https://*/*']
      }, result => {
        if (result) { // The extension has the permission
          userHasGrantedDownloadsPermission = true;
          //document.querySelector('.exportButtonTooltip').classList.add('hidden');
        }
      });
    }
  });

  function showTooManyEntitiesMessage() {
    clearIocList();
    hideExportButton();
    hideScanUrlsButton();
    hideHighlightToggle();
    document.getElementById('tooManyEntities').classList.remove('hidden');
    document.getElementById('new-feature-intro-box').style.display = 'none';
    document.querySelector('body').style.minHeight = '200px';
    chrome.runtime.sendMessage({ action: 'setDisabledIcon', tabId: currentTab.id });
    document.getElementById('loadingIndicator').classList.add('hidden');
  }

  function sandboxTimerProgressHandler(response) {
    urlScanIsInProgress = true;
    document.getElementById('scanUrlsButton').classList.add('disabled');

    if (document.getElementById('loader').classList.contains('hidden')) {
      document.getElementById('sandboxStatus').classList.remove('hidden');
      document.getElementById('sandboxStatus').classList.remove('done');
      document.getElementById('sandboxStatus').classList.add('progress');
      document.querySelector('#ioc-list').style.maxHeight = '440px';
      document.querySelector('.tabs__content-wrapper__outer').style.maxHeight = '390px';
      document.querySelectorAll('.tab__content ul').forEach(x => x.style.maxHeight = '350px');

      if (response.countdownNumber === 0) {
        document.querySelector('#sandboxStatus #innerText').innerHTML = `<img src="../images/loading.gif" alt=""><div>Finishing Sandbox reports ...</div>`;
      } else {
        let minutes = Math.floor(response.countdownNumber / 60);
        let seconds = Math.floor(response.countdownNumber % 60);
        if (minutes < 10) minutes = `0${minutes}`;
        if (seconds < 10) seconds = `0${seconds}`;

        let timeLeftAsString = `${minutes}:${seconds}`;
        if (response.sandBoxSubmissions.length === 1) {
          document.querySelector('#sandboxStatus #innerText').innerHTML = `<img src="../images/loading.gif" alt=""><div>1 URL is being scanned in the Sandbox. Time left ${timeLeftAsString}</div>`;
        } else if (response.sandBoxSubmissions.length > 1) {
          document.querySelector('#sandboxStatus #innerText').innerHTML = `<img src="../images/loading.gif" alt=""><div>${response.sandBoxSubmissions.length} URLs are being scanned in the Sandbox. Time left ${timeLeftAsString}</div>`;
        }
      }
    }
  }

  const getURLsThatAreNotWhiteListed = () => {
    return new Promise(resolve => {
      const urlsFromList = [
        ...([...document.querySelectorAll('.tab__content#url ul li')].map(x => x.getAttribute('data-entity'))),
        ...([...document.querySelectorAll('.redirectLink')].map(x => x.innerText))
      ];

      chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'getLinkUrls' }, urlsFromLinks => {
          let urls = [...urlsFromList, ...urlsFromLinks];
          urls = urls.filter(helpers.onlyUnique);
          urls = urls.filter(x => {
            const url = new URL(x);
            if (alexa1000.some(x => helpers.domainsAreSame(x, url.host))) {
              return false;
            } else {
              return true;
            }
          });
          resolve(urls);
        });
      });
    });
  }

  async function sandboxTimerCompletedHandler(response = undefined) {
    setTimeout(async () => {
      document.getElementById('sandboxStatus').classList.remove('hidden');
      document.querySelector('.tabs__content-wrapper__outer').style.maxHeight = '390px';
      document.querySelectorAll('.tab__content ul').forEach(x => x.style.maxHeight = '350px');
      urlScanIsInProgress = false;

      const storage = await browserModule.getStorage();
      const urlsThatAreNotWhiteListed = await getURLsThatAreNotWhiteListed();
      const settings = await userSettings.getUserSettings();

      if (hasMalwareSandboxPermission && storage.scope && storage.scope.includes('Modules') && urlsThatAreNotWhiteListed.length > 0 && settings.entityTypesToShow.url) {
        document.getElementById('scanUrlsButton').classList.remove('disabled');
      } else {
        document.getElementById('scanUrlsButton').classList.add('disabled');
      }

      document.getElementById('sandboxStatus').classList.remove('progress');
      document.getElementById('sandboxStatus').classList.add('done');

      document.querySelector('#sandboxStatus #innerText').innerText = '';

      const box1 = document.createElement('div');
      box1.innerText = 'URL scan is finished. Find your report';
      const box2 = document.createElement('div');
      box2.classList.add('blueLink');
      box2.innerHTML = ` in the Sandbox`;

      box2.addEventListener('click', () => {
        _trackAction({action: 'BrowserExtensionUserClickedSandboxReportsLink'});
        browserModule.sandboxLink();
      });

      const closeButton = document.createElement('button');
      closeButton.id = "sandboxCompleteCloseButton";
      closeButton.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24">
        <path d="M18.3 5.71c-.39-.39-1.02-.39-1.41 0L12 10.59 7.11 5.7c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L10.59 12 5.7 16.89c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0L12 13.41l4.89 4.89c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L13.41 12l4.89-4.89c.38-.38.38-1.02 0-1.4z"/>
      </svg>`;
      closeButton.addEventListener('click', () => {
        document.getElementById('sandboxStatus').classList.add('hidden');
        chrome.runtime.sendMessage({ action: 'sandboxCompletedDismissed' });
        _trackAction({action: 'BrowserExtensionSandboxCompletedDismissed'});
      });

      document.querySelector('#sandboxStatus #innerText').appendChild(box1);
      document.querySelector('#sandboxStatus #innerText').appendChild(box2);
      document.querySelector('#sandboxStatus #innerText').appendChild(closeButton);
    }, 200);
  }

  document.getElementById('new-feature-intro-box').style.display = 'none';
  document.querySelector('body').style.minHeight = '330px';

  if (typeof InstallTrigger !== 'undefined') { // firefox
    browser.runtime.onMessage.addListener((request) => {
      if (request.action === 'sendRiskScoresFromBackgroundToPopup') {
        handleRiskScoresFromBackground(request);
      } else if (request.action === 'getEntitiesResponseToPopup') {
        createPopupHTML(request.msg);
      } else if (request.action === 'tooManyEntities') {
        cachedIocResult = request.entities;
        showTooManyEntitiesMessage();
      } else if (request.action === 'sandboxTimerProgress') {
        sandboxTimerProgressHandler(request);
      } else if (request.action === 'sandboxTimerCompleted') {
        sandboxTimerCompletedHandler(request);
      } else if (request.action === 'listCreationError') {
        document.getElementById('exportPopupErrorMessage').innerText = 'Something went wrong';
      } else if (request.action === 'listCreated') {
        document.getElementById('exportPopupBox').style.display = 'none';
        document.getElementById('popupBoxOverlay').style.display = 'none';
        document.getElementById('exportPopupBoxLoadingOverlay').style.display = 'none';
      } else if (request.action === 'exportCompleted') {
        if (request.timeout) {
          handleExportTimeout();
        } else {
          document.getElementById('exportButton').classList.remove('loading');
        }
      }
    });
  } else { // chrome
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'sendRiskScoresFromBackgroundToPopup') {
        handleRiskScoresFromBackground(request);
      } else if (request.action === 'sandboxTimerProgress') {
        sandboxTimerProgressHandler(request);
      } else if (request.action === 'sandboxTimerCompleted') {
        sandboxTimerCompletedHandler(request);
      } else if (request.action === 'listCreationError') {
        document.getElementById('exportPopupErrorMessage').innerText = 'Something went wrong';
      } else if (request.action === 'listCreated') {
        document.getElementById('exportPopupBox').style.display = 'none';
        document.getElementById('popupBoxOverlay').style.display = 'none';
        document.getElementById('exportPopupBoxLoadingOverlay').style.display = 'none';
      } else if (request.action === 'exportCompleted') {
        if (request.timeout) {
          handleExportTimeout();
        } else {
          document.getElementById('exportButton').classList.remove('loading');
        }
      }
    });
  }

  function handleExportTimeout() {
    document.getElementById('exportButton').classList.add('failed');
    document.querySelector('#exportLoader span').innerText = 'Export timed out';
    setTimeout(() => {
      document.getElementById('exportButton').classList.remove('loading');
      document.getElementById('exportButton').classList.remove('failed');
      document.querySelector('#exportLoader span').innerText = 'Export as CSV';
    }, 5000);
  }

  function handleRiskScoresFromBackground(request) {
    // TODO make a check here to see if the entities have been updated, if not do not redraw, this is to avoid
    // unnecessary flickering
    if (currentTab) {
      if (currentTab.id === request.tabId) {
        redrawUi(request, currentTab);
      }
    }
  }

  function arraysEqual(a, b) {
    return a && b &&
      a.length === b.length &&
      a.every(x => b.includes(x)) &&
      b.every(x => a.includes(x));
  }

  document.body.addEventListener('click', ev => {
    if (userClickedSettingsButton || userClickedExportButton) {
      return;
    }
    const closeIfOutsideOfElements = (ev, menuToClose, button, closeCallback = null) => {
      const menuIsOpen = !menuToClose.classList.contains('hidden');
      let mouseCursorInsideMenu = false;
      let mouseCursorInsideButton = false;

      const menuToCloseBbox = menuToClose.getBoundingClientRect();
      const buttonBbox = button.getBoundingClientRect();

      if (
        ev.clientX >= menuToCloseBbox.x &&
        ev.clientX <= (menuToCloseBbox.x + menuToCloseBbox.width) &&
        ev.clientY >= menuToCloseBbox.y &&
        ev.clientY <= (menuToCloseBbox.y + menuToCloseBbox.height)
      ) {
        mouseCursorInsideMenu = true;
      }
      if (
        ev.clientX >= buttonBbox.x &&
        ev.clientX <= (buttonBbox.x + buttonBbox.width) &&
        ev.clientY >= buttonBbox.y &&
        ev.clientY <= (buttonBbox.y + buttonBbox.height)
      ) {
        mouseCursorInsideButton = true;
      }
      if (menuIsOpen && !mouseCursorInsideMenu && !mouseCursorInsideButton) {
        if (closeCallback) {
          closeCallback();
        } else {
          menuToClose.classList.add('hidden');
        }
      }
    }
    closeIfOutsideOfElements(
      ev,
      document.getElementById('exportMenu'),
      document.getElementById('exportButton'),
    );
    closeIfOutsideOfElements(
      ev,
      document.getElementById('mainMenu'),
      document.getElementById('elipsis-icon'),
      () => {
        keepMenuOpen = false;
        hideDropDown();
      }
    );
  });

  function redrawUi(request, tab) {
    const url = new URL(tab.url);
    isLocalFile = url.href.startsWith('file://');
    const isFirefox = typeof InstallTrigger !== 'undefined';
    const isChrome = !isFirefox;

    if (!localFileAccessAllowed && isChrome && isLocalFile) {
      return;
    }

    riskScoreCache = request.riskScores;
    const newIocNames = request.iocs.map(x => x.name);
    let performRedraw = true;

    if (iocsCache) {
      if (arraysEqual(newIocNames, iocsCache)) {
        performRedraw = false;
      }
    }
    iocsCache = newIocNames;

    if (!performRedraw && !request.forcePopupRedraw && !isPdf) {
      return;
    }

    const iocsResult = {
      matches: [{
        label: 'Domain', supportLink: 'https://support.recordedfuture.com/hc/en-us/articles/115003793388-Domain-Risk-Rules', supportTitle: 'Domain risk rules', type: 'idns', iocs: []
      }, {
        label: 'IP Address', supportLink: 'https://support.recordedfuture.com/hc/en-us/articles/115000894448-IP-Address-Risk-Rules', supportTitle: 'IP Address risk rules', type: 'ips', iocs: []
      }, {
        label: 'Hash', supportLink: 'https://support.recordedfuture.com/hc/en-us/articles/115000846167-Hash-Risk-Rules', supportTitle: 'Hash risk rules', type: 'hashes', iocs: []
      }, {
        label: 'Vulnerability', supportLink: 'https://support.recordedfuture.com/hc/en-us/articles/115000894468-Vulnerability-Risk-Rules', supportTitle: 'Vulnerability risk rules', type: 'cves', iocs: []
      }, {
        label: 'URL', supportLink: 'https://support.recordedfuture.com/hc/en-us/articles/115010052768', supportTitle: 'URL risk rules', type: 'urls', iocs: []
      }]
    };

    request.iocs.forEach(ioc => {
      const name = ioc.name;
      let item;
      if (regExpUtil.isCve(name)) {
        item = iocsResult.matches.find(x => x.type === 'cves');
        ioc.type = 'cves';
      } else if (regExpUtil.isIPAddress(name)) {
        item = iocsResult.matches.find(x => x.type === 'ips');
        ioc.type = 'ips';
      } else if (regExpUtil.isIdn(name)) {
        item = iocsResult.matches.find(x => x.type === 'idns');
        ioc.type = 'idns';
      } else if (regExpUtil.isUrl(name)) {
        item = iocsResult.matches.find(x => x.type === 'urls');
        ioc.type = 'urls';
      } else if (regExpUtil.isHash(name)) {
        item = iocsResult.matches.find(x => x.type === 'hashes');
        ioc.type = 'hashes';
      }
      if (item) {
        item.iocs.push(ioc);
      }
    });

    // Fix for a specific bug where a URL containing a CVE would be interpreted as a CVE
    const cves = iocsResult.matches.find(x => x.type === 'cves');
    if (cves) {
      cves.iocs = cves.iocs.filter(x => !x.name.startsWith('http'));
    }
    browserModule.getToken(null, '002').then((token) => {
      if (token !== undefined) {
        let userLoadAllDespiteAmountExceedsLimit = request.userLoadAllDespiteAmountExceedsLimit || false;

        _createPopupHTML({token, iocsResult}, true, request.forcePopupRedraw, userLoadAllDespiteAmountExceedsLimit, () => {
          setTimeout(() => {
            if (currentSelectedTab.label === 'url' && !document.querySelector('.tab__header.url').classList.contains('disabled')) {
              // Fix for bug RF-80500
              // If user activates URL from the "new URL feature" enable-button
              // URL should be properly selected after the popup UI redraws    
              const tabHeader = document.querySelector('.tab__header.url');
              const tabFooter = document.querySelector('.tab__footer.url');

              document.querySelector('.tabs__header-wrapper').querySelectorAll('.tab__header')
                .forEach(tab => tab.classList.remove('active'));
              document.querySelector('.tabs__footer-wrapper').querySelectorAll('.tab__footer')
                .forEach(tab => tab.classList.remove('active') && tab.classList.add('hidden'));
              tabHeader.classList.add('active');
              tabFooter.classList.add('active');

              let number = Number(document.querySelector('.tab__header.url').getAttribute('data-tab-target'));
              currentSelectedTab = {
                index: number,
                label: 'url'
              };
              const tabContentWrapper = document.querySelector('.tabs__content-wrapper');
              tabContentWrapper.setAttribute('data-active-tab', number);

              const list = [...document.querySelectorAll('.tab__header')].filter(x => !x.classList.contains('disabled'))
              const index = list.indexOf(list.find(x => x.classList.contains('url')))
              if (index) {
                tabContentWrapper.style.left = `-${index}00%`;
              }
            }
            endTimer('LOADALL');
          }, 100);
        });
      }
    })
  }

  // Update risk score cache by asking for it from background
  chrome.runtime.sendMessage({ action: 'getRiskScores' }, response => {
    riskScoreCache = response;
  });

  chrome.runtime.sendMessage({ action: 'getSandboxSubmissions' }, response => {
    if (response && response.countdownNumber === 0 && response.sandBoxSubmissions.length > 0) {
      sandboxTimerCompletedHandler();
    }
  });

  let hasMalwareSandboxPermission = false;
  let freemiumAccount = false;
  // All types of users except express plus have IntelligenceCard privelege, therefore this can be used
  // to determine if a user is express plus
  let hasIntelligenceCard = false;

  let currentSettings;
  userSettings.getUserSettings().then(settings => {
    currentSettings = settings;
  });

  const loaderReloadButton = document.querySelector('#loader .button');
  const throttledReloadButton = document.getElementById('throttled');
  const disabledForDomainReloadButton = document.querySelector('#disabled-pagescanning-for-domain .button');
  const signInButton = document.getElementById('signin-button');
  const signUpLink = document.getElementById('sign-up-link');
  const signOutButton = document.getElementById('sign-out');
  const linkLearnMore = document.getElementById('link-learn-more');
  const elipsisMenu = document.querySelector('#elipsis-icon');
  const notificationsToggle = document.querySelector('#notifications-toggle');
  const domainAbuseToggle = document.querySelector('#domain-abuse-toggle');
  const highlightToggle = document.querySelector('#highlighting-toggle');
  const highlightingForSpecificSiteToggle = document.querySelector('#highlighting-site-specific-toggle');
  const highlightingMinimumCriticality = document.querySelector('#highlighting-minimum-criticality');
  const exportButton = document.getElementById('exportButton');
  const scanUrlsButton = document.getElementById('scanUrlsButton');
  const exportAsCSVButton = document.getElementById('export-menu-option-csv');
  const exportAsListButton = document.getElementById('export-menu-option-custom-list');

  const iocTypeTexts = {
    'hashes': 'Hash',
    'ips': 'IP Address',
    'cves': 'Vulnerability',
    'idns': 'Domain',
    'urls': 'URL'
  };
  const riskScoreData = {};
  let currentSite;

  let tooManyEntitiesForceLoad = false;

  /**
   * Helper to do track user actions
   * @param trackOptions
   * @private
   */
  const _trackAction = (trackOptions) => {
    const typeMap = {
      vulnerability: 'CyberVulnerability',
      hash: 'Hash',
      domain: 'InternetDomainName',
      ipaddress: 'IpAddress',
      cves: 'CyberVulnerability',
      hashes: 'Hash',
      url: 'URL',
      urls: 'URL',
      idns: 'InternetDomainName',
      ips: 'IpAddress',
      all: 'All',
      Moderate: 'Moderate',
      Critical: 'Critical',
      Low: 'Low'
    };

    if (trackOptions.type !== undefined) {
      trackOptions.type = typeMap[trackOptions.type];
    }

    const url = 'https://api.recordedfuture.com/rfq/express/track/action';

    browserModule.getToken(null, '003').then((token) => {
      if (token !== undefined) {
        const requestOptions = {
          method: 'POST',
          headers: new Headers({
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json',
            'User-Agent': 'RFChromeExtension/6.1.4'
          }),
          body: JSON.stringify(trackOptions)
        };
        fetchRetry(url, requestOptions, false, '001', false).catch(console.error);
      }
    });
  };

  async function handleIfPdf () {
    if (currentTab) {
      const token = await browserModule.getToken(null, '012');
      if (token) {
        const isFirefox = typeof InstallTrigger !== 'undefined';
        const tabId = currentTab.id;
        const path = currentTab.url.split('?')[0];
        isPdf = path.toLowerCase().endsWith('.pdf');
        const url = new URL(currentTab.url);
        isLocalFile = url.href.startsWith('file://');
        const showPdfScanningNotAvailableMessage = (isLocalFile && isPdf) || (isFirefox && isPdf);
  
        if (isPdf && !isLocalFile && !isFirefox) {
          showTooManyEntitiesForHighlightingMessage = false;
          document.querySelector('body').style.minHeight = '200px';
          document.getElementById('loader').classList.add('hidden');
          document.getElementById('loadingIndicator').classList.remove('hidden');
          chrome.runtime.sendMessage({action: 'getPdfRiskScoresFromBackground', path, tabId});
        } else if (showPdfScanningNotAvailableMessage && token) {
          document.getElementById('allow-access-instructions').style.display = 'block';
          document.getElementById('loader').classList.add('hidden');
          hideExportButton();
          document.getElementById('loadingIndicator').classList.add('hidden');
          document.querySelector('body').style.minHeight = '331px';
        }
      }
    }
  }

  /**
   * When the popover is opened, try to get the IOCs from the current page and start creating the popup content
   */
  window.addEventListener('DOMContentLoaded', () => browserModule.onDOMContentLoaded().then(createPopupHTML));

  /**
   * Handle clicks on the reload button so the page is reloaded and popup gets populated with fresh data
   */
  document.querySelector('#tooManyEntities .button').addEventListener('click', () => {
    startTimer('LOADALL');

    _trackAction({action: 'BrowserExtensionLoadAllEntities'});

    ignoreTooManyHits = true;
    document.getElementById('tooManyEntities').classList.add('hidden');
    document.getElementById('loadingIndicator').classList.remove('hidden');
    hideExportButton();
    showElipsisMenu();
    showHighlightToggle();

    if (hasSeenDomainAbuseAlertsIntro) {
      if (document.querySelector('.tabs__content-wrapper__outer')) {
        document.querySelector('.tabs__content-wrapper__outer').style.maxHeight = 'none';
      }
      if (document.querySelector('.tabs__content-wrapper')) {
        document.querySelector('.tabs__content-wrapper').style.maxHeight = 'none';
      }
      if (document.querySelectorAll('.tabs__content-wrapper ul')) {
        document.querySelectorAll('.tabs__content-wrapper ul').forEach(x => x.style.maxHeight = '385px');
      }
    }
    tooManyEntitiesForceLoad = true;
    hideExportButton();
    if (cachedIocResult) {
      const entitiesAsList = cachedIocResult.matches.reduce((total, current) => [...total, ...current.iocs], []);
      chrome.runtime.sendMessage({ action: 'fetchRiskScores', iocs: entitiesAsList, tabId: currentTab.id });
    }
  });
  document.querySelector('#new-feature-intro-box #closeButton').addEventListener('click', () => {
    userSettings.setSettingInStorageByName('hasSeenDomainAbuseAlertsIntro', true);

    document.getElementById('new-feature-intro-box').style.opacity = '0';
    setTimeout(() => {
      document.getElementById('new-feature-intro-box').style.display = 'none';

      const tabContentWrapperOuter = document.querySelector('.tabs__content-wrapper__outer');
      const tabContentWrapper = document.querySelector('.tabs__content-wrapper');

      if (document.getElementById('over-400-entities-highlighting-disabled').style.display === 'block') {
        document.getElementById('over-400-entities-highlighting-disabled').style.marginTop = '20px';
        document.getElementById('over-400-entities-highlighting-disabled').style.marginBottom = '20px';
      } else {
        tabContentWrapperOuter.style.maxHeight = 'none';
        tabContentWrapper.style.maxHeight = 'none';

        let maxHeight;
        if (freemiumAccount && document.getElementById('new-feature-intro-box').style.display === 'block') {
          maxHeight = 170;
        } else if (getComputedStyle(document.getElementById('over-400-entities-highlighting-disabled')).display === 'block' &&
          document.getElementById('new-feature-intro-box').style.display === 'block') {
          maxHeight = 170;
        } else {
          maxHeight = 391;
        }

        //=  === 'block' ? 170 : 391;
        document.querySelectorAll('.tab__content ul').forEach(list => list.style.maxHeight = maxHeight + 'px');
      }
    }, 1000);
  });

  const hideTooManyEntitiesForHighlightingMessage = (time = 150) => {
    showTooManyEntitiesForHighlightingMessage = false;

    document.getElementById('over-400-entities-highlighting-disabled').style.opacity = '0';
    setTimeout(() => {
      document.getElementById('over-400-entities-highlighting-disabled').style.display = 'none';
      let tabContentWrapperOuter = document.querySelector('.tabs__content-wrapper__outer');
      let tabContentWrapper = document.querySelector('.tabs__content-wrapper');

      const hide = () => {
        if (document.getElementById('new-feature-intro-box').style.display === 'block') {
          document.getElementById('new-feature-intro-box').style.marginTop = '20px';
          document.getElementById('new-feature-intro-box').style.marginBottom = '20px';
        } else {
          tabContentWrapperOuter.style.maxHeight = 'none';
          tabContentWrapper.style.maxHeight = 'none';

          let maxHeight;
          if (freemiumAccount && document.getElementById('new-feature-intro-box').style.display === 'block') {
            maxHeight = 170;
          } else if (getComputedStyle(document.getElementById('over-400-entities-highlighting-disabled')).display === 'block' &&
            document.getElementById('new-feature-intro-box').style.display === 'block') {
            maxHeight = 170;
          } else {
            maxHeight = 391;
            tabContentWrapperOuter.style.maxHeight = 'auto';
            tabContentWrapper.style.maxHeight = 'auto';
          }

          document.querySelectorAll('.tab__content ul').forEach(list => list.style.maxHeight = maxHeight + 'px');
        }
      };
      if (tabContentWrapperOuter && tabContentWrapper) {
        hide();
      } else {
        setTimeout(() => {
          tabContentWrapperOuter = document.querySelector('.tabs__content-wrapper__outer');
          tabContentWrapper = document.querySelector('.tabs__content-wrapper');
          hide();
        }, 1000)
      }
    }, time);
  };

  document.querySelector('#over-400-entities-highlighting-disabled #closeButton').addEventListener('click', () => {
    hideTooManyEntitiesForHighlightingMessage(1000);
  });
  /* document.querySelector('#new-feature-intro-box #enableButton').addEventListener('click', () => {
    //_trackAction({action: 'BrowserExtensionSettingsMaliciousLinkBlockEnabled'});
    userSettings.setSettingInStorageByName('hasSeenDomainAbuseAlertsIntro', true);
    document.getElementById('new-feature-intro-box').style.display = 'none';
    document.querySelector('.tabs__content-wrapper__outer').style.maxHeight = 'none';
    document.querySelector('.tabs__content-wrapper').style.maxHeight = 'none';
    document.querySelectorAll('.tabs__content-wrapper ul').forEach(x => x.style.maxHeight = '385px');
    //document.querySelector('#url-options-disable-malicious-links .switch').classList.add('active');
    promptUserToAllowNotifications();
  }); */
  loaderReloadButton.addEventListener('click', browserModule.reloadCurrentPage);
  throttledReloadButton.addEventListener('click', browserModule.reloadCurrentPage);
  disabledForDomainReloadButton.addEventListener('click', () => {
    _trackAction({action: 'BrowserExtensionSettingsBEonThisDomainEnabled'});
    userSettings.removeSiteFromBlacklist(currentSite).then(() => {
      document.querySelector('#disabled-pagescanning-for-domain').classList.add('hidden');
      hideDropDown();
      browserModule.reloadCurrentPage(true);
      chrome.runtime.sendMessage({ action: 'updateBadge', value: true }, () => {
        window.close();
      });
    });
  });

  function validateSignUpForm() {
    const cb = document.getElementById('agreewithTermsSignupCheckbox');
    const mail = document.getElementById('emailInput').value;
    if (cb.checked && regExpUtil.isEmail(mail)) {
      document.getElementById('sign-up-for-free-link').removeAttribute('disabled');
    } else {
      document.getElementById('sign-up-for-free-link').setAttribute('disabled', '');
    }
  }

  document.getElementById('agreewithTermsSignupCheckbox').addEventListener('change', () => {
    validateSignUpForm();
  });
  document.getElementById('emailInput').addEventListener('change', () => {
    validateSignUpForm();
  });
  document.getElementById('emailInput').addEventListener('keydown', () => {
    validateSignUpForm();
  });

  /**
   * Handle click on the sign in button to start authentication
   */
  const signIn = async () => {
    signInButton.classList.add('disabled');
    await browserModule.startAuthentication();
    window.close();
  };
  document.querySelector('#sign-up-complete button').addEventListener('click', () => {
    signIn();
  });
  document.getElementById('firefoxPermissionPrompt_buttons_cancel').addEventListener('click', () => {
    document.getElementById('firefoxPermissionPrompt').style.visibility = 'hidden';
    document.getElementById('popupBoxOverlay').style.display = 'none';
  });
  document.getElementById('firefoxPermissionPrompt_buttons_confirm').addEventListener('click', () => {
    browser.permissions.request({origins: ['<all_urls>']}).then(granted => {
      document.getElementById('firefoxPermissionPrompt').style.visibility = 'hidden';
      document.getElementById('popupBoxOverlay').style.display = 'none';
      if (granted) {
        signIn();
      }
    });
  });

  signInButton.addEventListener('click', () => {
    const isFirefox = typeof InstallTrigger !== 'undefined';
    if (isFirefox) {
      chrome.permissions.contains({ origins: ['<all_urls>'] }, result => {
        if (result) { // The extension already has the permission
          signIn();
        } else {
          // Show prompt information box
          document.getElementById('firefoxPermissionPrompt').style.visibility = 'visible';
          document.getElementById('popupBoxOverlay').style.display = 'block';
        }
      });
    } else {
      signIn();
    }
  });
  document.querySelector('#alreadyHaveAccount .blueLink').addEventListener('click', () => {
    signIn();
  });
  document.getElementById('sign-up-for-free-link').addEventListener('click', () => {
    const errorBox = document.querySelector('#sign-up #errorMessage');
    errorBox.classList.add('hidden');
    _trackAction({action: 'BrowserExtensionSignUp2'});
    const mail = document.getElementById('emailInput').value;
    const portalId = '252628';
    const formGuid = 'd1ba6e78-8b2d-48e8-a2d2-51ee9b4f245a';
    const url = `https://api.hsforms.com/submissions/v3/integration/submit/${portalId}/${formGuid}`;
    const requestOptions = {
      method: 'POST',
      headers: new Headers({
        'Content-Type': 'application/json'
      }),
      body: JSON.stringify({
        fields: [{
          "name": "email",
          "value": mail
        },
        {
          "name": "opt_in",
          "value": "Yes"
        },
        {
          "name": "utm_source",
          "value": "browser extension"
        }]
      })
    };
    const request = new Request(url, requestOptions);
    fetch(request).then(res => {
      return res.json();
    })
      .then(body => {
        if (body.status === 'error') {
          if (body.errors[0].errorType === 'BLOCKED_EMAIL') {
            errorBox.textContent = 'Invalid Email Address';
          } else if (body.errors[0].errorType === 'INVALID_EMAIL') {
            errorBox.textContent = 'Invalid Email Address';
          } else {
            errorBox.textContent = 'Something went wrong with the signup';
          }
          errorBox.classList.remove('hidden');
          eventLog.error(`Error when calling hubspot API: ${JSON.stringify(body, null, 4)}`);
        } else { // success
          // Handle body here
          document.getElementById('sign-up-complete').classList.remove('hidden');
          document.getElementById('sign-up').classList.add('hidden');
        }
      })
      .catch(err => {
        eventLog.error(
          `Error when calling hubspot API: 
        ${JSON.stringify(err)}`
        );
      });
  });
  signUpLink.addEventListener('click', () => {
    _trackAction({action: 'BrowserExtensionSignUp1'});
    document.getElementById('sign-up').classList.remove('hidden');
    document.getElementById('sign-in').classList.add('hidden');
  });
  signOutButton.addEventListener('click', function () {
    _trackAction({action: 'BrowserExtensionSignedOut'});
    browserModule.signOut();
  });
  linkLearnMore.addEventListener('click', function () {
    browserModule.redirectLink();
  });
  linkLearnMore.addEventListener('click', function () {
    browserModule.redirectLink();
  });
  document.getElementById('termsOfUse').addEventListener('click', function () {
    browserModule.termOfUseLink();
  });
  if (document.getElementById('instructions-support-link')) {
    document.getElementById('instructions-support-link').addEventListener('click', function () {
      browserModule.localFileReadingInstructionsLink();
    });
  }
  exportAsListButton.addEventListener('click', function () {
    chrome.runtime.sendMessage({ action: 'getFullAccessList' }, resp => {
      fullAccessList = resp;

      let allItems = [];
      if (fullAccessList.ip) {
        allItems = [...allItems, ...document.querySelectorAll('.tab__content#ipaddress ul li')];
      }
      if (fullAccessList.hash) {
        allItems = [...allItems, ...document.querySelectorAll('.tab__content#hash ul li')];
      }
      if (fullAccessList.idn) {
        allItems = [...allItems, ...document.querySelectorAll('.tab__content#domain ul li')];
      }
      if (fullAccessList.url) {
        allItems = [...allItems, ...document.querySelectorAll('.tab__content#url ul li')];
      }
      if (fullAccessList.cve) {
        allItems = [...allItems, ...document.querySelectorAll('.tab__content#vulnerability ul li')];
      }

      let html = '';
      html += `
      <div class="exportPopupOption" type="all">
        <input type="checkbox">
        <div class="checkmark">
          <svg class="checked" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 3.05176e-05H0V16H16V3.05176e-05ZM6.22222 12.4445L1.77778 8.00003L3.03111 6.7467L6.22222 9.92892L12.9689 3.18225L14.2222 4.44448L6.22222 12.4445Z" fill="#2673B3"/></svg>
          <svg class="unchecked" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.5 15.5V0.5H15.5V15.5H0.5Z" stroke="#6F7787"/></svg>
        </div>
        <div>All <span class="counter">(${allItems.length})</span></div>
      </div>
      `;

      if (allItems.length > config.MAX_AMOUNT_OF_ENTITIES_FOR_EXPORT) {
        document.getElementById('exportPopupWarning').classList.remove('hidden');
      } else {
        document.getElementById('exportPopupWarning').classList.add('hidden');
      }

      ['domain', 'url', 'hash', 'ipaddress', 'vulnerability'].forEach(entityType => {
        let skip = false;

        if (entityType === 'domain' && !fullAccessList.idn) skip = true;
        if (entityType === 'url' && !fullAccessList.url) skip = true;
        if (entityType === 'hash' && !fullAccessList.hash) skip = true;
        if (entityType === 'ipaddress' && !fullAccessList.ip) skip = true;
        if (entityType === 'vulnerability' && !fullAccessList.cve) skip = true;

        if (!skip) {
          if (document.querySelector(`.tab__content#${entityType}`)) {
            let label;
            if (entityType === 'domain') label = 'Domain';
            if (entityType === 'url') label = 'URL';
            if (entityType === 'hash') label = 'Hash';
            if (entityType === 'ipaddress') label = 'IP Address';
            if (entityType === 'vulnerability') label = 'Vulnerability';

            const items = [...document.querySelectorAll(`.tab__content#${entityType} ul li`)];
            html += `
            <div class="exportPopupOption" type="${entityType}">
              <input type="checkbox">
              <div class="checkmark">
                <svg class="checked" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 3.05176e-05H0V16H16V3.05176e-05ZM6.22222 12.4445L1.77778 8.00003L3.03111 6.7467L6.22222 9.92892L12.9689 3.18225L14.2222 4.44448L6.22222 12.4445Z" fill="#2673B3"/></svg>
                <svg class="unchecked"  width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.5 15.5V0.5H15.5V15.5H0.5Z" stroke="#6F7787"/></svg>
              </div>
              <div>${label} <span class="counter">(${items.length})</span></div>
            </div>
            `;
            [3, 2, 1].forEach(criticality => {
              let label = '';
              if (criticality === 3) label = 'Critical';
              if (criticality === 2) label = 'Moderate';
              if (criticality === 1) label = 'Low';
              const criticalityItems = items.filter(x => x.querySelector(`.criticality__plupp.level-${criticality}`));
              if (criticalityItems.length > 0) {
                html += `
                <div class="exportPopupOption inset" type="${entityType}-criticality-${criticality}">
                  <input type="checkbox">
                  <div class="checkmark">
                    <svg class="checked" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 3.05176e-05H0V16H16V3.05176e-05ZM6.22222 12.4445L1.77778 8.00003L3.03111 6.7467L6.22222 9.92892L12.9689 3.18225L14.2222 4.44448L6.22222 12.4445Z" fill="#2673B3"/></svg>
                    <svg class="unchecked"  width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.5 15.5V0.5H15.5V15.5H0.5Z" stroke="#6F7787"/></svg>
                  </div>
                  <div>${label} <span class="counter">(${criticalityItems.length})</span></div>
                </div>
                `;
              }
            });
          }
        }
      });
      document.getElementById('exportPopupOptionsInner').innerHTML = html;
      setTimeout(() => {
        const setWarningDisplayStatus = () => {
          let entities = [];
          [...document.querySelectorAll(`.exportPopupOption:not([type="all"]) input[type="checkbox"]`)].filter(x => x.checked).forEach(x => {
            const parent = x.parentElement;
            if (parent.getAttribute('type').includes('criticality')) {
              const entityType = parent.getAttribute('type').split('-')[0];
              const criticality = parent.getAttribute('type').split('-')[2];
              [...document.querySelectorAll(`.tab__content#${entityType} ul li`)].forEach(e => {
                if (e.querySelector('.criticality__plupp').classList.contains('level-' + criticality)) {
                  entities.push({
                    name: e.getAttribute('data-entity'),
                    entityType
                  })
                }
              });
            }
          });
          if (entities.length === 0) {
            document.getElementById('exportPopupExportButton').classList.add('disabled');
            document.getElementById('exportPopupWarning').classList.add('hidden');
          } else if (entities.length > config.MAX_AMOUNT_OF_ENTITIES_FOR_EXPORT) {
            document.getElementById('exportPopupWarning').classList.remove('hidden');
            document.getElementById('exportPopupExportButton').classList.add('disabled');
          } else {
            document.getElementById('exportPopupWarning').classList.add('hidden');
            document.getElementById('exportPopupExportButton').classList.remove('disabled');
          }
        };

        [...document.querySelectorAll('#exportPopupOptions input[type="checkbox"]')].forEach(e => e.checked = true);
        // Listener for All
        document.querySelector('.exportPopupOption[type="all"] input[type="checkbox"]').addEventListener('change', () => {
          if (document.querySelector('.exportPopupOption[type="all"] input[type="checkbox"]').checked) {
            [...document.querySelectorAll('.exportPopupOption input[type="checkbox"]')].forEach(x => x.checked = true);
          } else {
            [...document.querySelectorAll('.exportPopupOption input[type="checkbox"]')].forEach(x => x.checked = false);
          }
          setWarningDisplayStatus();
        });
        ['domain', 'url', 'hash', 'ipaddress', 'vulnerability'].forEach(entityType => {
          if (document.querySelector(`.exportPopupOption[type="${entityType}"]`)) {
            document.querySelector(`.exportPopupOption[type="${entityType}"] input[type="checkbox"]`).addEventListener('change', () => {
              if (document.querySelector(`.exportPopupOption[type="${entityType}"] input[type="checkbox"]`).checked) {
                [...document.querySelectorAll(`
                  .exportPopupOption[type="${entityType}-criticality-3"] input[type="checkbox"],
                  .exportPopupOption[type="${entityType}-criticality-2"] input[type="checkbox"],
                  .exportPopupOption[type="${entityType}-criticality-1"] input[type="checkbox"]
                `)].forEach(x => x.checked = true);
              } else {
                [...document.querySelectorAll(`
                  .exportPopupOption[type="${entityType}-criticality-3"] input[type="checkbox"],
                  .exportPopupOption[type="${entityType}-criticality-2"] input[type="checkbox"],
                  .exportPopupOption[type="${entityType}-criticality-1"] input[type="checkbox"]
                `)].forEach(x => x.checked = false);
              }
            });
            setWarningDisplayStatus();
          }
        });
        [...document.querySelectorAll(`.exportPopupOption input[type="checkbox"]`)].forEach(e => e.addEventListener('change', ev => {
          setTimeout(() => {
            const parent = ev.srcElement.parentElement;
            if (!parent.getAttribute('type') !== 'all') {
              if (parent.getAttribute('type').includes('criticality')) {
                const entityType = parent.getAttribute('type').split('-')[0];
                if ([...document.querySelectorAll(`
                  .exportPopupOption[type="${entityType}-criticality-3"] input[type="checkbox"],
                  .exportPopupOption[type="${entityType}-criticality-2"] input[type="checkbox"],
                  .exportPopupOption[type="${entityType}-criticality-1"] input[type="checkbox"]
                `)].every(x => x.checked)) {
                  document.querySelector(`.exportPopupOption[type="${entityType}"] input[type="checkbox"]`).checked = true;
                } else {
                  document.querySelector(`.exportPopupOption[type="${entityType}"] input[type="checkbox"]`).checked = false;
                }
              }
              if ([...document.querySelectorAll(`.exportPopupOption:not([type="all"]) input[type="checkbox"]`)].every(x => x.checked)) {
                document.querySelector('.exportPopupOption[type="all"] input[type="checkbox"]').checked = true;
              } else {
                document.querySelector('.exportPopupOption[type="all"] input[type="checkbox"]').checked = false;
              }

              if ([...document.querySelectorAll(`.exportPopupOption:not([type="all"]) input[type="checkbox"]`)].every(x => !x.checked)) {
                document.getElementById('exportPopupExportButton').classList.add('disabled');
              } else {
                document.getElementById('exportPopupExportButton').classList.remove('disabled');
              }
            }
            setWarningDisplayStatus();
          }, 50);
        }));
        document.getElementById('exportPopupBox').style.display = 'block';
        document.getElementById('popupBoxOverlay').style.display = 'block';

        const bbox = document.getElementById('exportPopupOptionsInner').getBoundingClientRect();
        if (bbox.height >= 250) {
          document.getElementById('exportPopupOptions').classList.add('scrollable');
        }
      }, 500);
    });
  });

  const exportAsCSV = () => {
    exportButton.classList.add('loading');
    document.getElementById('exportMenu').classList.add('hidden');
    _trackAction({action: 'BrowserExtensionExportTriggered'});

    const startExport = tabId => {
      chrome.runtime.sendMessage({ action: 'export', currentIocs, tabId, hasIntelligenceCard }, response => {
        setTimeout(() => {
          exportButton.classList.remove('loading');
        }, 500);
      });
    };
    const handleResponse = (granted, tabId) => {
      if (granted) {
        //console.log('User granted permission');
        userHasGrantedDownloadsPermission = true;
        _trackAction({action: 'BrowserExtensionExportPermissionGranted'});
        document.getElementById('csvExportConfirmation').style.display = 'none';
        document.getElementById('popupBoxOverlay').style.display = 'none';
        startExport(tabId);
      } else {
        //console.log('User denied permission');
        document.getElementById('csvExportConfirmation').style.display = 'none';
        document.getElementById('popupBoxOverlay').style.display = 'none';
        _trackAction({action: 'BrowserExtensionExportPermissionDenied'});
        exportButton.classList.remove('loading');
      }
    };
    //console.log('The user has download permission: ' + userHasGrantedDownloadsPermission);
    if (currentTab) {
      //console.log('Tab exists', currentTab);
      if (userHasGrantedDownloadsPermission) { // The extension has the permission
        //console.log('Start export');
        startExport(currentTab.id);
      } else { // The extension doesn't have the permission
        //console.log('User has not granted permission. Request permission from user.');
        if (typeof InstallTrigger !== 'undefined') { // Firefox
          browser.permissions.request({
            permissions: ['downloads'],
            origins: ['http://*/*', 'https://*/*']
          }).then(granted => {
            handleResponse(granted, currentTab.id);
          });
        } else { // Chrome
          chrome.permissions.request({
            permissions: ['downloads'],
            origins: ['http://*/*', 'https://*/*']
          }).then(granted => {
            handleResponse(granted, currentTab.id);
          });
        }
      }
    }
  };
  document.querySelector('#csvExportConfirmation #confirm').addEventListener('click', function () {
    exportAsCSV();
  });
  document.querySelector('#csvExportConfirmation #cancel').addEventListener('click', function () {
    document.getElementById('csvExportConfirmation').style.display = 'none';
    document.getElementById('popupBoxOverlay').style.display = 'none';
  });
  document.querySelector('#csvExportConfirmation #closeButton').addEventListener('click', function () {
    document.getElementById('csvExportConfirmation').style.display = 'none';
    document.getElementById('popupBoxOverlay').style.display = 'none';
  });
  document.getElementById('exportPopupBoxCloseButton').addEventListener('click', function () {
    document.getElementById('exportPopupBox').style.display = 'none';
    document.getElementById('popupBoxOverlay').style.display = 'none';
  });
  document.getElementById('scanUrlsPopupBoxCloseButton').addEventListener('click', function () {
    document.getElementById('scanUrlsPopupBox').style.display = 'none';
    document.getElementById('popupBoxOverlay').style.display = 'none';
    _trackAction({action: 'BrowserExtensionUserCancelledSandbox'});
  });
  document.getElementById('scanUrlsPopupCancelButton').addEventListener('click', function () {
    document.getElementById('scanUrlsPopupBox').style.display = 'none';
    document.getElementById('popupBoxOverlay').style.display = 'none';
    _trackAction({action: 'BrowserExtensionUserCancelledSandbox'});
  });
  document.getElementById('exportPopupCancelButton').addEventListener('click', function () {
    document.getElementById('exportPopupBox').style.display = 'none';
    document.getElementById('popupBoxOverlay').style.display = 'none';
  });
  document.getElementById('exportPopupExportButton').addEventListener('click', function () {
    _trackAction({action: 'BrowserExtensionListCreated'});

    chrome.runtime.sendMessage({ action: 'getCveIds' }, response => {
      let cveIds = response;

      document.getElementById('exportPopupBoxLoadingOverlay').style.display = 'block';
      document.getElementById('exportPopupErrorMessage').innerText = '';

      let entities = [];
      [...document.querySelectorAll(`.exportPopupOption:not([type="all"]) input[type="checkbox"]`)].filter(x => x.checked).forEach(x => {
        const parent = x.parentElement;
        if (parent.getAttribute('type').includes('criticality')) {
          const entityType = parent.getAttribute('type').split('-')[0];
          const criticality = parent.getAttribute('type').split('-')[2];
          [...document.querySelectorAll(`.tab__content#${entityType} ul li`)].forEach(e => {
            if (e.querySelector('.criticality__plupp').classList.contains('level-' + criticality)) {
              entities.push({
                name: e.getAttribute('data-entity'),
                entityType
              });
              if (e.querySelector('.redirectLink')) {
                entities.push({
                  name: e.querySelector('.redirectLink').innerText,
                  entityType
                });
              }
            }
          });
        }
      });
      
      chrome.runtime.sendMessage({ action: 'createList', entities, isLocalFile, isPdf, currentTab, riskScoreCache });
    });
  });

  exportAsCSVButton.addEventListener('click', function () {
    document.getElementById('exportMenu').classList.add('hidden'); // Hide
    if (!userHasGrantedDownloadsPermission) { // Show modal
      document.getElementById('popupBoxOverlay').style.display = 'block';
      document.getElementById('csvExportConfirmation').style.display = 'block';
    } else { // Permission already granted, immediately export
      exportAsCSV();
    }
  });

  exportButton.addEventListener('click', function () {
    if (freemiumAccount) return;

    const menuIsClosed = document.getElementById('exportMenu').classList.contains('hidden');

    userClickedExportButton = true;
    setTimeout(() => {
      userClickedExportButton = false;
    }, 150);

    if (menuIsClosed) {
      hideDropDown();
      document.getElementById('exportMenu').classList.remove('hidden'); // Show
    } else {
      document.getElementById('exportMenu').classList.add('hidden'); // Hide
    }
  });

  document.querySelector('#scanUrlsButton .scanUrlsTooltip #upgradeTooltipLink').addEventListener('click', () => {
    window.open('https://support.recordedfuture.com/hc/en-us/articles/115001351547-Recorded-Future-Browser-Extension');
  });

  scanUrlsButton.addEventListener('click', async () => {
    const storage = await browserModule.getStorage();
    const settings = await userSettings.getUserSettings();

    if (freemiumAccount) return;
    if (urlScanIsInProgress) return;
    if (document.getElementById('scanUrlsButton').classList.contains('disabled')) return;
    if (!hasMalwareSandboxPermission) return;
    if (!storage.scope.includes('Modules')) return;
    if (!settings.entityTypesToShow.url) return;

    _trackAction({action: 'BrowserExtensionUserClickedScanUrlsButton'});

    const setWarningDisplayStatus = () => {
      const selectedUrls = [...document.querySelectorAll(`.scanUrlsPopupOption:not([type="all"]) input[type="checkbox"]`)].filter(x => x.checked);

      if (selectedUrls.length > config.MAX_AMOUNT_OF_URLS_FOR_SANDBOX) {
        document.getElementById('scanUrlsPopupWarning').classList.remove('hidden');
        document.getElementById('scanUrlsPopupExportButton').classList.add('disabled');
      } else if (selectedUrls.length > 0 && selectedUrls.length <= config.MAX_AMOUNT_OF_URLS_FOR_SANDBOX) {
        document.getElementById('scanUrlsPopupWarning').classList.add('hidden');
        document.getElementById('scanUrlsPopupExportButton').classList.remove('disabled');
      } else if (selectedUrls.length === 0) {
        document.getElementById('scanUrlsPopupExportButton').classList.add('disabled');
      }
    };

    setWarningDisplayStatus();

    const urls = await getURLsThatAreNotWhiteListed();
    let html = '';
    html += `
    <div class="scanUrlsPopupOption" type="all">
      <input type="checkbox">
      <div class="checkmark">
        <svg class="checked" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 3.05176e-05H0V16H16V3.05176e-05ZM6.22222 12.4445L1.77778 8.00003L3.03111 6.7467L6.22222 9.92892L12.9689 3.18225L14.2222 4.44448L6.22222 12.4445Z" fill="#2673B3"/></svg>
        <svg class="unchecked" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.5 15.5V0.5H15.5V15.5H0.5Z" stroke="#6F7787"/></svg>
      </div>
      <div>URLs <span class="counter">(${urls.length})</span></div>
    </div>
    `;
    urls.forEach(url => {
      html += `
      <div class="scanUrlsPopupOption inset url">
        <input type="checkbox">
        <div class="checkmark">
          <svg class="checked" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 3.05176e-05H0V16H16V3.05176e-05ZM6.22222 12.4445L1.77778 8.00003L3.03111 6.7467L6.22222 9.92892L12.9689 3.18225L14.2222 4.44448L6.22222 12.4445Z" fill="#2673B3"/></svg>
          <svg class="unchecked"  width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.5 15.5V0.5H15.5V15.5H0.5Z" stroke="#6F7787"/></svg>
        </div>
        <div class="optionLabel maxWidth">${url}</div>
      </div>
      `;
    });
    document.getElementById('scanUrlsPopupOptionsInner').innerHTML = html;
    document.getElementById('scanUrlsPopupBox').style.display = 'block';
    document.getElementById('popupBoxOverlay').style.display = 'block';
    const bbox = document.getElementById('scanUrlsPopupOptionsInner').getBoundingClientRect();
    if (bbox.height >= 220) {
      document.getElementById('scanUrlsPopupOptions').classList.add('scrollable');
    }

    [...document.querySelectorAll(`.scanUrlsPopupOption input[type="checkbox"]`)].forEach(e => e.addEventListener('change', ev => {
      setTimeout(() => {
        const parent = ev.srcElement.parentElement;

        if (parent.getAttribute('type') === 'all') {
          const urlsCheckboxes = [...document.querySelectorAll('.scanUrlsPopupOption.url input[type="checkbox"]')]
          if (urlsCheckboxes.every(x => x.checked)) {
            urlsCheckboxes.forEach(x => x.checked = false);
            document.getElementById('scanUrlsPopupWarning').classList.add('hidden');
          } else {
            urlsCheckboxes.forEach(x => x.checked = true);
          }
        } else {
          const urlsCheckboxes = [...document.querySelectorAll('.scanUrlsPopupOption.url input[type="checkbox"]')]
          if (urlsCheckboxes.every(x => x.checked)) {
            document.querySelector(`.scanUrlsPopupOption[type="all"] input[type="checkbox"]`).checked = true;
          } else {
            document.querySelector(`.scanUrlsPopupOption[type="all"] input[type="checkbox"]`).checked = false;
          }
        }
        setWarningDisplayStatus();
      }, 50);
    }));
  });

  document.getElementById('scanUrlsPopupExportButton').addEventListener('click', () => {
    const selectedUrls = [...document.querySelectorAll('.scanUrlsPopupOption.url input[type="checkbox"]')]
      .filter(x => x.checked)
      .map(x => x.parentElement.querySelector('.optionLabel').innerText);

    chrome.runtime.sendMessage({ action: 'submitToSandbox', urls: selectedUrls });

    document.getElementById('scanUrlsPopupBox').style.display = 'none';
    document.getElementById('popupBoxOverlay').style.display = 'none';

    _trackAction({action: 'BrowserExtensionUserSubmittedUrlsToSandbox'});
  });

  elipsisMenu.addEventListener('click', function () {
    const menuDropdown = document.querySelector('#menu-list');
    if (menuDropdown.classList.contains('hidden')) {
      userClickedSettingsButton = true;
      _trackAction({action: 'MenuOpen'});
      showDropDown();
      setTimeout(() => {
        userClickedSettingsButton = false;
      }, 150);
    } else {
      hideDropDown();
    }
  });

  const handleEntityTypeToggle = event => {
    const toggle = event.currentTarget.querySelector('.switch');
    let value;
    if (toggle.classList.contains('active')) {
      toggle.classList.remove('active');
      value = false;
    } else {
      toggle.classList.add('active');
      value = true;
    }

    let entityType;
    let actionToTrack;
    if (event.currentTarget.id === 'entity-type-domain-toggle') {
      entityType = 'domain'
      actionToTrack = value ? 'BrowserExtensionSettingsDomainEnabled' : 'BrowserExtensionSettingsDomainDisabled';
    } else if (event.currentTarget.id === 'entity-type-url-toggle') {
      entityType = 'url'
      actionToTrack = value ? 'BrowserExtensionSettingsUrlEnabled' : 'BrowserExtensionSettingsUrlDisabled';
    } else if (event.currentTarget.id === 'entity-type-vulnerability-toggle') {
      entityType = 'vulnerability'
      actionToTrack = value ? 'BrowserExtensionSettingsVulnerabilityEnabled' : 'BrowserExtensionSettingsVulnerabilityDisabled';
    } else if (event.currentTarget.id === 'entity-type-ip-toggle') {
      entityType = 'ip'
      actionToTrack = value ? 'BrowserExtensionSettingsIpAddressEnabled' : 'BrowserExtensionSettingsIpAddressDisabled';
    } else if (event.currentTarget.id === 'entity-type-hash-toggle') {
      entityType = 'hash'
      actionToTrack = value ? 'BrowserExtensionSettingsHashEnabled' : 'BrowserExtensionSettingsHashDisabled';
    }
    if (actionToTrack) {
      _trackAction({action: actionToTrack});
    }

    userSettings.getEntityTypesToShow().then(entityTypesToShow => {
      entityTypesToShow[entityType] = value;
      currentSettings.entityTypesToShow = entityTypesToShow;
      userSettings.setEntityTypesToShow(entityTypesToShow).then(async () => {
        if (entityType === 'url' && value) {
          await setScanUrlsButton();
          document.querySelector('#urlScoringInformation').style.display = 'none';
          window.localStorage.setItem('hasSeenUrlTabIntro', true);
          if (document.querySelector('.urls.newLabel')) {
            document.querySelector('.urls.newLabel').remove();
          }
        } else if (entityType === 'url' && !value) {
          document.querySelector('#urlScoringInformation').style.display = 'block';
        }
        if (currentTab) {
          keepMenuOpen = true;
          chrome.tabs.sendMessage(currentTab.id, {action: 'updateEntityOptions'});
        }
      })
    });
  };

  const setUrlOptionsSetting = (event, callback = null) => {
    let settingName = 'disableMaliciousLinks';

    if (event.currentTarget.classList.contains('disabled')) {
      return;
    }

    const toggle = event.currentTarget.querySelector('.switch');
    if (settingName) {
      let value;
      if (toggle.classList.contains('active')) {
        toggle.classList.remove('active');
        value = false;
      } else {
        toggle.classList.add('active');
        value = true;
      }

      if (value) {
        _trackAction({action: 'BrowserExtensionSettingsMaliciousLinkBlockEnabled'});
      } else {
        _trackAction({action: 'BrowserExtensionSettingsMaliciousLinkBlockDisable'});
      }

      userSettings.getUserSettings().then(settings => {
        currentSettings = settings;

        settings[settingName] = value;
        userSettings.saveNewSettings(settings);
        if (value) {
          userSettings.setSettingInStorageByName('hasSeenDomainAbuseAlertsIntro', true);
          document.getElementById('new-feature-intro-box').style.display = 'none';
        }
        if (callback) {
          callback(settings);
        }
      });
    }
  };

  // Entity type listeners
  document.getElementById('entity-type-domain-toggle').addEventListener('click', handleEntityTypeToggle);
  document.getElementById('entity-type-url-toggle').addEventListener('click', handleEntityTypeToggle);
  document.getElementById('entity-type-vulnerability-toggle').addEventListener('click', handleEntityTypeToggle);
  document.getElementById('entity-type-ip-toggle').addEventListener('click', handleEntityTypeToggle);
  document.getElementById('entity-type-hash-toggle').addEventListener('click', handleEntityTypeToggle);
  document.getElementById('advancedOptions').addEventListener('click', () => {
    showAdvancedSettings = !showAdvancedSettings;
    if (showAdvancedSettings) {
      _trackAction({action: 'BrowserExtensionSettingsAdvancedOptionsExpanded'});

      document.getElementById('advancedOptions').classList.add('opened');
      document.getElementById('advancedOptionsMenu').style.display = 'block';
    } else {
      _trackAction({action: 'BrowserExtensionSettingsAdvancedOptionsCollapsed'});

      document.getElementById('advancedOptions').classList.remove('opened');
      document.getElementById('advancedOptionsMenu').style.display = 'none';
    }
  });
  // URL options listeners
  document.querySelector('#url-options-disable-malicious-links').addEventListener('click', event => {
    setUrlOptionsSetting(event, settings => {
      setUrlHighlighting(settings.disableMaliciousLinks);
    });
  });

  domainAbuseToggle.addEventListener('click', () => {
    userSettings.getUserSettings().then(settings => {
      const newSettings = Object.assign({}, settings);
      newSettings.alertTypes.domainAbuse = !newSettings.alertTypes.domainAbuse;
      currentSettings = newSettings;
      userSettings.saveNewSettings(newSettings);
      // Update switch
      if (newSettings.alertTypes.domainAbuse) {
        _trackAction({action: 'userEnabledDomainAbuseAlertsForExtension'});
        document.querySelector('#domain-abuse-toggle .switch').classList.add('active');
      } else {
        _trackAction({action: 'userDisabledDomainAbuseAlertsForExtension'});
        document.querySelector('#domain-abuse-toggle .switch').classList.remove('active');
      }
      // Update background listener
      chrome.runtime.sendMessage({ action: 'updateAlertsMessageListener' });
    });
  });

  notificationsToggle.addEventListener('click', () => {
    userHasGrantedNotificationsPermission = !userHasGrantedNotificationsPermission;

    chrome.storage.local.set({ userHasGrantedNotificationsPermission: userHasGrantedNotificationsPermission }, () => {
      toggleNotificationsToggle(userHasGrantedNotificationsPermission);
      if (userHasGrantedNotificationsPermission) {
        _trackAction({action: 'userAllowedNotitifcationsPermission'});
        chrome.runtime.sendMessage({ action: 'userGrantedNotificationsPermission' });
      } else {
        _trackAction({action: 'userDeniedNotitifcationsPermission'});
        chrome.runtime.sendMessage({ action: 'userDeniedNotificationsPermission' });
      }
    });
  });

  highlightToggle.addEventListener('click', () => {
    highlightToggle.classList.add('disabled');
    const toggleButton = highlightToggle.querySelector('.switch');

    userSettings.getUserSettings().then(settings => {
      currentSettings = settings;

      if (settings.highlightingEnabled && pageContainsTooManyEntitiesForHighlighting && !toggleButton.classList.contains('active')) {
        hideTooManyEntitiesForHighlightingMessage();
        toggleButton.classList.add('active');
        setHighlighting(true, true);
      } else {
        const newSettings = Object.assign({}, settings);
        let highlightingEnabled = settings.highlightingEnabled;
        highlightingEnabled = !highlightingEnabled;

        if (highlightingEnabled) {
          _trackAction({action: 'ShowRiskScoreonPageEnable'});
          toggleButton.classList.add('active');
        } else {
          _trackAction({action: 'ShowRiskScoreonPageDisable'});
          toggleButton.classList.remove('active');
        }

        setHighlighting(highlightingEnabled, (pageContainsTooManyEntitiesForHighlighting && highlightingEnabled));

        newSettings.highlightingEnabled = highlightingEnabled;
        userSettings.saveNewSettings(newSettings);
        setTimeout(() => {
          highlightToggle.classList.remove('disabled');
        }, 800);
      }
    });
  });

  highlightingForSpecificSiteToggle.addEventListener('click', () => {
    _trackAction({action: 'BrowserExtensionSettingsBEonThisDomainDisabled'});
    userSettings.addSiteToBlacklist(currentSite).then(() => {
      hideDropDown();
      setUrlHighlighting(false);
      setHighlighting(false);
      browserModule.reloadCurrentPage(true);
      chrome.runtime.sendMessage({ action: 'updateBadge', value: false }, () => {
        document.getElementById('ioc-list').style.display = 'none';
        window.close();
      });
    });
  });

  highlightingMinimumCriticality.addEventListener('click', () => {
    document.querySelector('#highlighting-level-menu').classList.remove('hidden');
  });

  const setCriticalityHighlightingLevel = (level, id, label) => {
    return userSettings.getUserSettings().then(settings => {
      currentSettings = settings;

      let levelAsString = '';
      if (level === 0) {
        levelAsString = 'all';
      } else if (level === 1) {
        levelAsString = 'Low';
      } else if (level === 2) {
        levelAsString = 'Moderate';
      } else if (level === 3) {
        levelAsString = 'Critical';
      }
      _trackAction({action: 'BrowserExtensionSettingsSetRiskScore', type: levelAsString});

      settings.highlightingMinimumCriticality = level;
      userSettings.saveNewSettings(settings);
      document.querySelectorAll('.highlighting-level-menu-option').forEach(e => e.classList.remove('selected'));
      document.querySelector(`#${id}`).classList.add('selected');
      document.querySelector('#highlighting-minimum-criticality-current').innerText = label;
      document.querySelector('#highlighting-level-menu').classList.add('hidden');
      setHighlightingCriticality(level);
    });
  };

  document.querySelector('#highlighting-level-menu-critical').addEventListener('click', () => {
    setCriticalityHighlightingLevel(3, 'highlighting-level-menu-critical', 'Critical');
  });

  document.querySelector('#highlighting-level-menu-medium').addEventListener('click', () => {
    setCriticalityHighlightingLevel(2, 'highlighting-level-menu-medium', 'Medium & above');
  });

  document.querySelector('#highlighting-level-menu-low').addEventListener('click', () => {
    setCriticalityHighlightingLevel(1, 'highlighting-level-menu-low', 'Low & above');
  });

  document.querySelector('#highlighting-level-menu-all').addEventListener('click', () => {
    setCriticalityHighlightingLevel(0, 'highlighting-level-menu-all', 'All');
  });

  function setHighlighting(enabled, overrideMaxLevelBlock = false) {
    if (currentTab) {
      chrome.tabs.sendMessage(currentTab.id, {action: 'setHighlighting', value: enabled, ignoreTooManyHits, overrideMaxLevelBlock});
    }
  }

  function setUrlHighlighting(enabled) {
    if (currentTab) {
      chrome.tabs.sendMessage(currentTab.id, {action: 'setUrlHighlighting', value: enabled});
    }
    setTimeout(() => {
      keepMenuOpen = true;
      _createPopupHTML({ iocsResult: cachedIocResult, token }, false);
    }, 200);
  }

  function setHighlightingCriticality(criticality) {
    if (currentTab) {
      chrome.tabs.sendMessage(currentTab.id, {action: 'setHighlightingCriticality', criticality: criticality, ignoreTooManyHits});
    }
  }

  /**
   * Do browser specific init stuff:
   * the settingsButton is needed since we want to remove it from
   * Safari and add a click handler for Chrome
   */

  ////////////////////////////////////////////////////////////////////////////

  /**
   * Try to get the user's token from the extension storage
   * @private
   */
  let token;
  browserModule.getToken(null, '004').then(t => {
    token = t;
    browserModule.getStorage().then(async storage => {
      hasMalwareSandboxPermission = storage.scope && storage.scope.includes('MalwareSandbox');
      freemiumAccount = storage.scope && storage.scope.includes('FreeData');
      hasIntelligenceCard = storage.scope && storage.scope.includes('IntelligenceCard');

      const settings = await userSettings.getUserSettings();

      if (
        !hasMalwareSandboxPermission || // User does not have permission
        !storage.scope.includes('Modules') || // or is legacy user
        !settings.entityTypesToShow.url // or if URL is disabled
      ) {
        document.getElementById('scanUrlsButton').classList.add('noPermission');
        document.getElementById('scanUrlsButton').classList.add('disabled');
      }

      if (freemiumAccount) {
        // Express user
        exportButton.classList.remove('hidden');
        exportButton.classList.add('disabled');
        document.getElementById('exportButtonContainer').classList.add('expressUser');
      } else if (storage.scope && (!storage.scope.includes('Modules') || !storage.scope.includes('ListCreate'))) {
        // Legacy users and non-TI-users
        document.getElementById('export-menu-option-custom-list').classList.add('hidden');
      } else if (storage.scope && storage.scope.includes('Modules') && storage.scope.includes('ListCreate')) {
        // User that can export
        //document.getElementById('export-menu-option-custom-list').classList.add('hidden');
      }

      chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
        if (tabs[0] && tabs[0].url) {
          const url = new URL(tabs[0].url);
          const host = url.hostname;
          currentSite = host;

          userSettings.getUserSettings().then(settings => {
            currentSettings = settings;

            if (settings.alertTypes.domainAbuse) {
              document.querySelector('#domain-abuse-toggle .switch').classList.add('active');
            } else {
              document.querySelector('#domain-abuse-toggle .switch').classList.remove('active');
            }

            // Check if current site is blacklisted
            const siteIsBlacklisted = token && settings.userCustomBlacklist &&
              settings.userCustomBlacklist.some(url => currentSite.match(new RegExp(url, 'g')));

            if (freemiumAccount) {
              document.querySelector('body').classList.add('express');

              document.querySelector('#rfLogo').style.display = 'none';
              document.querySelector('#rfLogoExpress').style.display = 'block';

              document.querySelector('.logo').style.width = '190px';
              document.querySelector('header').style.marginBottom = '12px';
              document.getElementById('loadingIndicator').style.marginTop = '30px';

              /* if (showNewFeatureIntro) {
                const span1 = document.createElement('span');
                span1.innerText = 'The Recorded Future Browser Extension can now support export of key data in CSV format to allow data to be shared conveniently. Upgrade to export data in CSV format. Click ';
                const link = document.createElement('a');
                link.innerText = 'here';
                const span2 = document.createElement('span');
                span2.innerText = ' to learn more.';
  
                let href;
                if (typeof InstallTrigger !== 'undefined') { // Firefox
                  href = 'https://www.recordedfuture.com/license-options/?utm_campaign=express&utm_source=firefox-extension&utm_medium=affiliate';
                } else { // Chrome
                  href = 'https://www.recordedfuture.com/license-options/?utm_campaign=express&utm_source=chrome-extension&utm_medium=affiliate';
                }
                link.addEventListener('click', () => {
                  window.open(href);
                });
  
                const textElement = document.querySelector('#new-feature-intro-box span');
                textElement.innerText = '';
                textElement.appendChild(span1);
                textElement.appendChild(link);
                textElement.appendChild(span2);
  
                hideExportButton();
              } */
            } else  {
              //document.querySelector('#genericModuleMessageForExpressUsers').style.display = 'none';
            }
            if (siteIsBlacklisted) {
              document.querySelector('#disabled-pagescanning-for-domain').classList.remove('hidden');
              document.getElementById('new-feature-intro-box').style.display = 'none';
              document.getElementById('loader').classList.add('hidden');
              hideExportButton();
              document.getElementById('loadingIndicator').classList.add('hidden');
              document.getElementById('ioc-list').classList.add('hidden');
              document.querySelector('#sign-in').classList.add('hidden');
              document.querySelector('#elipsis-icon').classList.add('hidden');
            } else {
              document.querySelector('#disabled-pagescanning-for-domain').classList.add('hidden');
            }

            let showSignInWasTriggered = false;

            if (!siteIsBlacklisted && token) {
              document.querySelector('#sign-in').classList.add('hidden');
              //document.querySelector('#loader').classList.add('hidden');
              showElipsisMenu();
            } else if (storage.refreshToken && !siteIsBlacklisted) {
              hideSignIn();
              showElipsisMenu();
            } else if (!siteIsBlacklisted || !token) {
              showSignInWasTriggered = true;
              showSignIn();
              hideElipsisMenu();
            }

            if (!siteIsBlacklisted && token && !showSignInWasTriggered) {
              //document.querySelector('body').style.minHeight = '590px';
            }

            hideDropDown();
          });
        }
      });
    });
  });

  function configureMenu(settings, currentIocs) {
    if (currentIocs && currentIocs.matches) {
      currentIocs = currentIocs.matches;
    } else {
      currentIocs = [];
    }
    const allIocs = currentIocs.reduce((total, current) => {
      if (current.type === 'urls' && !settings.entityTypesToShow.url) {
        return total;
      } else if (current.type === 'idns' && !settings.entityTypesToShow.domain) {
        return total;
      } else if (current.type === 'hashes' && !settings.entityTypesToShow.hash) {
        return total;
      } else if (current.type === 'cves' && !settings.entityTypesToShow.vulnerability) {
        return total;
      } else if (current.type === 'ips' && !settings.entityTypesToShow.ip) {
        return total;
      }
      let iocs = current.iocs.map(x => Object.assign(x, { type: current.type }));
      iocs.forEach(ioc => {
        if (riskScoreCache && riskScoreCache[ioc.name]) {
          ioc.riskData = riskScoreCache[ioc.name];
        }
      });
      if (current.type === 'urls') {
        iocs = iocs.filter(x => x.fromPlainText || (x.fromLink && x.riskData && x.riskData.riskScore >= 65));
      }
      return [...total, ...iocs];
    }, []);
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (tabs[0] && tabs[0].url) {
        const url = new URL(tabs[0].url);
        const host = url.hostname;
        currentSite = host;
      }
      document.querySelectorAll('.highlighting-level-menu-option').forEach(e => e.classList.remove('selected'));
      const level = settings.highlightingMinimumCriticality !== null ? settings.highlightingMinimumCriticality : 2;
      switch (level) {
        case 0:
          document.querySelector('#highlighting-level-menu-all').classList.add('selected');
          document.querySelector('#highlighting-minimum-criticality-current').innerText = 'All';
          break;
        case 1:
          document.querySelector('#highlighting-level-menu-low').classList.add('selected');
          document.querySelector('#highlighting-minimum-criticality-current').innerText = 'Low & above';
          break;
        case 2:
          document.querySelector('#highlighting-level-menu-medium').classList.add('selected');
          document.querySelector('#highlighting-minimum-criticality-current').innerText = 'Moderate & above';
          break;
        case 3:
          document.querySelector('#highlighting-level-menu-critical').classList.add('selected');
          document.querySelector('#highlighting-minimum-criticality-current').innerText = 'Critical';
          break;
      }
      if (currentTab) {
        // Check if the user previously allowed highlighting on this page, overriding the max limit
        if (currentPageHasAllowedHighlightingDespiteExceedingEntityLimit) {
          highlightToggle.querySelector('.switch').classList.add('active');
        } else if (settings.highlightingEnabled && allIocs.length < config.MAX_AMOUNT_OF_ENTITIES_FOR_HIGHLIGHTING) {
          highlightToggle.querySelector('.switch').classList.add('active');
        } else {
          highlightToggle.querySelector('.switch').classList.remove('active');
        }
      }

      if (settings.disableMaliciousLinks) {
        document.querySelector('#url-options-disable-malicious-links .switch').classList.add('active');
      }

      if (!modules.includes('brand-protection')) {
        document.getElementById('domain-abuse-toggle').style.display = 'none';
      }

      userSettings.getEntityTypesToShow().then(entityTypesToShow => {
        // DOMAIN
        if (entityTypesToShow.domain) {
          document.querySelector('#entity-type-domain-toggle .switch').classList.add('active');
        } else {
          document.querySelector('#entity-type-domain-toggle .switch').classList.remove('active');
        }
        // URL
        if (entityTypesToShow.url) {
          document.querySelector('#entity-type-url-toggle .switch').classList.add('active');
          document.querySelector('#urlScoringInformation').style.display = 'none';
        } else {
          document.querySelector('#entity-type-url-toggle .switch').classList.remove('active');
        }
        // HASH
        if (entityTypesToShow.hash) {
          document.querySelector('#entity-type-hash-toggle .switch').classList.add('active');
        } else {
          document.querySelector('#entity-type-hash-toggle .switch').classList.remove('active');
        }
        // HASH
        if (entityTypesToShow.vulnerability) {
          document.querySelector('#entity-type-vulnerability-toggle .switch').classList.add('active');
        } else {
          document.querySelector('#entity-type-vulnerability-toggle .switch').classList.remove('active');
        }
        // IP
        if (entityTypesToShow.ip) {
          document.querySelector('#entity-type-ip-toggle .switch').classList.add('active');
        } else {
          document.querySelector('#entity-type-ip-toggle .switch').classList.remove('active');
        }
      });
    });
  }

  /**
   * Helper to do a call to an API endpoint
   * @param url
   * @param token
   * @private
   */
  const _doAPICall = ({url, token, method, body, headers}, source = '', logoutIfFailed = true) => new Promise((resolve, reject) => {
    eventLog.log(`Do API Call, source: ${source}`);
    let headersToUse;
    if (headers) {
      headersToUse = headers;
    } else {
      headersToUse = new Headers({
        'Authorization': 'Bearer ' + token,
        'x-rf-user-agent': 'RFChromeExtension/6.1.4'    // Updated by gulp task "version"!
      });
    }
    const requestOptions = {
      method: method || 'GET',
      headers: headersToUse,
    };
    if (body) {
      requestOptions.body = JSON.stringify(body);
    }
    fetchRetry(url, requestOptions, false, '002', logoutIfFailed)
      .then(res => res.json())
      .then(({data}) => {
        resolve(data);
      })
      .catch((err) => reject(err));
  });


  /**
   * Call the API to get risk score data
   *
   * @param name
   * @param token
   * @returns {Promise<any>}
   * @private
   */


  const _getRiskScoreData = (iocs, token, id, tabHeader, entityTypesToShow) => new Promise((resolve, reject) => {
    const criticalities = {1: 0, 2: 0, 3: 0};
    let maxCriticality = -1;
    // Add a span to hold a notification bubble with the highest criticality for each section
    const notificationsIcon = _createElement('div', 'notifications-icon');
    const notificationsLabel = _createElement('span', 'notifications-label');

    let allIocsExistsInCache = false;
    const iocKeys = iocs.map(x => x.name);
    if (riskScoreCache) {
      // Check if all iocs already exists in cache, in which case we dont need to make more calls
      const cacheIocsKeys = Object.keys(riskScoreCache);
      allIocsExistsInCache = iocKeys.every(x => cacheIocsKeys.includes(x));
    }
    if (allIocsExistsInCache || tooManyEntitiesForceLoad) {
      maxCriticality = 1;
      Object.keys(riskScoreCache).filter(key => iocKeys.includes(key)).forEach(key => {
        let riskScore = riskScoreCache[key].riskScore;
        let criticality = riskScoreCache[key].criticality;
        let triggeredRiskRuleSummaryExists = riskScoreCache[key].triggeredRiskRuleSummaryExists;

        const iocObject = iocs.find(x => x.name === key)

        if (iocObject && iocObject.redirect && iocObject.redirect.risk) {
          riskScore = iocObject.redirect.risk.score || iocObject.redirect.risk.riskScore;
          criticality = iocObject.redirect.risk.level;
          triggeredRiskRuleSummaryExists = !!(iocObject.redirect && iocObject.redirect.risk && iocObject.redirect.risk.rule && iocObject.redirect.risk.rule.evidence);
        } else if (iocObject && iocObject.redirect && iocObject.redirect.redirectsTo && riskScoreCache[iocObject.redirect.redirectsTo]) {
          riskScore = riskScoreCache[iocObject.redirect.redirectsTo].riskScore;
          criticality = riskScoreCache[iocObject.redirect.redirectsTo].level;
          triggeredRiskRuleSummaryExists = riskScoreCache[iocObject.redirect.redirectsTo].triggeredRiskRuleSummaryExists;
        } else if (riskScoreCache[key].redirect && riskScoreCache[key].redirect.risk) {
          riskScore = riskScoreCache[key].redirect.risk.score;
          criticality = riskScoreCache[key].redirect.risk.level;
        }

        if (riskScore === 0 && !riskScoreCache[key].redirect) {
          const duplicateKey = Object.keys(riskScoreCache).find(x => x !== key && x.toLowerCase() === key);
          if (duplicateKey) {
            riskScore = riskScoreCache[duplicateKey].riskScore;
            criticality = riskScoreCache[duplicateKey].criticality;
            triggeredRiskRuleSummaryExists = riskScoreCache[duplicateKey].triggeredRiskRuleSummaryExists;
          }
        }

        if (riskScore >= 65) {
          criticality = 3;
        } else if (riskScore >= 25) {
          criticality = 2;
        } else {
          criticality = 1;
        }

        if (criticality > maxCriticality) {
          maxCriticality = criticality;
        }
        criticalities[criticality] += 1;

        riskScoreData[key] = {
          riskScore,
          criticality
        };
        document.querySelectorAll(`li.panel[data-entity="${key}"]`).forEach(li => {
          _showRiskScore({li, riskScore, criticality, name: key, token, id, triggeredRiskRuleSummaryExists});
        });
      });

      let showNumber = false;
      if (id === 'all') {
        showNumber = true;
      } else if (id === 'ipaddress' && entityTypesToShow.ip) {
        showNumber = true;
      } else if (id === 'url' && !entityTypesToShow.url) {
        showNumber = false;
      } else if (entityTypesToShow[id]) {
        showNumber = true;
      }

      const count = criticalities[maxCriticality];
      if (count > 0 && showNumber) {
        notificationsLabel.textContent = count;
        // It's ok to not remove any previous level classes since they are defined in ascending order
        notificationsIcon.classList.add(`level-${maxCriticality}`);
        notificationsIcon.classList.add('grow');
        tabHeader.appendChild(notificationsIcon);
        tabHeader.appendChild(notificationsLabel);
      }
      document.querySelectorAll('li.panel').forEach(li => {
        const indicator = li.querySelector('.criticalityIndicator');
        if (indicator.classList.contains('criticalityIndicator--loading')) {
          indicator.classList.remove('criticalityIndicator--loading');
          const criticalitySpan = li.querySelector('.criticality__plupp');
          const scoreSpan = li.querySelector('.riskscore');
          criticalitySpan.classList.add(`level-1`);
          scoreSpan.textContent = 0;
        }
      });

      resolve();
    } else {
      const url = 'https://express-api.recordedfuture.com/rfq/v2/soar/enrichment';
      if (token) {
        //chrome.runtime.sendMessage({ action: 'fetchRiskScores', iocs, tabId: currentTab.id });
        resolve();
        const body = {
          ip: [],
          domain: [],
          hash: [],
          url: [],
          vulnerability: []
        };
        iocs.forEach(ioc => {
          const name = ioc.name;
          if (name && !riskScoreCache[name]) {
            if (regExpUtil.isIdn(name)) {
              body.domain.push(name);
            } else if (regExpUtil.isUrl(name)) {
              body.url.push(name);
            } else if (regExpUtil.isCve(name)) {
              body.vulnerability.push(name);
            } else if (regExpUtil.isIPAddress(name)) {
              body.ip.push(name);
            } else if (regExpUtil.isHash(name)) {
              body.hash.push(name);
            }
          }
        });
        _doAPICall({url, token, method: 'POST', body}, '001')
          .then((data) => {
            iocs.forEach(ioc => {
              let riskScore;
              let criticality;
              let noRiskScoreFound = false;
              let triggeredRiskRuleSummaryExists = false;

              if (riskScoreCache && riskScoreCache[ioc.name]) {
                riskScore = riskScoreCache[ioc.name].riskScore;
                criticality = riskScoreCache[ioc.name].criticality;
                triggeredRiskRuleSummaryExists = riskScoreCache[ioc.name].triggeredRiskRuleSummaryExists;
              } else {
                const item = data.results.find(x => x.entity.name === ioc.name);
                if (item && item.risk.context.public.summary && item.risk.context.public.summary.length > 0) {
                  triggeredRiskRuleSummaryExists = true;
                }
                if (item) {
                  riskScore = item.risk.score || item.risk.context.public.score || 0;
                } else {
                  riskScore = 0;
                  noRiskScoreFound = true;
                }

                if (riskScore >= 65) {
                  criticality = 3;
                } else if (riskScore >= 25) {
                  criticality = 2;
                } else {
                  criticality = 1;
                }

                if (criticality > 3) criticality = 3;
                if (criticality < 1) criticality = 1;
              }
              if (!noRiskScoreFound) {
                riskScoreData[ioc.name] = {riskScore, criticality};
              }

              maxCriticality = _updateNotificationsIcon({
                criticality,
                criticalities,
                maxCriticality,
                notificationsIcon
              });
              if (notificationsIcon.textContent) {
                tabHeader.appendChild(notificationsIcon);
              }
              document.querySelectorAll(`li.panel[data-entity="${ioc.name}"]`).forEach(li => {
                if (!noRiskScoreFound) {
                  _showRiskScore({li, riskScore, criticality, name: ioc.name, token, id, triggeredRiskRuleSummaryExists});
                }
              });
            });

            iocs.forEach(ioc => {
              if (!riskScoreData[ioc.name]) {
                document.querySelectorAll(`li.panel[data-entity="${ioc.name}"]`).forEach(li => {
                  const indicator = li.querySelector('.criticalityIndicator');
                  if (indicator.classList.contains('criticalityIndicator--loading')) {
                    indicator.classList.remove('criticalityIndicator--loading');
                    const criticalitySpan = li.querySelector('.criticality__plupp');
                    const scoreSpan = li.querySelector('.riskscore');
                    criticalitySpan.classList.add(`level-1`);
                    scoreSpan.textContent = 0;
                  }
                });
              }
            });

            resolve();
          }).catch(err => {
            console.error(err);
            reject();
          });
      }
    }
  });

  const _getNotes = ({name, token, entityType, cveId}) => new Promise((resolve, reject) => {
    if (freemiumAccount || !hasIntelligenceCard) {
      resolve(null);
    } else if (token) {
      if (!name) {
        reject({});
      }
      let entityName;
      if (entityType === 'idns' || entityType === 'domain') {
        entityName = `idn:${name}`;
      } else if (entityType === 'urls' || entityType === 'url') {
        entityName = `url:${name}`;
      } else if (entityType === 'hashes' || entityType === 'hash') {
        entityName = `hash:${name}`;
      } else if (entityType === 'cves' || entityType === 'vulnerability') {
        entityName = `${cveId}`;
      } else if (entityType === 'ips' || entityType === 'ip') {
        entityName = `ip:${name}`;
      }
      const headers = new Headers({
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/javascript',
        'x-rf-user-agent': 'RFChromeExtension/6.1.4'    // Updated by gulp task "version"!
      });
      _doAPICall({
        url: 'https://api.recordedfuture.com/graphql',
        token,
        method: 'POST',
        headers,
        body: {
          query: `
            query Entity {
              entity(id:"${entityName}") {
                analystNotes(limit:150, cursor:null) {
                  totalCount
                  count
                  cursor
                  documents {
                    title
                    published
                    text
                    source {
                      id
                    }
                  }
                }
              }
            }
          `
        }
      }, '002', false).then((data) => {
        resolve(data);
      })
        .catch(reject);
    }
  });

  const getIntelCardUrl = text => {
    const baseUrl = 'https://app.recordedfuture.com/live/sc/entity/';
    let prefix;
    if (regExpUtil.isIp4(text)) {
      prefix = 'ip:';
      text = regExpUtil.getAllIp4Matches(text)[0];
    } else if (regExpUtil.isIp6(text)) {
      prefix = 'ip:';
      text = regExpUtil.getAllIp6Matches(text)[0];
    } else if (regExpUtil.isIdn(text)) {
      prefix = 'idn:';
      text = regExpUtil.getAllIdnMatches(text)[0];
    } else if (regExpUtil.isHash(text)) {
      prefix = 'hash:';
      text = regExpUtil.getAllHashes(text)[0];
    } else if (regExpUtil.isCve(text)) {
      prefix = '?name=';
    } else {
      prefix = '?name=';
    }
    const ret = text && (baseUrl + prefix + text.toLowerCase());
    return ret;
  }

  /**
   * Call the API to get triggered risk rule data
   *
   * @param name
   * @param token
   * @private
   */
  const _getTriggeredRiskRules = ({name, token}) => new Promise((resolve, reject) => {
    if (riskScoreCache && riskScoreCache[name]) {
      resolve(riskScoreCache[name]);
    } else {
      if (token) {
        if (!name) {
          reject({});
        }
        const url = 'https://express-api.recordedfuture.com/rfq/v2/soar/enrichment';
        const body = {
          ip: [],
          domain: [],
          hash: [],
          url: [],
          vulnerability: []
        };

        if (regExpUtil.isCve(name)) {
          body.vulnerability.push(name);
        } else if (regExpUtil.isIPAddress(name)) {
          body.ip.push(name);
        } else if (regExpUtil.isIdn(name)) {
          body.domain.push(name);
        } else if (regExpUtil.isUrl(name)) {
          const duplicateKey = Object.keys(riskScoreCache).find(x => x !== name && x.toLowerCase() === name);
          if (duplicateKey) {
            name = duplicateKey;
          }
          body.url.push(name);
        } else if (regExpUtil.isHash(name)) {
          body.hash.push(name);
        }

        _doAPICall({url, token, method: 'POST', body}, '003')
          .then((data) => {
            const riskData = data.results[0] || {};
            resolve(riskData);
          })
          .catch(reject);
      }
    }
  });


  /**
   * MAIN METHOD
   * Create the content in the popup if there is anything to render,
   * but first check if the user has a stored token
   *
   * @param response
   */
  async function createPopupHTML(response) {
    const token = await browserModule.getToken(null, '009');
    if (response && response.iocsResult) {
      currentIocs = response.iocsResult;
    }
    chrome.tabs.query({ active: true, currentWindow: true }, async tabs => {
      if (tabs[0] && tabs[0].url) {
        const url = new URL(tabs[0].url);
        const host = url.hostname;
        isLocalFile = url.href.startsWith('file://');
        const path = currentTab.url.split('?')[0];
        isPdf = path.toLowerCase().endsWith('.pdf');
        const isFirefox = typeof InstallTrigger !== 'undefined';
        const isChrome = !isFirefox;

        /* console.log('response', response)
        console.log('localFileAccessAllowed', localFileAccessAllowed)
        console.log('isLocalFile', isLocalFile)
        console.log('isPdf', isPdf) */

        const showPdfScanningNotAvailableMessage = (isLocalFile && isPdf) || (isFirefox && isPdf);

        if (!token) { // dont show any of this if user is logged out
          if (showPdfScanningNotAvailableMessage) {
            document.getElementById('allow-access-instructions').style.display = 'block';
            document.getElementById('loader').classList.add('hidden');
            hideExportButton();
            document.getElementById('loadingIndicator').classList.add('hidden');
            document.querySelector('body').style.minHeight = '331px';
            return;
          } else if (!response || (Object.keys(response) && Object.keys(response).length === 0) && !isPdf) {
            if (document.getElementById('disabled-pagescanning-for-domain').classList.contains('hidden')) {
              if (!isPdf && token) {
                document.getElementById('loader').classList.remove('hidden');
              }
            }
            if (!isPdf) {
              document.getElementById('loadingIndicator').classList.add('hidden');
              document.querySelector('body').style.minHeight = '200px';
            }
          }
        }

        if (token && !showPdfScanningNotAvailableMessage) {
          const jwtToken = JSON.parse(atob(token.split('.')[1]));
          modules = jwtToken.modules ? jwtToken.modules.split(' ').map(x => x = x.replace('module:', '')) : [];

          _trackAction({action: 'BrowserExtensionOpened'});
          document.querySelector('#sign-in').classList.add('hidden');
          document.getElementById('allow-access-instructions').style.display = 'none';

          if (hasSeenDomainAbuseAlertsIntro) {
            document.getElementById('new-feature-intro-box').style.display = 'none';
          }

          // User opened extension popup and is logged in,
          // log this activity timestamp
          chrome.storage.local.set({ lastUsage: Date.now() });

          currentSite = host;
          const settings = await userSettings.getUserSettings();
          currentSettings = settings;

          // Check if current site is blacklisted
          const siteIsBlacklisted = settings.userCustomBlacklist &&
            settings.userCustomBlacklist.some(url => currentSite.match(new RegExp(url, 'g')));

          configureMenu(settings, currentIocs);

          if (response.scanDisabled && !siteIsBlacklisted) {
            return;
          } else if (siteIsBlacklisted) {
            document.getElementById('loader').classList.add('hidden');
            hideExportButton();
            document.getElementById('loadingIndicator').classList.add('hidden');
            document.querySelector('body').style.minHeight = '590px';
            hideSignIn();
            document.getElementById('new-feature-intro-box').style.display = 'none';
            hideElipsisMenu();
            showDisabledPageForSpecificDomain();
            return;
          }

          let iocsResult = response.iocsResult;
          if (!iocsResult) {
            return;
          }
          showHighlightToggle();
          _createPopupHTML({token, iocsResult});
        } else if (!token && !showPdfScanningNotAvailableMessage) {
          document.querySelector('#disabled-pagescanning-for-domain').classList.add('hidden');
          showSignIn();
        }
      }
    });
  }


  /**
   * Create a link element to open an entity as a intel card
   * @param href
   * @param name
   * @private
   */
  const _createLink = ({link: href, name}) => {
    let link;
    // If user is a freemium user then we shouldn't link to intelligence card
    if (freemiumAccount) {
      link = _createElement('span');
    } else {
      link = _createElement('a');
      if (href.includes('?')) {
        link.href = href + '&t_origin=BrowserExtensionDialog';
      } else {
        link.href = href + '?t_origin=BrowserExtensionDialog';
      }
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.title = name;

      // Firefox doesn't close the popup by itself...
      link.addEventListener('click', function () {
        setTimeout(function () {
          window.close();
        }, 50);
      });
    }

    link.textContent = name;
    return link;
  };

  function hideEmptyMessage() {
    document.querySelector('#message').classList.add('hidden');
  }

  function showEmptyMessage() {
    if (document.querySelector('#message')) {
      document.querySelector('#message').classList.remove('hidden');
    }
  }

  function hideThrottledMessage() {
    document.querySelector('#throttled').classList.add('hidden');
  }

  function showThrottledMessage() {
    document.querySelector('#throttled').classList.remove('hidden');
  }

  function hideSignIn() {
    document.querySelector('#sign-in').classList.add('hidden');
    if (hasSeenDomainAbuseAlertsIntro) {
      document.getElementById('new-feature-intro-box').style.display = 'none';
    }
    document.getElementById('loader').classList.remove('hidden');
    showScanUrlsButton();
    showExportButton();
    document.getElementById('loadingIndicator').classList.add('hidden');
    document.querySelector('body').style.minHeight = '200px';
  }

  function showSignIn() {
    document.getElementById('allow-access-instructions').style.display = 'none';
    document.getElementById('new-feature-intro-box').style.display = 'none';
    document.querySelector('#sign-in').classList.remove('hidden');
    document.getElementById('tooManyEntities').classList.add('hidden');
    document.getElementById('loader').classList.add('hidden');
    hideExportButton();
    document.getElementById('loadingIndicator').classList.add('hidden');
  }

  function clearIocList() {
    const iocList = document.getElementById('ioc-list');
    if (iocList) {
      iocList.innerHTML = '';
    }
  }

  function showExportButton() {
    if (freemiumAccount) return; // Never show export button for express users
    document.getElementById('exportButton').classList.remove('hidden');
  }

  function hideExportButton() {
    document.getElementById('exportButton').classList.add('hidden');
  }

  function showScanUrlsButton() {
    if (freemiumAccount) {
      document.getElementById('scanUrlsButton').classList.add('disabled');
    }
    document.getElementById('scanUrlsButton').classList.remove('hidden');
  }

  function hideScanUrlsButton() {
    document.getElementById('scanUrlsButton').classList.add('hidden');
  }

  function showElipsisMenu() {
    document.querySelector('#elipsis-icon').classList.remove('hidden');
  }

  function hideElipsisMenu() {
    document.querySelector('#elipsis-icon').classList.add('hidden');
    hideExportButton();
    hideScanUrlsButton();
  }

  function showHighlightToggle() {
    highlightToggle.style.display = 'block';
  }

  function hideHighlightToggle() {
    highlightToggle.style.display = 'none';
  }

  function hideDropDown() {
    document.querySelector('#menu-list').classList.add('hidden');
    document.querySelector('#highlighting-level-menu').classList.add('hidden');
  }

  function showDropDown() {
    document.getElementById('menu-list').classList.remove('hidden');
    document.getElementById('exportMenu').classList.add('hidden');

    if (typeof InstallTrigger !== 'undefined') { // Firefox
      document.querySelector('body').style.minHeight = '550px';
    }
  }

  function showDisabledPageForSpecificDomain() {
    document.getElementById('disabled-pagescanning-for-domain').classList.remove('hidden');
    document.querySelector('body').style.minHeight = '200px';
    document.querySelector('#elipsis-icon').classList.add('hidden');
    document.getElementById('loader').classList.add('hidden');
    hideExportButton();
    hideScanUrlsButton();
    document.getElementById('loadingIndicator').classList.add('hidden');
  }

  function promptUserToAllowNotifications() {
    if (userHasGrantedNotificationsPermission) return;
    const handleResponse = (granted) => {
      if (granted) {
        _trackAction({action: 'userAllowedNotitifcationsPermission'});
        chrome.runtime.sendMessage({ action: 'userGrantedNotificationsPermission' });
      } else {
        _trackAction({action: 'userDeniedNotitifcationsPermission'});
        chrome.runtime.sendMessage({ action: 'userDeniedNotificationsPermission' });
      }
      userHasGrantedNotificationsPermission = granted;
      chrome.storage.local.set({ userHasGrantedNotificationsPermission: userHasGrantedNotificationsPermission }, () => {
        if (userHasGrantedNotificationsPermission) {
          toggleNotificationsToggle(true);
        } else {
          toggleNotificationsToggle(false);
        }
      });
    }
    if (isFirefox) {
      browser.permissions.request({
        permissions: ['notifications'],
        origins: ['http://*/*', 'https://*/*']
      }).then(granted => {
        handleResponse(granted);
      });
    } else {
      chrome.permissions.request({
        permissions: ['notifications'],
        origins: ['http://*/*', 'https://*/*']
      }, granted => {
        handleResponse(granted);
      });
    }
  }

  /**
   * Render the popup content based on the matching entities found on the current page
   * @param token
   * @param iocsResult
   * @private
   */
  function _createPopupHTML({token, iocsResult}, reloadFromBackground = false, forcePopupRedraw = false, userLoadAllDespiteAmountExceedsLimit = false, callback = null) {
    startTimer('_createPopupHTML');
    currentIocs = iocsResult;
    document.querySelector('body').style.minHeight = '330px';
    if (!keepMenuOpen) {
      hideDropDown();
    } else if (keepMenuOpen && typeof InstallTrigger !== 'undefined') {
      document.querySelector('body').style.minHeight = '590px';
    }

    if (isFirefox) {
      domainAbuseToggle.style.display = 'none';
    }

    document.getElementById('scanUrlsButton').classList.remove('urls-disabled');

    const fetchCurrentSettings = new Promise(resolve => {
      if (currentSettings) {
        resolve(currentSettings)
      } else {
        userSettings.getUserSettings().then(settings => {
          currentSettings = settings;

          resolve(settings);
        });
      }
    });

    startTimer('getUserSettings');
    fetchCurrentSettings.then(settings => {
      endTimer('getUserSettings');
      const entityTypesToShow = settings.entityTypesToShow;

      const siteIsBlacklisted = token && settings.userCustomBlacklist &&
        settings.userCustomBlacklist.some(url => currentSite.match(new RegExp(url, 'g')));

      if (siteIsBlacklisted) {
        return;
      }

      document.getElementById('tooManyEntities').classList.add('hidden');
      cachedIocResult = iocsResult;
      // Since we have content to show, hide the reload button
      if (!isPdf) {
        document.querySelector('body').style.minHeight = '200px';
        document.getElementById('loader').classList.add('hidden');
      }
      showExportButton();
      showScanUrlsButton();
      document.getElementById('loadingIndicator').classList.add('hidden');

      let iocLists = iocsResult.matches;
      const iocListElement = document.getElementById('ioc-list');
      iocListElement.innerHTML = '';

      const urls = iocLists.find(x => x.type === 'urls');
      if (urls && urls.iocs) {
        urls.iocs.forEach(ioc => {
          if (ioc.fromPlainText && ioc.riskData && ioc.riskData.riskScore === 0) {
            const duplicate = urls.iocs.find(x => x.name.toLowerCase() === ioc.name && x.riskData.riskScore > 0);
            if (duplicate) {
              ioc.riskData = duplicate.riskData;
            }
          }
        });
      }

      // Sorts the IOC types by amount of iocs found under each category
      iocLists.sort((a, b) => {
        let aIocs = a.iocs;
        let bIocs = b.iocs;
        if (a.type === 'urls') {
          aIocs = aIocs.filter(x => (x.fromPlainText || (x.fromLink && x.riskData && x.riskData.riskScore >= 65)));
        }
        if (b.type === 'urls') {
          bIocs = bIocs.filter(x => (x.fromPlainText || (x.fromLink && x.riskData && x.riskData.riskScore >= 65)));
        }

        return bIocs.length - aIocs.length
      });

      // TODO if google.com and www.google.com are both present then remove one of them

      // Get all IOC:s from all categories and put them in its own category for 'All'
      const allIocs = iocLists.reduce((total, current) => {
        if (current.type === 'urls' && !entityTypesToShow.url) {
          return total;
        } else if (current.type === 'idns' && !entityTypesToShow.domain) {
          return total;
        } else if (current.type === 'hashes' && !entityTypesToShow.hash) {
          return total;
        } else if (current.type === 'cves' && !entityTypesToShow.vulnerability) {
          return total;
        } else if (current.type === 'ips' && !entityTypesToShow.ip) {
          return total;
        }

        let iocs = current.iocs.map(x => Object.assign(x, { type: current.type }));
        iocs.forEach(ioc => {
          if (riskScoreCache && riskScoreCache[ioc.name]) {
            ioc.riskData = riskScoreCache[ioc.name];
          }
        });
        if (current.type === 'urls') {
          iocs = iocs.filter(x => x.fromPlainText || (x.fromLink && x.riskData && x.riskData.riskScore >= 65));

          iocs = iocs.reduce((t, c) => {
            if (!t.find(x => x.name === c.name)) t.push(c);
            return t;
          }, []);
        }
        return [...total, ...iocs];
      }, []);

      // Filter out URL duplicates
      const urlList = iocLists.find(x => x.type === 'urls');
      if (urlList && urlList.iocs && urlList.iocs.length > 0) {
        urlList.iocs = urlList.iocs.reduce((t, c) => {
          if (!t.find(x => x.name === c.name)) t.push(c);
          return t;
        }, []);
      }
      iocLists.forEach(list => {
        list.iocs.forEach(ioc => {
          if (riskScoreCache && riskScoreCache[ioc.name]) {
            ioc.riskData = riskScoreCache[ioc.name];
          }
        });
      });

      const allEntityTypesDisabled = (!entityTypesToShow.domain &&
        !entityTypesToShow.url &&
        !entityTypesToShow.hash &&
        !entityTypesToShow.vulnerability &&
        !entityTypesToShow.ip);
      const showMaliciousLinksTab = settings.disableMaliciousLinks &&
        iocLists.find(x => x.type === 'urls') &&
        iocLists.find(x => x.type === 'urls').iocs.filter(x => x.fromLink && x.riskData && x.riskData.riskScore >= 65).length > 0;

      if (allIocs.length > config.MAX_AMOUNT_OF_ENTITIES_FOR_HIGHLIGHTING) {
        pageContainsTooManyEntitiesForHighlighting = true;
      }

      if (!userLoadAllDespiteAmountExceedsLimit && (!ignoreTooManyHits && allIocs.length > config.MAX_AMOUNT_OF_ENTITIES)) {
        // Check in background if the current page has already recently been manually loaded by user, in which case we don't need to prompt the user again
        startTimer('checkIfApproved');
        chrome.runtime.sendMessage({ action: 'currentPageIsApproved' }, response => {
          endTimer('checkIfApproved');
          if (response) {
            hideExportButton();
            hideScanUrlsButton();
            document.getElementById('loadingIndicator').classList.remove('hidden');
            tooManyEntitiesForceLoad = true;
            const entitiesAsList = cachedIocResult.matches.reduce((total, current) => [...total, ...current.iocs], []);
            chrome.runtime.sendMessage({ action: 'fetchRiskScores', iocs: entitiesAsList, tabId: currentTab.id });
          } else {
            showTooManyEntitiesMessage();
            return;
          }
        });
      } else {
        if (allEntityTypesDisabled && !showMaliciousLinksTab) {
          const wrapper = _createElement('div', 'tabs__header-wrapper');
          const allTab = _createElement('div', 'tab__header all active disabled');

          const span1 = _createElement('span', 'tab__header-title');
          span1.textContent = 'All';
          const span2 = _createElement('span', 'all ioc-count');
          span2.textContent = '0';

          allTab.appendChild(span1);
          allTab.appendChild(span2);
          wrapper.appendChild(allTab);
          iocListElement.appendChild(wrapper);

          const noEntityTypesEnabledMessage = document.createElement('div');
          noEntityTypesEnabledMessage.id = 'noEntityTypesEnabledMessage';

          const noEntityTypesEnabledMessageInner = document.createElement('div');
          noEntityTypesEnabledMessageInner.id = 'noEntityTypesEnabledMessageInner';
          noEntityTypesEnabledMessageInner.textContent = 'All entity types are currently disabled. Reset to the default settings to display IOCs and vulnerabilities.'

          const button = _createElement('button', 'button');
          button.textContent = 'RESET';
          button.style.margin = 'inherit';
          button.style.marginTop = '10px';
          noEntityTypesEnabledMessageInner.appendChild(button);

          button.addEventListener('click', () => {
            userSettings.getUserSettings().then(settings => {
              currentSettings = settings;

              settings.entityTypesToShow = {
                domain: true,
                url: false,
                hash: true,
                vulnerability: true,
                ip: true
              };
              userSettings.saveNewSettings(settings);

              document.querySelector('#entity-type-hash-toggle .switch').classList.add('active');
              document.querySelector('#entity-type-vulnerability-toggle .switch').classList.add('active');
              document.querySelector('#entity-type-ip-toggle .switch').classList.add('active');
              document.querySelector('#entity-type-url-toggle .switch').classList.remove('active');
              document.querySelector('#entity-type-domain-toggle .switch').classList.add('active');

              if (currentTab) {
                chrome.tabs.sendMessage(currentTab.id, {action: 'updateEntityOptions'});
              }
            });
          });

          noEntityTypesEnabledMessage.append(noEntityTypesEnabledMessageInner);

          document.getElementById('new-feature-intro-box').style.display = 'none';

          iocListElement.append(noEntityTypesEnabledMessage);

          if (document.getElementById('no-iocs-found').style.display === 'block') {
            document.getElementById('no-iocs-found').style.display = 'none';
          }
          hideExportButton();
          hideScanUrlsButton();
        } else {
          showTooManyEntitiesForHighlightingMessage = allIocs.length > config.MAX_AMOUNT_OF_ENTITIES_FOR_HIGHLIGHTING && !currentPageHasAllowedHighlightingDespiteExceedingEntityLimit;

          if (showNewFeatureIntro) {
            document.getElementById('new-feature-intro-box').style.display = 'flex';
          }
          if (showTooManyEntitiesForHighlightingMessage && !isPdf) {
            document.getElementById('over-400-entities-highlighting-disabled').classList.remove('hidden');
            document.querySelector('#highlighting-toggle .switch').classList.remove('active');
            if (isFirefox) {
              document.querySelectorAll('.tab__content ul').forEach(list => list.style.maxHeight = '200px');
            }
          } else {
            //document.querySelectorAll('.tab__content ul').forEach(list => list.style.maxHeight = maxHeight + 'px');
          }

          const allObj = {
            iocs: allIocs,
            label: 'All',
            supportLink: undefined,
            supportTitle: undefined,
            type: 'all',
          };
          iocLists = [allObj, ...iocLists];

          const noIocsFound = allIocs.length === 0;

          // If _createPopupHTML is called because new risk score data sent has been sent from background
          // then we must clear old ioc list before we can draw the GUI again. Otherwise there will be 2 ioc lists
          clearIocList();

          const tabHeaderWrapper = _createElement('div', 'tabs__header-wrapper');
          iocListElement.appendChild(tabHeaderWrapper);
          const tabContentWrapperOuter = _createElement('div', 'tabs__content-wrapper__outer');

          iocListElement.appendChild(tabContentWrapperOuter);
          const tabContentWrapper = _createElement('div', 'tabs__content-wrapper');
          tabContentWrapperOuter.appendChild(tabContentWrapper);
          const tabFooterWrapper = _createElement('div', 'tabs__footer-wrapper');
          iocListElement.appendChild(tabFooterWrapper);

          if (showNewFeatureIntro) {
            if (freemiumAccount) {
              tabContentWrapperOuter.style.maxHeight = '170px';
              tabContentWrapper.style.maxHeight = '170px';
            } else {
              tabContentWrapperOuter.style.maxHeight = '240px';
              tabContentWrapper.style.maxHeight = '240px';

              if (isFirefox) {
                setTimeout(() => {
                  document.querySelectorAll('.tabs__content-wrapper ul').forEach(x => x.style.maxHeight = '240px');
                }, 1000);
              }
            }
          }
          if (showTooManyEntitiesForHighlightingMessage) {
            if (freemiumAccount) {
              tabContentWrapperOuter.style.maxHeight = '170px';
              tabContentWrapper.style.maxHeight = '170px';
            } else if (isPdf) {
              tabContentWrapperOuter.style.maxHeight = 'auto';
              tabContentWrapper.style.maxHeight = 'auto';
            } else {
              tabContentWrapperOuter.style.maxHeight = '240px';
              tabContentWrapper.style.maxHeight = '240px';

              if (isFirefox) {
                setTimeout(() => {
                  document.querySelectorAll('.tabs__content-wrapper ul').forEach(x => x.style.maxHeight = '200px');
                }, 1000);
              }
            }
          }
          if (showNewFeatureIntro && showTooManyEntitiesForHighlightingMessage) { // show both message boxes
            document.getElementById('new-feature-intro-box').style.marginTop = '0px';
            document.getElementById('over-400-entities-highlighting-disabled').style.marginBottom = '10px';
          }

          tabContentWrapperOuter.style.marginBottom = '30px';

          let max = {
            count: -1,
            id: '',
            index: 0
          };

          let numberOfSections = 0;

          const showUrlNewInformation = (!entityTypesToShow.url && !window.localStorage.getItem('hasSeenUrlTabIntro'));

          let allEntityTypesDisabledAndNoMaliciousLinks = false;

          if (allEntityTypesDisabled && showMaliciousLinksTab) {
            hideExportButton();
            hideScanUrlsButton();

            iocLists = iocLists.filter(x => x.type === 'urls');
            const item = iocLists.find(x => x.type === 'urls');

            item.iocs.forEach(ioc => {
              if (riskScoreCache && riskScoreCache[ioc.name]) {
                ioc.riskData = riskScoreCache[ioc.name];
              }
            });
            item.iocs = item.iocs.filter(x => x.riskData && x.riskData.riskScore >= 65);

            if (item.iocs.length === 0) {
              allEntityTypesDisabledAndNoMaliciousLinks = true;
            }

            item.label = 'Potentially Malicious Links';
            item.iocs = item.iocs.filter(x => x.fromLink);

            document.getElementById('no-iocs-found').style.display = 'none';
          } else {
            if (showUrlNewInformation) { // If user is new to version 4.3.0 then we should show an intro for URL entity type
              if (iocLists.find(x => x.type === 'urls')) {
                const item = iocLists.find(x => x.type === 'urls');
                item.iocs = item.iocs.filter(x => (x.fromPlainText || (x.fromLink && x.riskData && x.riskData.riskScore >= 65)));
                item.intro = true;
              } else {
                iocLists.push({
                  label: 'URL',
                  type: 'urls',
                  supportLink: 'https://support.recordedfuture.com/hc/en-us/articles/115010052768',
                  supportTitle: 'URL risk rules',
                  intro: true,
                  iocs: []
                });
              }
            } else {
              if (!entityTypesToShow.url) {
                iocLists = iocLists.filter(x => x.type !== 'urls');
              } else if (iocLists.find(x => x.type === 'urls')) {
                const item = iocLists.find(x => x.type === 'urls');
                item.iocs = item.iocs.filter(x => (x.fromPlainText || (x.fromLink && x.riskData && x.riskData.riskScore >= 65)));

                if (item.iocs.length === 0) {
                  item.intro = true;
                }
              }
            }
          }

          if (
            iocLists.find(x => x.type === 'urls') &&
            iocLists.find(x => x.type === 'urls').iocs.length === 0 &&
            !forceShowUrlTab &&
            !entityTypesToShow.url &&
            window.localStorage.getItem('hasSeenUrlTabIntro')
          ) {
            iocLists = iocLists.filter(x => x.type !== 'urls');
          }

          if ((noIocsFound && !(allEntityTypesDisabled && showMaliciousLinksTab)) || allEntityTypesDisabledAndNoMaliciousLinks) {
            document.querySelector('.tabs__content-wrapper__outer').style.marginBottom = '0px';
            document.getElementById('no-iocs-found').style.display = 'block';
            hideExportButton();
            hideScanUrlsButton();
          } else {
            document.getElementById('no-iocs-found').style.display = 'none';
          }

          let listsThatAreNotSorted = [];

          startTimer('new_sort_method');

          const urlList = iocLists.find(x => x.type === 'urls');
          if (urlList) {
            urlList.iocs.forEach(urlIoc => {
              if (urlIoc.redirect && !urlIoc.redirect.risk) {
                // If URL-IoC misses redirect-link-risk-data then get it from the cache
                const it = riskScoreCache[urlIoc.name];
                if (it && it.redirect && it.redirect.risk) {
                  urlIoc.redirect.risk = it.redirect.risk;
                }
              }
            })
          }
          iocLists.forEach(list => {
            const allEntitiesInListHaveRiskScores = list.iocs.every(
              ioc =>
                (ioc.riskData && ioc.riskData.riskScore >= 0) ||
                (ioc.redirect && ioc.redirect.risk)
            );
            if (allEntitiesInListHaveRiskScores) {
              list.iocs.sort((a, b) => {
                let aRiskScore = (a.redirect && a.redirect.risk) ? a.redirect.risk.score : a.riskData.riskScore;
                let bRiskScore = (b.redirect && b.redirect.risk) ? b.redirect.risk.score : b.riskData.riskScore;

                if (!aRiskScore && a.redirect && a.redirect.redirectsTo && riskScoreCache[a.redirect.redirectsTo]) {
                  aRiskScore = riskScoreCache[a.redirect.redirectsTo].riskScore;
                }
                if (!bRiskScore && b.redirect && b.redirect.redirectsTo && riskScoreCache[b.redirect.redirectsTo]) {
                  bRiskScore = riskScoreCache[b.redirect.redirectsTo].riskScore;
                }

                return bRiskScore - aRiskScore;
              });
            } else {
              listsThatAreNotSorted.push(list.type);
            }
          });
          endTimer('new_sort_method');

          iocLists.forEach(iocList => {
            if (iocList.type === 'all' ||
              (iocList.type === 'idns' && entityTypesToShow.domain) ||
              ((iocList.type === 'urls' && entityTypesToShow.url) || (iocList.type === 'urls' && showUrlNewInformation) || (iocList.type === 'urls' && showMaliciousLinksTab)) ||
              (iocList.type === 'hashes' && entityTypesToShow.hash) ||
              (iocList.type === 'cves' && entityTypesToShow.vulnerability) ||
              (iocList.type === 'ips' && entityTypesToShow.ip))
            {
              let iocs = iocList.iocs;

              if (iocList.type === 'urls' && !iocList.intro && !showMaliciousLinksTab) {
                iocs = iocs.filter(x => (x.fromPlainText || (x.fromLink && x.riskData && x.riskData.riskScore >= 65)));
              }

              const numberOfIocs = iocs.length;
              const id = `${iocList.label.replace(/\s/g, '').toLowerCase()}`;

              const tabHeader = _createElement('div', 'tab__header');
              const tabTitle = _createElement('span', 'tab__header-title');

              const tabFooter = _createElement('div', 'tab__footer');

              tabTitle.textContent = iocList.label;
              tabHeader.appendChild(tabTitle);

              tabHeader.classList.add(id);
              tabHeaderWrapper.appendChild(tabHeader);

              if (freemiumAccount) {
                const learnMoreFooterLink = _createElement('span', 'tab__footer-link');
                const dividerText = _createElement('span', 'tab__footer-text');
                const requestDemoFooterLink = _createElement('span', 'tab__footer-link');

                learnMoreFooterLink.textContent = 'Upgrade';
                dividerText.textContent = ' | ';
                requestDemoFooterLink.textContent = 'Request Demo';

                dividerText.style.marginRight = '0';

                let upgradeLink;
                let requestDemoLink;

                if (typeof InstallTrigger !== 'undefined') { // Firefox
                  upgradeLink = 'https://www.recordedfuture.com/license-options/?utm_campaign=express&utm_source=firefox-extension&utm_medium=affiliate';
                  requestDemoLink = 'https://go.recordedfuture.com/demo?utm_campaign=express&utm_source=firefox-extension&utm_medium=affiliate'
                } else { // Chrome
                  upgradeLink = 'https://www.recordedfuture.com/license-options/?utm_campaign=express&utm_source=chrome-extension&utm_medium=affiliate';
                  requestDemoLink = 'https://go.recordedfuture.com/demo?utm_campaign=express&utm_source=chrome-extension&utm_medium=affiliate';
                }

                if (document.querySelector('.exportButtonTooltip .upgradeTooltipLink')) {
                  document.querySelector('.exportButtonTooltip .upgradeTooltipLink').addEventListener('click', () => {
                    window.open(upgradeLink);
                  });
                }
                learnMoreFooterLink.addEventListener('click', () => {
                  window.open(upgradeLink);
                });
                requestDemoFooterLink.addEventListener('click', () => {
                  window.open(requestDemoLink);
                });

                tabFooter.appendChild(learnMoreFooterLink);
                tabFooter.appendChild(dividerText);
                tabFooter.appendChild(requestDemoFooterLink);
              } else if (iocList.supportTitle) {
                const footerText = _createElement('span', 'tab__footer-text');
                const footerLink = _createElement('span', 'tab__footer-link');

                footerText.textContent = 'Learn more about ';
                footerLink.textContent = iocList.supportTitle;

                tabFooter.appendChild(footerText);
                tabFooter.appendChild(footerLink);
              }

              tabFooter.classList.add(id);
              tabFooterWrapper.appendChild(tabFooter);

              const countLabel = _createElement('span', iocList.type + ' ioc-count');
              if (iocList.intro && !window.localStorage.getItem('hasSeenUrlTabIntro')) {
                countLabel.textContent = 'new';
                countLabel.classList.add('newLabel')
              } else {
                countLabel.textContent = numberOfIocs;
              }
              tabHeader.appendChild(countLabel);

              tabFooter.classList.add('hidden');

              if (
                (iocList.type !== 'urls' && numberOfIocs === 0) ||
                (numberOfIocs === 0 && iocList.type === 'urls' && !userClickedUrlTabEnableButton && !iocList.intro) ||
                (numberOfIocs === 0 && iocList.type === 'urls' && !userClickedUrlTabEnableButton && window.localStorage.getItem('hasSeenUrlTabIntro'))
              ) {
                tabHeader.classList.add('disabled');
                tabFooter.classList.add('disabled');
                return;
              }

              tabHeader.setAttribute('data-tab-target', numberOfSections);
              tabFooter.setAttribute('data-footer-target', numberOfSections);

              numberOfSections += 1;

              tabHeader.addEventListener('click', () => {
                if (iocList.intro) {
                  window.localStorage.setItem('hasSeenUrlTabIntro', true);
                  if (document.querySelector('.urls.newLabel')) {
                    document.querySelector('.urls.newLabel').remove();
                  }
                }

                tabHeaderWrapper.querySelectorAll('.tab__header').forEach(tab => tab.classList.remove('active'));
                tabFooterWrapper.querySelectorAll('.tab__footer')
                  .forEach(tab => tab.classList.remove('active') && tab.classList.add('hidden'));
                tabHeader.classList.add('active');
                tabFooter.classList.add('active');

                const activeTab = tabHeader.getAttribute('data-tab-target');

                currentSelectedTab = {
                  index: Number(activeTab),
                  label: id
                };

                tabContentWrapper.setAttribute('data-active-tab', activeTab);

                const list = [...document.querySelectorAll('.tab__header')].filter(x => !x.classList.contains('disabled'))
                if (list && list.length) {
                  const index = list.indexOf(list.find(x => x.classList.contains(id)))
                  if (index !== undefined) {
                    let left = index * 100;
                    tabContentWrapper.style.left = `-${left}%`;
                  }
                }

                _trackAction({action: 'BrowserExtensionResultFiltered', type: id});
              });

              if (iocList.supportLink) {
                tabFooter.addEventListener('click', () => {
                  var supportUrl = iocList.supportLink;
                  _trackAction({action: 'BrowserExtensionResultLearnMore', type: id});
                  window.open(supportUrl);
                });
              }

              if (numberOfIocs > max.count) {
                max.count = numberOfIocs;
                max.label = id;
                max.index = numberOfSections - 1;
              }

              const tabContent = _createElement('div', `tab__content`);
              tabContent.id = id;
              tabContentWrapper.appendChild(tabContent);

              if (iocList.intro) {
                if (window.localStorage.getItem('hasSeenUrlTabIntro') && iocList.iocs.length === 0 && reloadFromBackground) {
                  const noEntitiesBox = _createElement('div');
                  noEntitiesBox.style.padding = '24px';
                  noEntitiesBox.style.backgroundColor = 'white';
                  noEntitiesBox.classList.add('noEntities');
                  noEntitiesBox.textContent = 'This page does not contain any identifiable IOCs or vulnerabilities.';
                  tabContent.appendChild(noEntitiesBox);

                  if (document.querySelector('.tab__content#url .noEntities').style.display !== 'none' && document.querySelector('#no-iocs-found').style.display === 'block') {
                    document.querySelector('#no-iocs-found').style.display = 'none';
                  }
                } else {
                  const introDiv = _createElement('div', 'introDiv');

                  const secondDiv = _createElement('div');
                  const firstSpan = _createElement('div');
                  firstSpan.textContent = 'In-Page URL scanning';
                  firstSpan.classList.add('title');
                  const secondSpan = _createElement('div', 'description');
                  secondSpan.textContent = 'The Recorded Future Browser Extension now scans in-page URLs. When these options are enabled, in-page links are processed by Recorded Future, who may use this data to provide the service, develop and improve its offerings, and otherwise in its business.';
                  secondSpan.style.textAlign = 'center';
                  const button = _createElement('button', 'button semibold');
                  button.classList.add('enableButton');
                  button.textContent = 'Enable';
                  forceShowUrlTab = true;

                  secondDiv.appendChild(firstSpan);
                  secondDiv.appendChild(secondSpan);
                  secondDiv.appendChild(button);

                  button.addEventListener('click', () => {
                    introDiv.style.display = 'none';
                    window.localStorage.setItem('hasSeenUrlTabIntro', true);
                    userClickedUrlTabEnableButton = true;

                    userSettings.getUserSettings().then(settings => {
                      currentSettings = settings;

                      settings.entityTypesToShow.url = true;
                      userSettings.saveNewSettings(settings);

                      _trackAction({action: 'BrowserExtensionSettingsUrlEnabled'});
                      document.querySelector('#entity-type-url-toggle .switch').classList.add('active');

                      if (currentTab) {
                        chrome.tabs.sendMessage(currentTab.id, {action: 'updateEntityOptions'});
                      }
                    });
                  });

                  introDiv.appendChild(secondDiv);

                  tabContent.appendChild(introDiv);
                }
              } else if (numberOfIocs) {
                const list = _createElement('ul');

                // Now we have a list of matching entities that we want to put in the 'list' element
                iocs.forEach(ioc => {
                  // Each list item has a row with the entity name and count, and there might be
                  // an expanding section with matching risk rules
                  const li = _createElement('li', 'panel');
                  // Add the entity name as an attribute to the list item,
                  // so we can sort them by name after we sort by risk score is
                  li.setAttribute('data-entity', ioc.name);
                  li.setAttribute('ioc-type', ioc.type);

                  // The panel header element the name of the entity and possibly an expanding icon
                  const panelHeader = _createElement('div', 'panel__header');

                  // The panel entity element contains a link to an intelcard and
                  // possibly a criticality indicator with a risk score or just a non clickable title (express)
                  const panelEntity = _createElement('div', 'panel__entity');

                  const link = _createLink(ioc);

                  if (token) {
                    // The user has added an API token, let's query the API for risk score data
                    // The indicator element has two spans, one for the critiycality plupp and one for the riskscoew
                    const indicator = _createElement('div', 'criticalityIndicator criticalityIndicator--loading');
                    const criticalitySpan = _createElement('span', `criticality__plupp`);
                    const scoreSpan = _createElement('span', 'riskscore');

                    indicator.appendChild(criticalitySpan);
                    indicator.appendChild(scoreSpan);

                    panelEntity.appendChild(indicator);
                    panelEntity.appendChild(link);

                    if (ioc.redirect && ioc.redirect.redirectsTo && ioc.redirect.redirectsTo !== ioc.name) {
                      link.classList.add('hasRedirect');

                      const arrow = _createElement('div', 'redirectArrow');
                      arrow.innerHTML = `
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                      <g id="arrow_right_alt" clip-path="url(#clip0_1501_2776)">
                      <path id="Vector" d="M16.01 11H4V13H16.01V16L20 12L16.01 8V11Z" fill="#222222"/>
                      </g>
                      <defs>
                      <clipPath id="clip0_1501_2776">
                      <rect width="24" height="24" fill="white"/>
                      </clipPath>
                      </defs>
                      </svg>
                      `;
                      arrow.style.paddingLeft = '5px';
                      arrow.style.paddingRight = '5px';
                      arrow.style.marginTop = '5px';
                      panelEntity.appendChild(arrow);

                      arrow.addEventListener('mouseover', ev => {
                        userHoveringTooltip = true;
                        let el = arrow;
                        const bboxForIcon = el.getBoundingClientRect();
        
                        let tooltipToShow = document.getElementById('redirectTooltip');
                        const bboxForTooltip = tooltipToShow.getBoundingClientRect();
        
                        const displayTooltipAbove = bboxForIcon.top >= 250;
        
                        tooltipToShow.style.left = ((bboxForIcon.left + (bboxForIcon.width / 2)) - (bboxForTooltip.width / 2)) - 14 + 'px';
                        if (displayTooltipAbove) {
                          tooltipToShow.querySelector('.arrow.top').style.display = 'none';
                          tooltipToShow.querySelector('.arrow.bottom').style.display = 'block';
                          tooltipToShow.style.top = (bboxForIcon.top - bboxForTooltip.height) + 10 + 'px';
                        } else {
                          tooltipToShow.querySelector('.arrow.top').style.display = 'block';
                          tooltipToShow.querySelector('.arrow.bottom').style.display = 'none';
                          tooltipToShow.style.top = (bboxForIcon.top + bboxForIcon.height) - 10 + 'px';
                        }
                        setTimeout(() => {
                          tooltipToShow.style.visibility = 'visible';
                        }, 10);
                      });
                      arrow.addEventListener('mouseout', ev => {
                        userHoveringTooltip = false;
                        setTimeout(() => {
                          if (!userHoveringTooltip) {
                            document.querySelectorAll('.noteInfoTooltip').forEach(x => {
                              x.style.visibility = 'hidden';
                            });
                          }
                        }, 10);
                      });

                      const redirectsToLink = _createElement('a', 'redirectLink');
                      redirectsToLink.setAttribute('href', getIntelCardUrl(ioc.redirect.redirectsTo));
                      redirectsToLink.setAttribute('title', ioc.redirect.redirectsTo);
                      redirectsToLink.setAttribute('target', '_blank');
                      redirectsToLink.setAttribute('rel', 'noopener noreferrer');

                      redirectsToLink.innerText = ioc.redirect.redirectsTo;
                      panelEntity.appendChild(redirectsToLink);
                    }

                    if (iocList.type === 'all') {
                      const iocType = _createElement('span', 'ioc-type');
                      iocType.textContent = iocTypeTexts[ioc.type] || '';
                      panelEntity.appendChild(iocType);
                    }
                    panelHeader.appendChild(panelEntity);
                    li.appendChild(panelHeader);
                  } else {
                    panelEntity.appendChild(link);
                    panelHeader.append(panelEntity);
                    li.appendChild(panelHeader);
                  }
                  const line = _createElement('div', 'line');
                  li.appendChild(line);

                  list.appendChild(li);
                });
                if (showNewFeatureIntro) {
                  if (freemiumAccount) {
                    //list.style.maxHeight = '163px';
                  } else if (getComputedStyle(document.getElementById('over-400-entities-highlighting-disabled')).display === 'block' &&
                    document.getElementById('new-feature-intro-box').style.display === 'block') {
                    list.style.maxHeight = '163px';
                  } else {
                    list.style.maxHeight = '200px';
                  }
                }
                tabContent.appendChild(list);
              }
            }
          });

          startTimer('handleIocLists');
          handleIocLists(iocLists, token, entityTypesToShow, showUrlNewInformation, showMaliciousLinksTab).then(() => {
            // This is to fix a very specific bug where the IoCs list would not properly sort themself
            // on certain pages (RFPD-8297). This is because not all list items have a data-riskScore attribute set
            // in which case we use helper function allRiskScoresAreSet and add a short setTimeout to attempt to fix this
            const allRiskScoresAreSet = () => [...document.querySelectorAll('.tab__content#all li')].every(x => x.getAttribute('data-riskscore'))
            const amountOfClickableLabels = document.querySelectorAll('.tab__header:not(.disabled)').length;
            tabContentWrapper.style.width = `${amountOfClickableLabels}00%`;
            const index = currentSelectedTab && currentSelectedTab.index ? currentSelectedTab.index : max.index;
            const label = currentSelectedTab && currentSelectedTab.label ? currentSelectedTab.label : max.label;
            const currentTabHeader = tabHeaderWrapper.querySelector(`.${label}`);
            const currentTabFooter = tabFooterWrapper.querySelector(`.${label}`);
            if (currentTabHeader) {
              currentTabHeader.classList.add('active');
              currentTabFooter.classList.add('active');
            }
            tabContentWrapper.setAttribute('data-active-tab', index);

            setTimeout(async () => {
              endTimer('handleIocLists');

              let lis = [];
              listsThatAreNotSorted.forEach(type => {
                const tabContent = document.querySelector(`.tab__content#${type}`);
                if (tabContent) {
                  const tabContentPanels = [...tabContent.querySelectorAll('li.panel')];
                  if (tabContentPanels && tabContentPanels.length > 0) {
                    lis = [...lis, ...tabContentPanels];
                  }
                }
              });
              if (lis.length > 0) {
                startTimer('_sortByRiskScore');
                document.querySelectorAll(`li.panel[data-entity]`).forEach(li => {
                  _sortByRiskScore(li);
                });
                endTimer('_sortByRiskScore');
              }

              // If there are no matches at all, at least the user some indication of that.
              if (!iocsResult.matches.find(ms => ms.iocs.length)) {
                showEmptyMessage();
              } else {
                const index = currentSelectedTab && currentSelectedTab.index ? currentSelectedTab.index : max.index;
                const label = currentSelectedTab && currentSelectedTab.label ? currentSelectedTab.label : max.label;

                const currentTabHeader = tabHeaderWrapper.querySelector(`.${label}`);
                const currentTabFooter = tabFooterWrapper.querySelector(`.${label}`);
                if (currentTabHeader) {
                  currentTabHeader.classList.add('active');
                  currentTabFooter.classList.add('active');
                }
                tabContentWrapper.setAttribute('data-active-tab', index);

                tabContentWrapper.style.width = `${numberOfSections}00%`;
              }

              startTimer('_createPopupHTML_callback');
              if (callback) {
                callback();
                endTimer('_createPopupHTML_callback');
              }

              // Check if there is anything to create a list from
              chrome.runtime.sendMessage({ action: 'getFullAccessList' }, resp => {
                fullAccessList = resp;
                let entities = [];
                if (fullAccessList.idn) {
                  const items = [...document.querySelectorAll(`.tab__content#domain ul li`)];
                  entities = [...entities, ...items];
                }
                if (fullAccessList.ip) {
                  const items = [...document.querySelectorAll(`.tab__content#ipaddress ul li`)];
                  entities = [...entities, ...items];
                }
                if (fullAccessList.hash) {
                  const items = [...document.querySelectorAll(`.tab__content#hash ul li`)];
                  entities = [...entities, ...items];
                }
                if (fullAccessList.url) {
                  const items = [...document.querySelectorAll(`.tab__content#url ul li`)];
                  entities = [...entities, ...items];
                }
                if (fullAccessList.cve) {
                  const items = [...document.querySelectorAll(`.tab__content#vulnerability ul li`)];
                  entities = [...entities, ...items];
                }
                if (entities.length === 0) { // There are no entities to create a list with, hide button
                  document.getElementById('export-menu-option-custom-list').classList.add('hidden');
                }
              });

              await setScanUrlsButton();
              endTimer('_createPopupHTML');
            }, allRiskScoresAreSet() ? 1 : 1000);
          }).catch(err => {
            console.warn(err);
          });
        }
      }
    });
  }

  async function setScanUrlsButton() {
    browserModule.getStorage().then(async storage => {
      const urlsThatAreNotWhiteListed = await getURLsThatAreNotWhiteListed();
      const settings = await userSettings.getUserSettings();

      if (hasMalwareSandboxPermission && urlsThatAreNotWhiteListed.length > 0 && storage.scope && storage.scope.includes('Modules') && settings.entityTypesToShow.url) {
        document.getElementById('scanUrlsButton').classList.remove('disabled');
        document.getElementById('scanUrlsButton').classList.remove('urls-disabled');
        document.getElementById('scanUrlsButton').classList.remove('noPermission');
      } else if (hasMalwareSandboxPermission && storage.scope && storage.scope.includes('Modules') && !settings.entityTypesToShow.url) {
        document.getElementById('scanUrlsButton').classList.add('disabled');
        document.getElementById('scanUrlsButton').classList.add('urls-disabled');
        document.querySelector('.scanUrlsTooltip .inner').innerText = 'To use this feature you must first enable the URL entity type under Settings'
      } else {
        document.getElementById('scanUrlsButton').classList.add('disabled');
      }
    });
  }

  function handleIocLists (iocLists, token, entityTypesToShow, showUrlNewInformation, showMaliciousLinksTab) {
    const promises = [];
    startTimer('iocListsLoop');
    iocLists.forEach(iocList => {
      if (iocList.type === 'all' ||
        (iocList.type === 'idns' && entityTypesToShow.domain) ||
        ((iocList.type === 'urls' && entityTypesToShow.url) || (iocList.type === 'urls' && showUrlNewInformation) || (iocList.type === 'urls' && showMaliciousLinksTab)) ||
        (iocList.type === 'hashes' && entityTypesToShow.hash) ||
        (iocList.type === 'cves' && entityTypesToShow.vulnerability) ||
        (iocList.type === 'ips' && entityTypesToShow.ip))
      {
        if (token) {
          const id = `${iocList.label.replace(/\s/g, '').toLowerCase()}`;
          const tabHeader = document.querySelector(`.tab__header.${id}`);

          let iocs = iocList.iocs;
          if (iocList.type === 'urls' && !iocList.intro && !showMaliciousLinksTab) {
            iocs = iocs.filter(x => (x.fromPlainText || (x.fromLink && x.riskData && x.riskData.riskScore >= 65)));
          }
          if (!(iocList.type === 'urls' && !entityTypesToShow.url) && iocs.length > 0) {
            const promise = _getRiskScoreData(iocs, token, id, tabHeader, entityTypesToShow).catch((e) => {
              console.error(e);
            });
            promises.push(promise);
          }
        }
      }
    });
    endTimer('iocListsLoop');
    return Promise.all(promises);
  }

  /**
   * Keep track of the highest criticality level for this section, and the number of IOCs with that criticality
   * @param criticality
   * @param criticalities
   * @param maxCriticality
   * @param notificationsIcon
   * @returns {Number.maxCriticality | *}
   * @private
   */
  function _updateNotificationsIcon({criticality, criticalities, maxCriticality, notificationsIcon}) {
    // We are using three levels grey, yellow and red.
    let level = -1;

    if (criticality > 2) {
      criticalities[3] += 1;
      level = 3;
    } else if (criticality === 2) {
      criticalities[2] += 1;
      level = 2;
    } else if (criticality === 1) {
      criticalities[1] += 1;
      level = 1;
    }

    maxCriticality = Math.max(maxCriticality, level);
    const count = criticalities[maxCriticality];

    if (count > 0) {
      notificationsIcon.textContent = count;
      // It's ok to not remove any previous level classes since they are defined in ascending order
      notificationsIcon.classList.add(`level-${maxCriticality}`);
      notificationsIcon.classList.add('grow');
    }

    return maxCriticality;
  }

  function _toggleItem(item, clazz, nextItemIsExpandedClass = undefined) {
    if (item) {
      if (item.classList.contains(clazz)) {
        item.classList.remove(clazz);
        if (nextItemIsExpandedClass && item.previousElementSibling) {
          item.previousElementSibling.classList.remove('nextItemIsExpandedClass');
        }
      } else {
        item.classList.add(clazz);
        if (nextItemIsExpandedClass && item.previousElementSibling) {
          item.previousElementSibling.classList.add('nextItemIsExpandedClass');
        }
      }
    }
  }

  function _createElement(type, clazz) {
    const element = document.createElement(type);
    if (clazz) {
      element.className = clazz;
    }
    return element;
  }

  /**
   * Get the parent list from a list item, and sort that list by risk score and then by name,
   * found as a data attributes in each list item
   * @param li
   * @private
   */
  function _sortByRiskScore(li) {
    const list = li.parentElement;
    const listItems = list.children;
    const sortedListItems = [...listItems].sort((a, b) => {
      const aScore = a.getAttribute('data-riskScore') ? parseInt(a.getAttribute('data-riskScore'), 10) : -1;
      const bScore = b.getAttribute('data-riskScore') ? parseInt(b.getAttribute('data-riskScore'), 10) : -1;
      const aName = a.getAttribute('data-entity') || '';
      const bName = b.getAttribute('data-entity') || '';
      // Sort by risk score first, then by name if the risk scores are equal
      return bScore - aScore || aName.localeCompare(bName);
    });

    sortedListItems.forEach(listItem => list.appendChild(listItem));
  }

  /**
   * Add a section for expanding triggered risk rule data, but don't call the API until
   * he user clicks the expander!
   *
   * @param li
   * @param name
   * @param token
   * @param id
   */
  function addTriggeredRiskRulesSection({li, name, token, id}) {
    // We want a label row with an expander icon and a text label
    // after that we prepare an empty section that will hold the triggered risk rule data
    // once we have called the API

    const panelHeader = li.querySelector('.panel__header');
    // Create a flag to prevent multiple calls to the paying API
    let isLoading = false;

    // Create an initial hidden section to hold risk rule data
    const panelContent = _createElement('div', 'panel__content');

    if (!panelHeader.querySelector('.expander-wrapper')) {
      // Create the expander row
      const expanderWrapper = _createElement('div', 'expander-wrapper');
      const expanderIcon = _createElement('div', 'expander-icons');
      expanderIcon.innerHTML =
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18px" height="18px" class="arrow">
          <path xmlns="http://www.w3.org/2000/svg" d="M8.12 9.29L12 13.17l3.88-3.88c.39-.39 1.02-.39 1.41 0 .39.39.39 1.02 0 1.41l-4.59 4.59c-.39.39-1.02.39-1.41 0L6.7 10.7c-.39-.39-.39-1.02 0-1.41.39-.38 1.03-.39 1.42 0z"/>
        </svg>`;
      panelHeader.appendChild(expanderWrapper);
      li.appendChild(panelContent);

      // Handle clicks on the expander elements
      expanderIcon.addEventListener('click', function (event) {
        _toggleItem(li, 'panel--expanded', 'next-item-is-expanded');
        _toggleItem(expanderIcon, 'expanded');

        if (id === 'all') {
          id = li.getAttribute('ioc-type');
        }

        if (li.classList.contains('panel--expanded')) {
          _addRiskRules(id, panelHeader, panelContent);
          _trackAction({action: 'BrowserExtensionResultExpanded', type: id});
        } else {
          _trackAction({action: 'BrowserExtensionResultCollapsed', type: id});
        }
      });

      expanderWrapper.appendChild(expanderIcon);
    }

    function _addRiskRules(entityType, panelHeader, panelContent) {
      // Prevent multiple calls to the paying API
      if (isLoading) {
        return;
      }
      isLoading = true;
      let ruleDiv = _createElement('div', 'evidenceDetail');
      let cveId = null;
      const panelEntity = panelHeader.querySelector('.panel__entity');

      let notesLoading;
      if (!freemiumAccount && hasIntelligenceCard) {
        notesLoading = _createElement('div', 'notesLoading');
        notesLoading.innerHTML = '<img src="../images/loading.gif">';
        panelEntity.append(notesLoading);
      }

      let itemName = name;
      const redirectLink = panelHeader.querySelector('.redirectLink');
      if (redirectLink) {
        const redirectsTo = redirectLink.innerText;
        if (riskScoreCache[redirectsTo]) {
          itemName = redirectsTo
        }
      }

      _getTriggeredRiskRules({name: itemName, token})
        .then(riskData => {
          const getCriticality = criticality => {
            if (criticality > 3) return 3;
            if (criticality < 1) return 1;
            return criticality;
          };
          if (riskData.cveId) {
            cveId = riskData.cveId
          } else if (riskData.entity && riskData.entity.id) {
            cveId = riskData.entity.id;
          }
          if (freemiumAccount) {
            ruleDiv = _createElement('div', 'evidenceDetail');

            let mostCriticalRule;

            if (riskData.risk && riskData.risk.context && riskData.risk.context.public && riskData.risk.context.public.mostCriticalRule) {
              mostCriticalRule = riskData.risk.context.public.mostCriticalRule;
            } else if (riskData.riskRules && riskData.riskRules.mostCriticalRiskRule) {
              mostCriticalRule = riskData.riskRules.mostCriticalRiskRule;
            } else if (riskData.mostCriticalRule) {
              mostCriticalRule = riskData.mostCriticalRule;
            }

            if (mostCriticalRule) {
              const ruleParagraph = _createElement('p', 'evidenceDetail__rule');
              ruleParagraph.textContent = mostCriticalRule;
              ruleDiv.appendChild(ruleParagraph);
            }

            let summary;
            if (riskData.risk && riskData.risk.context && riskData.risk.context.public && riskData.risk.context.public.summary) {
              summary = riskData.risk.context.public.summary;
            } else if (riskData.riskRules && riskData.riskRules.summary) {
              summary = riskData.riskRules.summary;
            }
            const sortedSummary = summary ? summary.sort((a, b) => b.level - a.level) : null;

            if (sortedSummary && mostCriticalRule) {
              let levelOfMostCriticalRiskRule = sortedSummary[0].level;
              if (mostCriticalRule) {
                const item = sortedSummary.find(x => x.level === levelOfMostCriticalRiskRule);
                if (item) {
                  item.count--;
                }
              }
              levelOfMostCriticalRiskRule = getCriticality(levelOfMostCriticalRiskRule);

              const newSummary = [3, 2, 1].map(x => ({
                count: 0,
                level: x
              }));
              sortedSummary.forEach(x => {
                const level = getCriticality(x.level);
                newSummary.find(x => x.level === level).count += x.count;
              });

              ruleDiv.classList.add(`criticality-${levelOfMostCriticalRiskRule}`);
              panelContent.appendChild(ruleDiv);

              newSummary.map(item => {
                if (item.count >= 1) {
                  const ruleDiv = _createElement('div');
                  const ruleParagraph = _createElement('p', 'evidenceDetail__rule greyedOut');
                  ruleParagraph.textContent = `${item.count} More Risk Rule${ item.count > 1 ? 's' : '' }`;
                  ruleDiv.appendChild(ruleParagraph);
                  ruleDiv.classList.add('evidenceDetail');
                  ruleDiv.classList.add(`criticality-${getCriticality(item.level)}`);
                  panelContent.appendChild(ruleDiv);
                }
              });
            } else {
              const ruleDiv = _createElement('div');
              ruleDiv.classList.add('evidenceDetail');
              ruleDiv.textContent = 'No risk rule data available';
              panelContent.appendChild(ruleDiv);
            }
          } else {
            if ((riskData.riskRules && riskData.riskRules.evidence) || (riskData.risk && riskData.risk.rule && riskData.risk.rule.evidence)) {
              let evidence;
              if (riskData.riskRules && riskData.riskRules.evidence) {
                evidence = riskData.riskRules.evidence;
              } else {
                evidence = riskData.risk.rule.evidence;
              }

              const ruleKeys = Object.keys(evidence);
              const rules = [];
              ruleKeys.forEach(key => {
                rules.push(evidence[key]);
              });
              rules.sort((a, b) => b.level - a.level);
              rules.forEach(riskRule => {
                const ruleDiv = _createElement('div', 'evidenceDetail');
                const ruleParagraph = _createElement('p', 'evidenceDetail__rule');
                ruleParagraph.textContent = riskRule.rule;
                ruleDiv.appendChild(ruleParagraph);

                if (riskRule.description) {
                  const evidenceString = _prettifyText(riskRule.description);
                  const ruleString = _createElement('p', 'evidenceDetail__string');
                  ruleString.innerHTML = safeResponse.cleanDomString(evidenceString);
                  ruleDiv.appendChild(ruleString);
                }

                ruleDiv.classList.add(`criticality-${getCriticality(riskRule.level)}`);
                panelContent.appendChild(ruleDiv);
              });
            } else if ((riskData.risk && riskData.risk.context && riskData.risk.context.public && riskData.risk.context.public.summary) ||
              (riskData.riskRules && riskData.riskRules.summary)) {
              const ruleDiv = _createElement('div', 'evidenceDetail');
              let mostCriticalRiskRule;

              if (riskData.risk && riskData.risk.context && riskData.risk.context.public && riskData.risk.context.public.mostCriticalRule) {
                mostCriticalRiskRule = riskData.risk.context.public.mostCriticalRule;
              } else if (riskData.riskRules && riskData.riskRules.mostCritical) {
                mostCriticalRiskRule = riskData.riskRules.mostCritical;
              } else if (riskData.mostCriticalRule) {
                mostCriticalRiskRule = riskData.mostCriticalRule;
              }

              if (mostCriticalRiskRule) {
                const ruleParagraph = _createElement('p', 'evidenceDetail__rule');
                ruleParagraph.textContent = mostCriticalRiskRule;
                ruleDiv.appendChild(ruleParagraph);
              }

              let summary;
              if (riskData.risk && riskData.risk.context && riskData.risk.context.public && riskData.risk.context.public.summary) {
                summary = riskData.risk.context.public.summary;
              } else if (riskData.riskRules.summary) {
                summary = riskData.riskRules.summary;
              }

              const sortedSummary = summary.sort((a, b) => b.level - a.level);
              let levelOfMostCriticalRiskRule = sortedSummary[0].level;
              if (mostCriticalRiskRule) {
                const item = sortedSummary.find(x => x.level === levelOfMostCriticalRiskRule);
                if (item) {
                  item.count--;
                }
              }
              levelOfMostCriticalRiskRule = getCriticality(levelOfMostCriticalRiskRule);

              const newSummary = [3, 2, 1].map(x => ({
                count: 0,
                level: x
              }));
              sortedSummary.forEach(x => {
                const level = getCriticality(x.level);
                newSummary.find(x => x.level === level).count += x.count;
              });

              ruleDiv.classList.add(`criticality-${levelOfMostCriticalRiskRule}`);
              panelContent.appendChild(ruleDiv);

              newSummary.map(item => {
                if (item.count >= 1) {
                  const ruleDiv = _createElement('div');
                  const ruleParagraph = _createElement('p', 'evidenceDetail__rule greyedOut');
                  ruleParagraph.textContent = `${item.count} More Risk Rule${ item.count > 1 ? 's' : '' }`;
                  ruleDiv.appendChild(ruleParagraph);
                  ruleDiv.classList.add('evidenceDetail');
                  ruleDiv.classList.add(`criticality-${getCriticality(item.level)}`);
                  panelContent.appendChild(ruleDiv);
                }
              });
            } else {
              const ruleDiv = _createElement('div');
              ruleDiv.classList.add('evidenceDetail');
              ruleDiv.textContent = 'No risk rule data available';
              panelContent.appendChild(ruleDiv);
            }
          }
        })
        .then(() => _getNotes({name, token, entityType, cveId}))
        .then(noteData => {
          if (noteData && noteData.entity && noteData.entity.analystNotes && noteData.entity.analystNotes.documents && noteData.entity.analystNotes.documents.length > 0) {
            const noteContainer = _createElement('div', 'noteContainer');

            const insiktNotes = noteData.entity.analystNotes.documents.filter(note => note.source.id.includes('VKz42X'));
            const analystNotes = noteData.entity.analystNotes.documents.filter(note => note.source.id.includes('VWKdVr'));
            const insiktNoteExists = insiktNotes.length > 0;
            const analystNotesExists = analystNotes.length > 0;

            const createNoteContainer = (name, noteData, noteContainerTitle, hidden) => {
              const containerExists = noteContainer.querySelector(`.${name}`);
              let container;
              let noteTitle;

              if (!containerExists) {
                container = _createElement('div', name);
                noteTitle = _createElement('div', 'noteTitle');
                const noteIcon = _createElement('div', `noteIcon ${name === 'analystNoteContainer' ? 'analyst' : 'insikt'}`);
                if (name === 'analystNoteContainer') {
                  noteIcon.innerHTML = `
                <svg class="analystIcon" xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 14 14" fill="none">
                  <path d="M13.66 1.66671C13.66 0.933374 13.0667 0.333374 12.3333 0.333374H1.66667C0.933332 0.333374 0.333332 0.933374 0.333332 1.66671V9.66671C0.333332 10.4 0.933332 11 1.66667 11H11L13.6667 13.6667L13.66 1.66671ZM10.3333 8.33337H3.66667C3.3 8.33337 3 8.03337 3 7.66671C3 7.30004 3.3 7.00004 3.66667 7.00004H10.3333C10.7 7.00004 11 7.30004 11 7.66671C11 8.03337 10.7 8.33337 10.3333 8.33337ZM10.3333 6.33337H3.66667C3.3 6.33337 3 6.03337 3 5.66671C3 5.30004 3.3 5.00004 3.66667 5.00004H10.3333C10.7 5.00004 11 5.30004 11 5.66671C11 6.03337 10.7 6.33337 10.3333 6.33337ZM10.3333 4.33337H3.66667C3.3 4.33337 3 4.03337 3 3.66671C3 3.30004 3.3 3.00004 3.66667 3.00004H10.3333C10.7 3.00004 11 3.30004 11 3.66671C11 4.03337 10.7 4.33337 10.3333 4.33337Z" fill="#2673B3"/>
                </svg>
                `;
                } else {
                  noteIcon.innerHTML = `
                <svg width="18" height="18" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <rect width="100%" height="100%" fill="url(#pattern0)"/>
                  <defs>
                    <pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">
                      <use xlink:href="#image0" transform="translate(-0.212985 -0.153846) scale(0.0121942)"/>
                    </pattern>
                    <image id="image0" width="106" height="106" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGoAAABqCAYAAABUIcSXAAAAAXNSR0IArs4c6QAAAJZlWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAASShgAHAAAAEgAAAISgAQADAAAAAQABAACgAgAEAAAAAQAAAGqgAwAEAAAAAQAAAGoAAAAAQVNDSUkAAABTY3JlZW5zaG90h4/wyAAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+MTA2PC9leGlmOlBpeGVsWURpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6UGl4ZWxYRGltZW5zaW9uPjEwNjwvZXhpZjpQaXhlbFhEaW1lbnNpb24+CiAgICAgICAgIDxleGlmOlVzZXJDb21tZW50PlNjcmVlbnNob3Q8L2V4aWY6VXNlckNvbW1lbnQ+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpNgKfFAAAAHGlET1QAAAACAAAAAAAAADUAAAAoAAAANQAAADUAAAliiUj5SAAACS5JREFUeAHsW3lYVNcV/yEKyCbKyCogO6igqJGkCDGhnwrWuqX64RIxVGxd8hltXdKaIH4aTWu+uCTGYKOoGG2tkWqJ1NQYETVGE0UFgsDIvu/7Ium5pAy8eW+AQWaY5zfnn3n3vvveO/f87vI7557R+YkEWtF4C+hogdJ4jNoV1AIlDpygBUoLlEgsIBI1tTNKC5RILCASNbUzSguUSCwgEjW1M0oLlEgsIBI1tTNKC5RILCASNbUzSguUSCwgEjW1M0oLlEgsIBI1tTNKC5T6LcDOqqXFjbibVY+0ggb4uhjjFU9T6A7S4SjT+vQnXEmpxrcZtXCy0IeXrSHcbQygP3gQp50mFUQ9o9oIGGbsO5l1+C6rFolZdZDWt3Ls+/kiByzyNefUfXKlGKsv5nLqTHR14GtpCB97QwR5D0OAmwkGyQHMeUDNBVECVVzdir/fLkP0rVLcLW/q1mShY83wWZgTp03AnhRcL2rg1MkXxpgOweJJ5lj4wgi4WBnI31Z7WTRAsWXtWlo1Tt0oQ8yjStSz6dSD0CTBmZDRmD95BKflu+dyseN6Maeuu0KQvTHWvGKB4PFm3TVT6T1RAPXDkzps/EcOrhbU92gMBk6AtSH8nY2xYLI5vOyG8p5pI5DPf1+Bi/crcSunDqnVLbw2QhXznYwRMdcO40bx3ynUvj/rNBqomsan2HOxAHtuFoP2f4Uy1XIoAt1N8KKzCXzJmGZGugrbCt3Ir2xBUnY97mfXIS65CgmFipdFfRoIa1+QYHOwDSSmg4Vep5I6jQXqUlIV/nAuG8kKRrtkyCAs9R6OxX4STB5t1K/GuUes8QztgTE/lCOXBouQ2Ojr4sBr9pg3abjQ7X6v0zigGprbsD4mC1EPKgQ76ysxwMqpkvZ9x8xQtSOa6RJHy+Pu+AKFpGXHy5bYOttG5QxRo4CqImr9elQmLhDVlpdRBrp4Z7oNQv0lGMw2IjVKc0sbDhGl33mlEKV0LS+LXE1xaPloqHLgaAxQRVUtCPk0g0cY2J6wbspIbJplDYlx32YQY4xVDa0wpOVK7xlAzi1vRmRsHo4IzPYp5gaIfsMR7taqIRoaAdSTkib85nA6b3kZb6aHY6FOGE9OaG+knpaq62k1uJZag7zKZhTUtKCQ9jhpbQtq/s9GnGm5tCEfydp4CCzod6KDEQLHmMLOXK83n2hv88XdCoSdfoJKOYbjRu+Mf9MNDhL9Xr+rtw0HHKjU/AbM/yQdqWTMrhJMvsuxN5x6ZFYlNa34z8NKXH5Yjbj0asGlqet7FV1PI0ofNHYYpo8b1quBcVtah8WfZSCzjhsJYTPrAoE10qRvs1+RfgMKVEXdUwR+kIp7FdzowuoJI/BBiD30iNkpEkbdP/6qCHsTivsMjqJ3v+Zsim2/thX0wbo+k1XahKVHMpFYzKXzM2yNcHatC4xoqe0vGTCgmNO55HAGzjyu5vQlcpol/jTbFjoK+AILqJ5ILMPOy/m80cx50TMW2FYWTgNmC/lL3S2LjAAt+TQTcdlcAhTiYYroMOd+Iz4DBtSef+dj638LOeYMJ7/o0HJHhSA9ym3Ab49L8W1pI+c5VRbMCLEdM2yw5peWCj9TXtuK4H1puF3G1esdfwtEzBul8DllbgwIUPEPqhB0NIOj58xRRji3zhUGCpY75gCHnpKimAjDQAhbjv9Ky7Ei/TLpeGXG/jRkdIneM8Z6Y507fPrBIVc7UGz0+bz3CDkNnR4/Y3fx6z2IhQlvwAcuF2HDpbxuw0jqAG+6nVE7wbEaNkTwc7czazHz0GMOG/S3GorLGz2eyS1gH1M7UNv+mYOdiSWyjrK94CaNOqEwEPN/NnyejX13SmXtB/qCHX/E/t4VzpbCRx8s9BRyOouj5l5aOt+aYcWpU7agVqAyixrh/ZcUzhHFegpwMoYnJPviC/FWfL7QrQGtY2GsL9e7KYxELPwoHWczOkkS2+dubfSE2zOca6kVqBVEZaOTK2VGZmGhu1vHCvocl2gfm30sY8CXO5mychcsbHRylTPvmJ81Sy9sxKS9KTInm9UtdDPF6d+5sMs+idqAupFeg6kfP+YoGTXHDmEvj+TUsQJzggP3/4iCASIOPIUUVHTH6nZeyMO2r4s4T6ZuGtPnWaU2oEIp2Ho8pXM2vWRhgGubPHkjsqm1DdPeT1UrBedYU8lCXKgzZlKOhbzUNT2F3+4UJFU1y2792c8CkQv6RtfVAlQpMb3REQ84e9Nhmk0rBWbTkaslCP9Xjqxzmn7B9quEzZ6Cji2LuK/pkkRjR5GK5IhxfYpYqAWoo9dKEXY+W2ZzlvEjfdcLI+Si4czLn7grmZdJJHtQQy+O0wHi0l9IeNqxOKTjdu4APUFtlwi05T0sV6EWoIL2/oj4vDrZp1dSBOJwqKOs3HEhtK533NPkXw+i7HfeHgtDPX5sMvyolHMs8qqVIb7a5KF0d1QOFGNAbu8ncxS7Gu6CAIqFdZUCylvw2vUI5bRHiVEOzrLF6kB+mOlrSvQMjErndElKoCp7FKJyoKK+KcGq2M49hzmMSbTsyec2CiVFcnqn4QVGjhK3jOFpybLaJkQ+xMMupCJ2mSNm+yiXa6FyoN48mYWD35fJOrDGxxwHljnIyh0XcyioKXQE33FfDL9pRL+FkjXlbbCd8iy2zbFVqksqB8qfKGrX8xqhzZRlvtpuT9JY57a3Ft0fbIu1AlH26IQSrPiic1WZSylt59a69fa17e1UClQt+RLD377PAUBo1MXcKMWys52sUKkeaFBjdgIQt8GdpxHLGZzwYaqs3ppIR86u8UplLqkUKBZNfvFgmkxBllOQst2Ld960/EgGTlDi4/MghRHevFMAdthpQwO2awZT8h894aFEIoxKgYqltOF5J6Uy+6/0Ilq+gk/L/XYn4yad5zwPcotOAqY48hNC59OAPU8Dt0MSKALv52rSUezxV6VAMcptG/lApsQ3q1zhT6nH8uKw9T5yaJl8HuTC606YNYH/ZwKWubQg5udBy7J8s3Z4Y6iA36XIBioFin30O8rWOXWzDNM8TDBnIp+SshQv4y33FOknuvq/zbXHigB+lILR9C8p6/Ye/Slh2UsS2CuZUqZyoHqyNMvkcSRH93mR9161wuZf2fR7d/4HAAD//3aXplIAAAntSURBVO1beVhU1xX/qYBsQXaUTXRUFDeCGyQxi6KYVY3GxqgoLp/WBGNa45eYJlqtoTE1fhgTG624N0mNQj4NCSmNW6yiRRRRWRQimwjDviOS3kP73szjvRlgMvNmJt/cP+bu75xzf2/uPct9PX5mCUZMF/PqEfpxlhE50C/p18e6Y9sr/vp9KHtaD2MDdeVOA0JiM/UumLEe+GaoBz6Y46d38kYHqriyBb6bMvQumLEe+OHUfvj9tH4aybex/atnD43dGjsMClRzaxtijhfj+LUqzB3rhjXPiAVoefAzHNamgWW/inRwtj/mPeIukoXkjD74E77JqsGCEFdsnuWLnt1AzKBAncqswaRdt3im/7lUgclBffg6Vwh8Nx059a1c1azzpMWDMGWEk0iGw+eVWHAkn28/t3IIwgY58vXOCgYFat9ZJRbHq5hbM94DW14W79/hWzLxQ0lDZ7yaRX/a6qEY7W8v4jXqb7nYf6OKb9870w8LJ3rw9c4KBgUq5XYdwj7J5nl4ytse/1ozlK9zhTWf5+OjS0quara5u3VP5G0cCYfevUQyBL13DZl19/n2lOhAjBvgwNc7KxgUqNqmB+iz7irPgz3bk5Uxo2HLBFJPyderMXXPbfUmsywvGu6MuCUDRbwXVrTA/08qhak3UybKY4JhbyNcB9FEtQaDAkV0QjffwMXyJp5k6qpAPBwgfJOa7rdBwc6puy1t/DhzLHz5cgBeGu8qYv34lSpMP5DLt0/sa4fTa4fx9a4UDA7U8n152J1eyfMSN9MfiyaKtaKO4/gJZlKg3aLgj6Pg4iDe9jZ9XYT1p+/xkuhiFBscqB3J97AqsYhncs4QJ3yxYhBf5woJlyvx4qE8rmp2+WyFE/7xqlguspsmbL6O1IpmXqbuKhI00eBAZRQ0YtS2mzyTvdj+nPPWcAR49ObbqEA2V1jMTVypVAkkGGDile+XKBA+XGx6nGEmypNqJgqJkfu2WP7OxDM4UMTA1L9kIbm4nudl01NeeOd5H77OFeJTKzHrsPn9q14Y8BASogdzYgjyZXF52JOh2vo1/fMEkyQqsgB14JwSi46q7KnBDlZIXz8Cva2EWg+5hyO2CkGV4NnkmjSp2veq70PB3GMNtP/9P8XPH4DpIS5ctcu5LEDVNLZi0IYMKJl2xyVNDP+YXYvH/5rDDTP5fGGQM/YuFavkxHhsUgneSCrmZVDYW+E6e0FtOpgn/AAtBVmAIvqrD9/B9tRynpVQD1ucfHOo6F9FA1YwTXGXmqbITzKxgjczbM+sDsRAL1sRZ6U1rRgXcx0FzQ/4vvWPe2L9DF++3p2CbEBd/qkeY7dnCXiLfdoH0VO8BG1UqWfCTY/NMWm3EilFiVHSfj2SIfrgHXySpnoxycjNWBsEhQSoNL6zJBtQxMirzHu8M62C54lcLqmMeT83G76NK5A1P3lbpsk6a7c/44PXwsUvGfF//lYdHv1U5Tqjtnce9cCmWWI/J/V1JckKlNR2oMntQsxfYL7C8J05gsO4K0IZeszKYFfsiAyQJNPKwhmTt2bibEkj3z/E0Ropbw1DH3ZG6ZpkBYqYjDtTiqUJhQJ+j84bgJljpDWh79KrEclUdnVFRDBZ5sqykS6Ind9f5K/k2PjziWKs+6GEq7bnmlxLgkGdVGQHqo2pqlM+ysLJYlVYw5Wp6Ym/HYzxGrzJZDTPj7uN9OqWTsQxbDdFb38X0Q892Hkjlb68WI65X9wRdD3f3xEJq4ZonCMYrKUiO1DESxpTLCbuyBZsaQOZbZXMHLYdPRYc77RtRsXl4tv8Oq5JtpzO0r1zA/BssLNGmrRNRzCzolYtVE0v4JnXAxHkY6dxXlc7jAIUMXfo30pEfqUygqltgrstEplgUo5N6icv+4eJd7Htx1JUqS0I9Rkq0T8iZraf1sXOK2tGeGwW8hqEUWptW3p3+TUaUMToxoQibDij8ipT21Q/BxxgfjNPJ80Hb355C7Z8U4zPrlYY7K4F2XnvPeuDaaPE/jvik0tZdxsxl0VvO/oot4T3k7wjws3rbm5UoMizsmSPMERNAox2tsGhxQoM99W+ZVzNb0BMYjGO5tToDTCivXqSF+aFucOKjCUt6TRdVNmfh0IWIFVPy0e74lOmFWo6y9THdrVsVKCISTJuZ358S+C0pXZPFv3cx7TBaSO1v9E0VsnOr6TrVUjKqMaJ7Jpub4uPednhuRHOiGC0RvnZd2mBD7Ote/mxAsE5S7w87e+Ioyzc0TGKTX2/JBkdKGK+rLYVC3ffxneFKg87tdML/cEUb7zGvBc2nbzdNJ5SHXu7z+XUoYiFS0gBKWWO0bs199tpONr1gtdDVujrZA2vPtZse7VGCLuIIuUC+t/TxL/0YpEKvvlcmahzxkBHxEUp4CwRPBQN7maDSQBFPDeyMDz5A3dfU4UEOFnCPG3x/kxfPBEovobFjZEjT7pWjXXxBUirEpsJ0SFu7TesOkYE9MWXyQBFAlGYI4a9rX84KTQYOWHJ2Fw/wwfeLmKXEzfGEDm5s949Vii47qVOZ2uEN96I6KvepPeySQHFSff5hXKsYPErdZuE66Oza9k4t/bDfqi3dmWDm6NrfrOoCX+/UIbdl8pRKnHxhuyrz+b01+hV0ZWu1DyTBIoYzWRq79tfFeLrvFopvtvbnmMH97xH3PBCsAvsunH1SuMDWUcDA+REWiUOnC9HohbjOnKYMza+6At/CYeytufr2meyQJFAtBUeYW6ZdSeKkKvlyrOvbS9MYuHwMf0d2FU0e6a52cHJTrMdpr5YVcxITWdqfhr7quRyQT1OMQ+DegxJfSyVx7j2Rgw7L6XuR3Qcq8+6SQPFCVpV/wDvs48Ntl0q65K9RApimKcd5o13Q9Rj7qKIKmmGu06V4cjlCqQoVXcOOXpSOW1za5/watdA9a16S9Hr2GYWQHFM595jZ0ZKOQ79pwLZateDuX6pfAfzLqycLIwbbYgvxMazpVLDRW1P9rNHZKg7O4ecf1GYQvTgbjaYFVCcbPQJSzIzbg+nKHGMeQea2RapKZGXYOfCAEH3b1iM60iO5rOPFJYFLOb0Sqib6Fav4EEyVswSKPX1oQ/h6PPSq/n1uMLCIeeL6nkNzZntgd+uGIwJCuHnLd8zkF/an8trlXTujGU+xofZGRfsb4cRvvbduheuzo+hymYPVMeFoXhXdkkTiphROoF5ChyZoiGVyMNwo7gJCnYR1NWxa4qH1HPkavvVASXXwslNxwKU3CuuIz0LUDounNzTLEDJveI60rMApePCyT3NApTcK64jPQtQOi6c3NMsQMm94jrSswCl48LJPc0ClNwrriM9C1A6Lpzc0yxAyb3iOtKzAKXjwsk9zQKU3CuuIz0LUDounNzTLEDJveI60vsv4uTDLBzff/IAAAAASUVORK5CYII="/>
                  </defs>
                </svg>
                `;
                }

                const noteLabel = _createElement('div', 'noteLabel');
                noteLabel.innerText = noteContainerTitle;
                const noteInfo = _createElement('div', 'noteInfo');
                noteInfo.classList.add(name === 'analystNoteContainer' ? 'analyst' : 'insikt');
                noteInfo.innerHTML = `
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                <g clip-path="url(#clip0_2244_8000)">
                  <path d="M8 1.33334C4.32 1.33334 1.33333 4.32 1.33333 8C1.33333 11.68 4.32 14.6667 8 14.6667C11.68 14.6667 14.6667 11.68 14.6667 8C14.6667 4.32 11.68 1.33334 8 1.33334ZM8 11.3333C7.63333 11.3333 7.33333 11.0333 7.33333 10.6667V8C7.33333 7.63334 7.63333 7.33334 8 7.33334C8.36667 7.33334 8.66667 7.63334 8.66667 8V10.6667C8.66667 11.0333 8.36667 11.3333 8 11.3333ZM8.66667 6H7.33333V4.66667H8.66667V6Z" fill="#DDDDDD"/>
                </g>
                <defs>
                <clipPath id="clip0_2244_8000">
                  <rect width="16" height="16" fill="white"/>
                </clipPath>
                </defs>
              </svg>
              `;
                noteTitle.append(noteIcon);
                noteTitle.append(noteLabel);
                noteTitle.append(noteInfo);
              } else {
                container = noteContainer.querySelector(`.${name}`);
              }

              const noteBody = _createElement('div', 'noteBody');

              if (hidden) {
                noteBody.classList.add('hidden');
              }

              const note = _createElement('div', 'note');
              const title = _createElement('div', 'noteTitle');
              title.innerHTML = noteData.title;
              const body = _createElement('div', 'noteDescription');
              if (noteData.text.length <= 200) {
                body.innerHTML = noteData.text;
              } else {
                const textPreview = _createElement('div', 'preview');
                const textFull = _createElement('div', 'full hidden');
                textPreview.innerHTML = noteData.text.slice(0, 200) + '...';
                textFull.innerHTML = noteData.text;

                const readFullNote = _createElement('span', 'readFullNote');
                readFullNote.innerText = 'Full Note';
                readFullNote.addEventListener('click', () => {
                  textPreview.classList.add('hidden');
                  textFull.classList.remove('hidden');
                });
                textPreview.append(readFullNote);

                const collapseNote = _createElement('span', 'collapseNote');
                collapseNote.innerText = 'Collapse Note';
                collapseNote.addEventListener('click', () => {
                  textFull.classList.add('hidden');
                  textPreview.classList.remove('hidden');
                });
                textFull.append(collapseNote);

                body.append(textPreview);
                body.append(textFull);
              }
              note.append(title);
              note.append(body);
              noteBody.append(note);

              if (!containerExists) {
                container.append(noteTitle);
              }

              container.append(noteBody);

              if (!containerExists) {
                noteContainer.append(container);
              }
            };

            if (analystNotesExists) {
              createNoteContainer('analystNoteContainer', analystNotes.sort((a, b) => new Date(b.published).getTime() - new Date(a.published).getTime())[0], 'Analyst Note', false);
            }
            if (insiktNoteExists) {
              createNoteContainer('insiktNoteContainer', insiktNotes.sort((a, b) => new Date(b.published).getTime() - new Date(a.published).getTime())[0], 'Insikt Group Notes', false);
            }

            let link;
            if (hasIntelligenceCard && (analystNotesExists || insiktNoteExists)) {
              link = _createElement('a', 'showAllNotes');
              const url = getIntelCardUrl(name);

              if (url.includes('?')) {
                link.href = url + '&t_origin=BrowserExtensionDialog';
              } else {
                link.href = url + '?t_origin=BrowserExtensionDialog';
              }
              link.target = '_blank';
              link.rel = 'noopener noreferrer';
              link.title = name;
              link.innerText = 'Show All Notes';
              link.addEventListener('click', function () {
                setTimeout(function () {
                  window.close();
                }, 50);
              });
            }

            if (analystNotes.length > 0) {
              const numberOfAnalystNotes = _createElement('span', 'notesAmount');
              numberOfAnalystNotes.innerHTML = `
            <svg class="analystIcon" xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 14 14" fill="none">
              <path d="M13.66 1.66671C13.66 0.933374 13.0667 0.333374 12.3333 0.333374H1.66667C0.933332 0.333374 0.333332 0.933374 0.333332 1.66671V9.66671C0.333332 10.4 0.933332 11 1.66667 11H11L13.6667 13.6667L13.66 1.66671ZM10.3333 8.33337H3.66667C3.3 8.33337 3 8.03337 3 7.66671C3 7.30004 3.3 7.00004 3.66667 7.00004H10.3333C10.7 7.00004 11 7.30004 11 7.66671C11 8.03337 10.7 8.33337 10.3333 8.33337ZM10.3333 6.33337H3.66667C3.3 6.33337 3 6.03337 3 5.66671C3 5.30004 3.3 5.00004 3.66667 5.00004H10.3333C10.7 5.00004 11 5.30004 11 5.66671C11 6.03337 10.7 6.33337 10.3333 6.33337ZM10.3333 4.33337H3.66667C3.3 4.33337 3 4.03337 3 3.66671C3 3.30004 3.3 3.00004 3.66667 3.00004H10.3333C10.7 3.00004 11 3.30004 11 3.66671C11 4.03337 10.7 4.33337 10.3333 4.33337Z" fill="#2673B3"/>
            </svg>
            <span>${analystNotes.length}</span>
            `;
              panelEntity.append(numberOfAnalystNotes);
            }
            if (insiktNotes.length > 0) {
              const numberOfInsiktNotes = _createElement('span', 'notesAmount');
              numberOfInsiktNotes.innerHTML = `
            <svg class="insiktIcon" width="18" height="18" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
              <rect width="100%" height="100%" fill="url(#pattern0)"/>
              <defs>
                <pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">
                  <use xlink:href="#image0" transform="translate(-0.212985 -0.153846) scale(0.0121942)"/>
                </pattern>
                <image id="image0" width="106" height="106" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGoAAABqCAYAAABUIcSXAAAAAXNSR0IArs4c6QAAAJZlWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAASShgAHAAAAEgAAAISgAQADAAAAAQABAACgAgAEAAAAAQAAAGqgAwAEAAAAAQAAAGoAAAAAQVNDSUkAAABTY3JlZW5zaG90h4/wyAAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+MTA2PC9leGlmOlBpeGVsWURpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6UGl4ZWxYRGltZW5zaW9uPjEwNjwvZXhpZjpQaXhlbFhEaW1lbnNpb24+CiAgICAgICAgIDxleGlmOlVzZXJDb21tZW50PlNjcmVlbnNob3Q8L2V4aWY6VXNlckNvbW1lbnQ+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpNgKfFAAAAHGlET1QAAAACAAAAAAAAADUAAAAoAAAANQAAADUAAAliiUj5SAAACS5JREFUeAHsW3lYVNcV/yEKyCbKyCogO6igqJGkCDGhnwrWuqX64RIxVGxd8hltXdKaIH4aTWu+uCTGYKOoGG2tkWqJ1NQYETVGE0UFgsDIvu/7Ium5pAy8eW+AQWaY5zfnn3n3vvveO/f87vI7557R+YkEWtF4C+hogdJ4jNoV1AIlDpygBUoLlEgsIBI1tTNKC5RILCASNbUzSguUSCwgEjW1M0oLlEgsIBI1tTNKC5RILCASNbUzSguUSCwgEjW1M0oLlEgsIBI1tTNKC5T6LcDOqqXFjbibVY+0ggb4uhjjFU9T6A7S4SjT+vQnXEmpxrcZtXCy0IeXrSHcbQygP3gQp50mFUQ9o9oIGGbsO5l1+C6rFolZdZDWt3Ls+/kiByzyNefUfXKlGKsv5nLqTHR14GtpCB97QwR5D0OAmwkGyQHMeUDNBVECVVzdir/fLkP0rVLcLW/q1mShY83wWZgTp03AnhRcL2rg1MkXxpgOweJJ5lj4wgi4WBnI31Z7WTRAsWXtWlo1Tt0oQ8yjStSz6dSD0CTBmZDRmD95BKflu+dyseN6Maeuu0KQvTHWvGKB4PFm3TVT6T1RAPXDkzps/EcOrhbU92gMBk6AtSH8nY2xYLI5vOyG8p5pI5DPf1+Bi/crcSunDqnVLbw2QhXznYwRMdcO40bx3ynUvj/rNBqomsan2HOxAHtuFoP2f4Uy1XIoAt1N8KKzCXzJmGZGugrbCt3Ir2xBUnY97mfXIS65CgmFipdFfRoIa1+QYHOwDSSmg4Vep5I6jQXqUlIV/nAuG8kKRrtkyCAs9R6OxX4STB5t1K/GuUes8QztgTE/lCOXBouQ2Ojr4sBr9pg3abjQ7X6v0zigGprbsD4mC1EPKgQ76ysxwMqpkvZ9x8xQtSOa6RJHy+Pu+AKFpGXHy5bYOttG5QxRo4CqImr9elQmLhDVlpdRBrp4Z7oNQv0lGMw2IjVKc0sbDhGl33mlEKV0LS+LXE1xaPloqHLgaAxQRVUtCPk0g0cY2J6wbspIbJplDYlx32YQY4xVDa0wpOVK7xlAzi1vRmRsHo4IzPYp5gaIfsMR7taqIRoaAdSTkib85nA6b3kZb6aHY6FOGE9OaG+knpaq62k1uJZag7zKZhTUtKCQ9jhpbQtq/s9GnGm5tCEfydp4CCzod6KDEQLHmMLOXK83n2hv88XdCoSdfoJKOYbjRu+Mf9MNDhL9Xr+rtw0HHKjU/AbM/yQdqWTMrhJMvsuxN5x6ZFYlNa34z8NKXH5Yjbj0asGlqet7FV1PI0ofNHYYpo8b1quBcVtah8WfZSCzjhsJYTPrAoE10qRvs1+RfgMKVEXdUwR+kIp7FdzowuoJI/BBiD30iNkpEkbdP/6qCHsTivsMjqJ3v+Zsim2/thX0wbo+k1XahKVHMpFYzKXzM2yNcHatC4xoqe0vGTCgmNO55HAGzjyu5vQlcpol/jTbFjoK+AILqJ5ILMPOy/m80cx50TMW2FYWTgNmC/lL3S2LjAAt+TQTcdlcAhTiYYroMOd+Iz4DBtSef+dj638LOeYMJ7/o0HJHhSA9ym3Ab49L8W1pI+c5VRbMCLEdM2yw5peWCj9TXtuK4H1puF3G1esdfwtEzBul8DllbgwIUPEPqhB0NIOj58xRRji3zhUGCpY75gCHnpKimAjDQAhbjv9Ky7Ei/TLpeGXG/jRkdIneM8Z6Y507fPrBIVc7UGz0+bz3CDkNnR4/Y3fx6z2IhQlvwAcuF2HDpbxuw0jqAG+6nVE7wbEaNkTwc7czazHz0GMOG/S3GorLGz2eyS1gH1M7UNv+mYOdiSWyjrK94CaNOqEwEPN/NnyejX13SmXtB/qCHX/E/t4VzpbCRx8s9BRyOouj5l5aOt+aYcWpU7agVqAyixrh/ZcUzhHFegpwMoYnJPviC/FWfL7QrQGtY2GsL9e7KYxELPwoHWczOkkS2+dubfSE2zOca6kVqBVEZaOTK2VGZmGhu1vHCvocl2gfm30sY8CXO5mychcsbHRylTPvmJ81Sy9sxKS9KTInm9UtdDPF6d+5sMs+idqAupFeg6kfP+YoGTXHDmEvj+TUsQJzggP3/4iCASIOPIUUVHTH6nZeyMO2r4s4T6ZuGtPnWaU2oEIp2Ho8pXM2vWRhgGubPHkjsqm1DdPeT1UrBedYU8lCXKgzZlKOhbzUNT2F3+4UJFU1y2792c8CkQv6RtfVAlQpMb3REQ84e9Nhmk0rBWbTkaslCP9Xjqxzmn7B9quEzZ6Cji2LuK/pkkRjR5GK5IhxfYpYqAWoo9dKEXY+W2ZzlvEjfdcLI+Si4czLn7grmZdJJHtQQy+O0wHi0l9IeNqxOKTjdu4APUFtlwi05T0sV6EWoIL2/oj4vDrZp1dSBOJwqKOs3HEhtK533NPkXw+i7HfeHgtDPX5sMvyolHMs8qqVIb7a5KF0d1QOFGNAbu8ncxS7Gu6CAIqFdZUCylvw2vUI5bRHiVEOzrLF6kB+mOlrSvQMjErndElKoCp7FKJyoKK+KcGq2M49hzmMSbTsyec2CiVFcnqn4QVGjhK3jOFpybLaJkQ+xMMupCJ2mSNm+yiXa6FyoN48mYWD35fJOrDGxxwHljnIyh0XcyioKXQE33FfDL9pRL+FkjXlbbCd8iy2zbFVqksqB8qfKGrX8xqhzZRlvtpuT9JY57a3Ft0fbIu1AlH26IQSrPiic1WZSylt59a69fa17e1UClQt+RLD377PAUBo1MXcKMWys52sUKkeaFBjdgIQt8GdpxHLGZzwYaqs3ppIR86u8UplLqkUKBZNfvFgmkxBllOQst2Ld960/EgGTlDi4/MghRHevFMAdthpQwO2awZT8h894aFEIoxKgYqltOF5J6Uy+6/0Ilq+gk/L/XYn4yad5zwPcotOAqY48hNC59OAPU8Dt0MSKALv52rSUezxV6VAMcptG/lApsQ3q1zhT6nH8uKw9T5yaJl8HuTC606YNYH/ZwKWubQg5udBy7J8s3Z4Y6iA36XIBioFin30O8rWOXWzDNM8TDBnIp+SshQv4y33FOknuvq/zbXHigB+lILR9C8p6/Ye/Slh2UsS2CuZUqZyoHqyNMvkcSRH93mR9161wuZf2fR7d/4HAAD//3aXplIAAAntSURBVO1beVhU1xX/qYBsQXaUTXRUFDeCGyQxi6KYVY3GxqgoLp/WBGNa45eYJlqtoTE1fhgTG624N0mNQj4NCSmNW6yiRRRRWRQimwjDviOS3kP73szjvRlgMvNmJt/cP+bu75xzf2/uPct9PX5mCUZMF/PqEfpxlhE50C/p18e6Y9sr/vp9KHtaD2MDdeVOA0JiM/UumLEe+GaoBz6Y46d38kYHqriyBb6bMvQumLEe+OHUfvj9tH4aybex/atnD43dGjsMClRzaxtijhfj+LUqzB3rhjXPiAVoefAzHNamgWW/inRwtj/mPeIukoXkjD74E77JqsGCEFdsnuWLnt1AzKBAncqswaRdt3im/7lUgclBffg6Vwh8Nx059a1c1azzpMWDMGWEk0iGw+eVWHAkn28/t3IIwgY58vXOCgYFat9ZJRbHq5hbM94DW14W79/hWzLxQ0lDZ7yaRX/a6qEY7W8v4jXqb7nYf6OKb9870w8LJ3rw9c4KBgUq5XYdwj7J5nl4ytse/1ozlK9zhTWf5+OjS0quara5u3VP5G0cCYfevUQyBL13DZl19/n2lOhAjBvgwNc7KxgUqNqmB+iz7irPgz3bk5Uxo2HLBFJPyderMXXPbfUmsywvGu6MuCUDRbwXVrTA/08qhak3UybKY4JhbyNcB9FEtQaDAkV0QjffwMXyJp5k6qpAPBwgfJOa7rdBwc6puy1t/DhzLHz5cgBeGu8qYv34lSpMP5DLt0/sa4fTa4fx9a4UDA7U8n152J1eyfMSN9MfiyaKtaKO4/gJZlKg3aLgj6Pg4iDe9jZ9XYT1p+/xkuhiFBscqB3J97AqsYhncs4QJ3yxYhBf5woJlyvx4qE8rmp2+WyFE/7xqlguspsmbL6O1IpmXqbuKhI00eBAZRQ0YtS2mzyTvdj+nPPWcAR49ObbqEA2V1jMTVypVAkkGGDile+XKBA+XGx6nGEmypNqJgqJkfu2WP7OxDM4UMTA1L9kIbm4nudl01NeeOd5H77OFeJTKzHrsPn9q14Y8BASogdzYgjyZXF52JOh2vo1/fMEkyQqsgB14JwSi46q7KnBDlZIXz8Cva2EWg+5hyO2CkGV4NnkmjSp2veq70PB3GMNtP/9P8XPH4DpIS5ctcu5LEDVNLZi0IYMKJl2xyVNDP+YXYvH/5rDDTP5fGGQM/YuFavkxHhsUgneSCrmZVDYW+E6e0FtOpgn/AAtBVmAIvqrD9/B9tRynpVQD1ucfHOo6F9FA1YwTXGXmqbITzKxgjczbM+sDsRAL1sRZ6U1rRgXcx0FzQ/4vvWPe2L9DF++3p2CbEBd/qkeY7dnCXiLfdoH0VO8BG1UqWfCTY/NMWm3EilFiVHSfj2SIfrgHXySpnoxycjNWBsEhQSoNL6zJBtQxMirzHu8M62C54lcLqmMeT83G76NK5A1P3lbpsk6a7c/44PXwsUvGfF//lYdHv1U5Tqjtnce9cCmWWI/J/V1JckKlNR2oMntQsxfYL7C8J05gsO4K0IZeszKYFfsiAyQJNPKwhmTt2bibEkj3z/E0Ropbw1DH3ZG6ZpkBYqYjDtTiqUJhQJ+j84bgJljpDWh79KrEclUdnVFRDBZ5sqykS6Ind9f5K/k2PjziWKs+6GEq7bnmlxLgkGdVGQHqo2pqlM+ysLJYlVYw5Wp6Ym/HYzxGrzJZDTPj7uN9OqWTsQxbDdFb38X0Q892Hkjlb68WI65X9wRdD3f3xEJq4ZonCMYrKUiO1DESxpTLCbuyBZsaQOZbZXMHLYdPRYc77RtRsXl4tv8Oq5JtpzO0r1zA/BssLNGmrRNRzCzolYtVE0v4JnXAxHkY6dxXlc7jAIUMXfo30pEfqUygqltgrstEplgUo5N6icv+4eJd7Htx1JUqS0I9Rkq0T8iZraf1sXOK2tGeGwW8hqEUWptW3p3+TUaUMToxoQibDij8ipT21Q/BxxgfjNPJ80Hb355C7Z8U4zPrlYY7K4F2XnvPeuDaaPE/jvik0tZdxsxl0VvO/oot4T3k7wjws3rbm5UoMizsmSPMERNAox2tsGhxQoM99W+ZVzNb0BMYjGO5tToDTCivXqSF+aFucOKjCUt6TRdVNmfh0IWIFVPy0e74lOmFWo6y9THdrVsVKCISTJuZ358S+C0pXZPFv3cx7TBaSO1v9E0VsnOr6TrVUjKqMaJ7Jpub4uPednhuRHOiGC0RvnZd2mBD7Ote/mxAsE5S7w87e+Ioyzc0TGKTX2/JBkdKGK+rLYVC3ffxneFKg87tdML/cEUb7zGvBc2nbzdNJ5SHXu7z+XUoYiFS0gBKWWO0bs199tpONr1gtdDVujrZA2vPtZse7VGCLuIIuUC+t/TxL/0YpEKvvlcmahzxkBHxEUp4CwRPBQN7maDSQBFPDeyMDz5A3dfU4UEOFnCPG3x/kxfPBEovobFjZEjT7pWjXXxBUirEpsJ0SFu7TesOkYE9MWXyQBFAlGYI4a9rX84KTQYOWHJ2Fw/wwfeLmKXEzfGEDm5s949Vii47qVOZ2uEN96I6KvepPeySQHFSff5hXKsYPErdZuE66Oza9k4t/bDfqi3dmWDm6NrfrOoCX+/UIbdl8pRKnHxhuyrz+b01+hV0ZWu1DyTBIoYzWRq79tfFeLrvFopvtvbnmMH97xH3PBCsAvsunH1SuMDWUcDA+REWiUOnC9HohbjOnKYMza+6At/CYeytufr2meyQJFAtBUeYW6ZdSeKkKvlyrOvbS9MYuHwMf0d2FU0e6a52cHJTrMdpr5YVcxITWdqfhr7quRyQT1OMQ+DegxJfSyVx7j2Rgw7L6XuR3Qcq8+6SQPFCVpV/wDvs48Ntl0q65K9RApimKcd5o13Q9Rj7qKIKmmGu06V4cjlCqQoVXcOOXpSOW1za5/watdA9a16S9Hr2GYWQHFM595jZ0ZKOQ79pwLZateDuX6pfAfzLqycLIwbbYgvxMazpVLDRW1P9rNHZKg7O4ecf1GYQvTgbjaYFVCcbPQJSzIzbg+nKHGMeQea2RapKZGXYOfCAEH3b1iM60iO5rOPFJYFLOb0Sqib6Fav4EEyVswSKPX1oQ/h6PPSq/n1uMLCIeeL6nkNzZntgd+uGIwJCuHnLd8zkF/an8trlXTujGU+xofZGRfsb4cRvvbduheuzo+hymYPVMeFoXhXdkkTiphROoF5ChyZoiGVyMNwo7gJCnYR1NWxa4qH1HPkavvVASXXwslNxwKU3CuuIz0LUDounNzTLEDJveI60rMApePCyT3NApTcK64jPQtQOi6c3NMsQMm94jrSswCl48LJPc0ClNwrriM9C1A6Lpzc0yxAyb3iOtKzAKXjwsk9zQKU3CuuIz0LUDounNzTLEDJveI60vsv4uTDLBzff/IAAAAASUVORK5CYII="/>
              </defs>
            </svg>
            <span>${insiktNotes.length}</span>
            `;
              panelEntity.append(numberOfInsiktNotes);
            }

            panelContent.appendChild(noteContainer);
            if (link) {
              panelContent.appendChild(link);
            }
          }
        })
        .then(() => {
          if (!freemiumAccount && hasIntelligenceCard) {
            notesLoading.style.display = 'none';
          }
        })
        .then(() => {
          // Add listeners to noteInfo elements
          document.querySelectorAll('.noteInfo').forEach(x => {
            x.addEventListener('mouseover', ev => {
              userHoveringTooltip = true;

              let el = ev.srcElement;
              let tries = 0;
              while (!el.classList.contains('noteInfo') && tries < 8) { // Loop up in the DOM tree to find the .noteInfo parent
                el = el.parentElement;
                tries++;
              }
              if (tries < 8) {
                const bboxForIcon = el.getBoundingClientRect();

                let tooltipToShow = el.classList.contains('analyst') ? document.getElementById('analystNoteInfoTooltip') : document.getElementById('insiktNoteInfoTooltip');
                const bboxForTooltip = tooltipToShow.getBoundingClientRect();

                const displayTooltipAbove = bboxForIcon.top >= 250;

                tooltipToShow.style.left = ((bboxForIcon.left + (bboxForIcon.width / 2)) - (bboxForTooltip.width / 2)) - 8 + 'px';
                if (displayTooltipAbove) {
                  tooltipToShow.querySelector('.arrow.top').style.display = 'none';
                  tooltipToShow.querySelector('.arrow.bottom').style.display = 'block';
                  tooltipToShow.style.top = (bboxForIcon.top - bboxForTooltip.height) + 10 + 'px';
                } else {
                  tooltipToShow.querySelector('.arrow.top').style.display = 'block';
                  tooltipToShow.querySelector('.arrow.bottom').style.display = 'none';
                  tooltipToShow.style.top = (bboxForIcon.top + bboxForIcon.height) - 10 + 'px';
                }
                setTimeout(() => {
                  tooltipToShow.style.visibility = 'visible';
                }, 10);
              }
            });
            x.addEventListener('mouseout', ev => {
              userHoveringTooltip = false;
              setTimeout(() => {
                if (!userHoveringTooltip) {
                  document.querySelectorAll('.noteInfoTooltip').forEach(x => {
                    x.style.visibility = 'hidden';
                  });
                }
              }, 10);
            });
          });
        })
        .catch(err => {
          console.warn(err);
          const errorSpan = _createElement('span', 'error');
          errorSpan.textContent = 'Sorry, there was a problem getting the triggered risk rules data.';
          if (err === 401) {
            // Unauthenticated, possible reason is that the user ran out of credits
            errorSpan.textContent += ' Do you have API credits left?';
          } else if (err == 'TypeError: Failed to fetch') {
            // Not sure why, but must us '==' here, '===' will not match!
            // fetch() failed, could be a network issue maybe?
            errorSpan.textContent += ' Are you offline?';
          }
          panelContent.appendChild(errorSpan);
        });
    }
  }

  /**
   * Do some formatting of the text. Create actual links and add some line breaks
   * @param text
   * @returns {*}
   * @private
   */
  function _prettifyText(text) {
    // Prettify the text by adding line breaks before any "X related malware(s)." section
    text = text.replace(/(\d+ related malwares?:?(?:including?)? .*[\.])/g, '<br>$1');

    // Prettify the text by adding line breaks before any "Most recent..." section
    text = text.replace(/Most recent/g, '<br>Most recent');

    // Add a line break between Insikt Group and the number of notes found
    const [, , insiktNotes] = text.match(/(Insikt Group. (\d+ notes? (((?!\. ).)*)))/) || [];
    if (insiktNotes) {
      text = text.replace(insiktNotes, `<br>${insiktNotes}`);
    }

    // Prettify the text by identifying malware and creating Intel Card links for them
    const [, malwares] = text.match(/\d+ related malwares?(?: including)?:? (((?!\. ).)*)/) || [];
    if (malwares && malwares.length) {
      const baseUrl = 'https://app.recordedfuture.com/live/sc/entity/?name=';
      const newMalwares = malwares
        .split(', ')
        .map(malware => `
          <a class="entity__malware"
             id="entity-link"
             href="${baseUrl}${malware.trim().toLowerCase()}" >
             ${malware.trim()}</a>`)
        .join(', ');

      text = text.replace(malwares, newMalwares);
    }

    // Prettify the text by creating actual links to the "Most recent link"
    const [, link] = text.match(/Most recent link .*: (https?:\/\/.*)/) || [];
    if (link) {
      text = text.replace(link,
        `<a href="${link}" rel="noopener noreferrer" target="_blank" id="entity-link">${link}</a>`);
    }
    return text;
  }

  /**
   * Create the necessary elements to show the criticality level,
   * the risk score and any triggered risk rules
   *
   * @param li
   * @param riskScore
   * @param criticality
   * @param name
   * @param token
   * @param id
   * @private
   */
  function _showRiskScore({li, riskScore, criticality, name, token, id, triggeredRiskRuleSummaryExists}) {
    // Get the indicator element that we created earlier
    const indicator = li.querySelector('.criticalityIndicator');
    // Remove the loading spinner
    indicator.classList.remove('criticalityIndicator--loading');
    // Get the elments for the criticality level and risk score
    const criticalitySpan = li.querySelector('.criticality__plupp');
    const scoreSpan = li.querySelector('.riskscore');

    // Add the risk score as an attribute to the list element, so that we can sort the list!
    li.setAttribute('data-riskScore', riskScore);

    // Add the criticality as a class so we can style the plupp with the correct color
    criticalitySpan.classList.add(`level-${criticality}`);
    scoreSpan.textContent = riskScore;

    if (riskScore > 0 || triggeredRiskRuleSummaryExists) {
      // If there are matching risk rules we need to add an expand item with the content
      addTriggeredRiskRulesSection({li, name, token, id});
    }
  }

  /**
   * Helper to remove all child elements from a DOM element
   * @param node
   */
  function removeOldList(node) {
    var firstChild = node.firstChild;

    while (firstChild) {
      node.removeChild(firstChild);
      firstChild = node.firstChild;
    }
  }

  /*
      Possible error codes:
      401 - Unauthenticated, perform a retry with a refreshed token
      404 - No data available for that entity
      429 - Throttled, show throttled message
   */
  async function fetchRetry(url, requestOptions, refreshAttempted = false, source = '', logoutIfFailed = true) {
    await eventLog.log(`Request to ${url} source: ${source}`)
    let request = new Request(url, requestOptions);
    const response = await fetch(request);

    let oldToken, newToken;
    if ((response.status === 401 && refreshAttempted !== true)) {
      try {
        await eventLog.error(`401 error on fetchRetry when calling ${url}. ${response.statusText ? ', Message: ' + response.statusText : ''}`);
        oldToken = await browserModule.getToken();
        await eventLog.log(`oldToken is ${oldToken.slice(0,5)}...`)
        eventLog.log('Refresh auth tokens');
        await browserModule.refreshAuthTokens();
        await eventLog.log('Auth tokens refreshed, get token');
        await helpers.delay(1000);
        newToken = browserModule.getToken();
        await eventLog.log(
          oldToken === newToken ?
            'New token is the same as the old token' :
            'New token difffers from the old one'
        );
        let refreshedHeaders = new Headers({
          'Authorization': 'Bearer ' + newToken,
          'x-rf-user-agent': 'RFChromeExtension/6.1.4'    // Updated by gulp task "version"!
        });
        if (requestOptions.headers.get('Content-Type') !== null) {
          refreshedHeaders.set('Content-Type', requestOptions.headers.get('Content-Type'));
        }
        let refreshedOptions = { method: requestOptions.method, headers: refreshedHeaders };
        if (requestOptions.body !== undefined) { refreshedOptions.body = requestOptions.body; }
        await eventLog.log(
          `Fetchretry, url: ${url}, refreshedOptions: ${JSON.stringify(refreshedOptions)}`
        );
        return fetchRetry(url, refreshedOptions, true, '003', logoutIfFailed);
      } catch (err) {
        await eventLog.error(
          `Error on fetchretry ${JSON.stringify(request)} err: ${JSON.stringify(err, null, 4)}`
        );
      }
    } else if (response.status === 401 && refreshAttempted) {
      // User is unathorized also on second refresh call
      // no regular tracking since we have no valid token
      await eventLog.error(
        `401 error on fetchRetry also on refresh call when calling ${url}
        ${response.statusText ? ', Message: ' + response.statusText : ''}`
      );
      if (logoutIfFailed) {
        await eventLog.error('Will now sign out user');
        browserModule.signOut(false);
        showSignIn();
        clearIocList();
        hideHighlightToggle();
        return;
      } else {
        await eventLog.error('Will not sign out user');
        return;
      }
    } else if (response.status === 429) {
      await eventLog.error(
        `429 error on fetchRetry when calling ${url} 
            ${response.statusText ? ', Message: ' + response.statusText : ''}`
      );
      showThrottledMessage();
      throw(response.status);
    } else if (response.status === 404) {
      await eventLog.error(
        `Response status 404 when calling ${url} 
            ${response.statusText ? ', Message: ' + response.statusText : ''}`
      );
      throw(404);
    } else if (response.status !== 200) {
      const t = await response.text();
      await eventLog.error(
        `Unknown error with status code ${response.status} when calling ${url} 
            ${response.statusText ? ', Message: ' + t : ''}`
      );
      throw(response.status);
    } else {
      return response;
    }
  }

  popupCodeJustForSafariToWork.createPopupHTML = createPopupHTML;
})();
