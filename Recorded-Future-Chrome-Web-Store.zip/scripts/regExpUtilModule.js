import tlds from './tldsModule.js';
import saferesp from './saferespose2.js';

const patterns = {
  verisonNumber: /(((\d{1,5}\.\d{1,5}))(r|R)((\d{1,5}(\.\d{1,5})?)))|((r|R)((\d{1,5}(\.\d{1,5})?) ((\d{1,5}\.\d{1,5}))))|(((\d{1,5}\.\d{1,5})) (r|R)((\d{1,5}(\.\d{1,5})?)))|((r|R)((\d{1,5}(\.\d{1,5})?)))|(((\d{1,5}\.\d{1,5})) Patch [0-9]{0,2})|((\d{1,5}\.\d{1,5}(\.\d{1,5})?(\.\d{1,5})?(\.\d{1,5})?(\.\d{1,5})?))/g,
  cve: /(cve-\d{4}-\d{4,})/ig,
  hash: /(([0-9a-f]{128})|([0-9a-f]{64})|([0-9a-f]{40})|([0-9a-f]{32}))(?!([0-9a-f]*\u2026))/ig,
  idn: /(([a-z])([0-9]{1,2})-{0,3})?((?=[a-z0-9-]{1,63}\.)(xn--)?[a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,63}/ig,
  emailAdress: /(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})/ig,
  privateIp: /(^127\.)|(^10\.)|(^172\.1[6-9]\.)|(^172\.2[0-9]\.)|(^172\.3[0-1]\.)|(^192\.168\.)/ig,
  inlineIp: /(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/ig,
  ipv4: /((?<!([A-Z0-9]|([0-9]\.)))(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?![A-Z0-9]))(?!(\.[0-9]))/ig,
  ipv6: /((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?/ig,
  url: /((http(s)?:\/\/.):?[-a-zA-Z0-9@:.%_\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*))|(https:\/\/[-a-zA-Z0-9@:.%_\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*))|(http:\/\/[-a-zA-Z0-9@:.%_\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*))/ig
};

const _getAllRegExpMatches = (pattern, text) => {
  let m;
  const matches = [];
  pattern.lastIndex = 0;
  while ((m = pattern.exec(text)) !== null) {
    matches.push(m[0].toLowerCase());
  }
  return matches;
};

const onlyUnique = (value, index, self) => self.indexOf(value) === index;

const upperCase = value => value.toUpperCase();

const getAllCves = text => _getAllRegExpMatches(patterns.cve, text).filter(onlyUnique).map(upperCase);

const isIdn = text => {
  text = text.toLowerCase();
  if (!text.includes('.')) {
    return false;
  }
  const parts = text.split('.');
  if (!tlds.includes(parts[parts.length - 1])) {
    return false;
  }
  if (parts.some(p => !/^[a-z0-9\-]+$/.test(p))) {
    return false;
  }
  return true;
};

const getAllIdnMatches = text => {
  const textWithoutEmailAdresses = text.replace(patterns.emailAdress, '');
  const idns = _getAllRegExpMatches(patterns.idn, textWithoutEmailAdresses)
                .filter(el => isIdn(el))
                .filter(onlyUnique)
                .filter(idn => !idn.match(new RegExp('recordedfuture.com', 'g')));

  const newIdnsList = [];
  idns.forEach(idn => {
    if (idn.toLowerCase().startsWith('mentioned')) {
      const idnWithoutMentioned = idn.replace('mentioned', '');
      if (!idns.includes(idnWithoutMentioned)) {
        newIdnsList.push(idn);
      }
    } else {
      newIdnsList.push(idn);
    }
  });
  return newIdnsList;
};

const getAllIp6Matches = text => {
  var ip6Matches = _getAllRegExpMatches(patterns.ipv6, text).filter(onlyUnique);
  // "::" is caught as a valid IP6, good luck debugging the regexp...
  // Just remove it instead
  ip6Matches = ip6Matches.filter(x => !x.startsWith('::'));
  const filtered = ip6Matches.filter(ip => !ip.match(patterns.privateIp));
  return filtered;
};

const normalizeIPv4 = ip => ip.split('.').map(val => parseInt(val)).join('.');

const getInlineIps = text => {
  const ips = _getAllRegExpMatches(patterns.inlineIp, text).map(ip => normalizeIPv4(ip));
  const filtered = ips.filter(ip => !ip.match(patterns.privateIp)).filter(onlyUnique);
  return filtered;
};

const getAllIp4Matches = text => {
  const ips = _getAllRegExpMatches(patterns.ipv4, text).map(ip => normalizeIPv4(ip));
  const filtered = ips.filter(ip => !ip.match(patterns.privateIp)).filter(onlyUnique);
  return filtered;
};

const textContainsIp = text => {
  const ips = getInlineIps(text);
  const ipv4 = getAllIp4Matches(text);
  const ipv6 = getAllIp6Matches(text);
  const all = [...ips, ...ipv4, ...ipv6];
  const filtered = all.filter(ip => !ip.match(patterns.privateIp));
  return filtered;
};

const getAllIps = text => {
  const ipv4 = getAllIp4Matches(text);
  const ipv6 = getAllIp6Matches(text);
  const all = ipv4.concat(ipv6);
  const filtered = all.filter(ip => !ip.match(patterns.privateIp));
  return filtered;
};

const getAllPlainTextUrls = text => _getAllRegExpMatches(patterns.url, text).filter(onlyUnique).filter(idn => !idn.match(new RegExp('recordedfuture.com', 'g')));

const stripHtml = html => {
  let tmp = document.createElement('div');
  tmp.innerHTML = saferesp.cleanDomString(html);
  return tmp.textContent || tmp.innerText || '';
}

const getAllLinkUrls = body => {
  const links = [...body.querySelectorAll('a:not(.tooltipNavigateLink__link)')]
                .map(x => x.getAttribute('ref-backup') ? x.getAttribute('ref-backup') : x.getAttribute('href'))
                .map(x => stripHtml(x))
                .filter(x => !!x)
                .filter(x => x.startsWith('http'))
                //.map(x => x.split('?')[0]) // If we want to ignore query parameters
                .filter(onlyUnique);
  return links;
};

const getAllHashes = text => {
  // The following replace is to fix a bug where a filename ending with .exe followed
  // by a hash, the has would start with an e
  text = text.replace(/exe/g, 'x');
  return _getAllRegExpMatches(patterns.hash, text).filter(onlyUnique);
};

const getAllVersionNumbers = text => {
  return _getAllRegExpMatches(patterns.verisonNumber, text).filter(onlyUnique);
}

const isPrivateNetwork = text => {
  return !!patterns.privateIp.test(text);
};

const isIp4 = text => {
  return !!(text && patterns.ipv4.test(text) && !isPrivateNetwork(text));
};

const isIp6 = text => {
  return !!(text && patterns.ipv4.test(text) && !isPrivateNetwork(text));
};

const isHash = text => text && text.match(patterns.hash) !== null;

const isIPAddress = text => {
  return !!(text && (text.match(patterns.ipv4) !== null || text.match(patterns.ipv6) !== null) && !isPrivateNetwork(text));
};

const isCve = text => text && text.match(patterns.cve) !== null;

const isUrl = text => text && text.match(patterns.url) !== null;

const isEmail = text => text && text.match(patterns.emailAdress) !== null;

const getEndpoint = text => {
  if (isCve(text)) {
    return 'vulnerability';
  } else if (isIPAddress(text)) {
    return 'ip';
  } else if (isHash(text)) {
    return 'hash';
  } else if (isIdn(text)) {
    return 'domain';
  }
};

export default {
  textContainsIp,
  getAllVersionNumbers,
  getAllHashes,
  getAllCves,
  getAllIps,
  getAllIdnMatches,
  getAllIp4Matches,
  getAllIp6Matches,
  getAllPlainTextUrls,
  getAllLinkUrls,
  isCve,
  isUrl,
  isEmail,
  isIPAddress,
  isHash,
  isIdn,
  isIp4,
  isIp6,
  getEndpoint
};