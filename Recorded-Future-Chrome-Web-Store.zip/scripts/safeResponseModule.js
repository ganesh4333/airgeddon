const validAttrs = ['class', 'id', 'href', 'style'];

const removeInvalidAttributes = (target) => {
  var attrs = target.attributes, currentAttr;

  for (var i = attrs.length - 1; i >= 0; i--) {
    currentAttr = attrs[i].name;

    if (attrs[i].specified && validAttrs.indexOf(currentAttr) === -1) {
      target.removeAttribute(currentAttr);
    }

    if (
      currentAttr === 'href' &&
      /javascript[:]/gi.test(target.getAttribute('href'))
    ) {
      target.parentNode.removeChild(target);
    }
  }
};

const cleanDomString = (data) => {
  var parser = new DOMParser();
  var tmpDom = parser.parseFromString(data, 'text/html').body;

  var list, current;

  list = tmpDom.querySelectorAll('script,img');

  for (var i = list.length - 1; i >= 0; i--) {
    current = list[i];
    current.parentNode.removeChild(current);
  }

  list = tmpDom.getElementsByTagName('*');

  for (i = list.length - 1; i >= 0; i--) {
    // Remove links
    if (list[i].tagName === 'A') {
      list[i].outerHTML = `<b>${list[i].innerHTML}</b>`;
    } else {
      removeInvalidAttributes(list[i]);
    }
  }
  return tmpDom.innerHTML;
};

export default {
  cleanDomString
};