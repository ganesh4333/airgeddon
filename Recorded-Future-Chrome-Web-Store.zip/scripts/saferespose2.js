var validAttrs = ["class", "id", "href", "style"];

const removeInvalidAttributes = function (target) {
    var attrs = target.attributes, currentAttr;

    for (var i = attrs.length - 1; i >= 0; i--) {
        currentAttr = attrs[i].name;

        if (attrs[i].specified && validAttrs.indexOf(currentAttr) === -1) {
            target.removeAttribute(currentAttr);
        }

        if (
            currentAttr === "href" &&
            /^(#|\s*javascript[:])/i.test(target.getAttribute("href"))
        ) {
            target.parentNode.removeChild(target);
        }
    }
}

const cleanDomString = function (data) {
    var parser = new DOMParser;
    var tmpDom = parser.parseFromString(data, "text/html").body;

    var list, current, currentHref;

    list = tmpDom.querySelectorAll("script,img");

    for (var i = list.length - 1; i >= 0; i--) {
        current = list[i];
        current.parentNode.removeChild(current);
    }

    list = tmpDom.getElementsByTagName("*");

    for (i = list.length - 1; i >= 0; i--) {
        removeInvalidAttributes(list[i]);
    }

    return tmpDom.innerHTML;
}

export default {
    cleanDomString
}