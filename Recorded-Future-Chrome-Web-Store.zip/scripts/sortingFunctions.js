// SORTING FUNCTIONS FOR VERSIONS

// Sort func for format
// 5.2 R4.2
// or
// 5.4R4.5
function sortFunc1(a, b) {
    a = a.replace('R', ' R').replace('r', ' r');
    b = b.replace('R', ' R').replace('r', ' r');
    a = a.replace('  ', ' ');
    b = b.replace('  ', ' ');
    const aVersion = a.split(' ')[0];
    const bVersion = b.split(' ')[0];
    const aMajor = Number(aVersion.split('.')[0]);
    const aMinor = Number(aVersion.split('.')[1]);
    const bMajor = Number(bVersion.split('.')[0]);
    const bMinor = Number(bVersion.split('.')[1]);
    if (aMajor > bMajor) return 1;
    if (bMajor > aMajor) return -1;
    if (aMajor === bMajor && aMinor > bMinor) return 1;
    if (aMajor === bMajor && bMinor > aMinor) return -1;
    if (aMajor === bMajor && bMinor === aMinor) {
      const aRevision = a.split(' ')[1].replace('R', '').replace('r', '');
      const bRevision = b.split(' ')[1].replace('R', '').replace('r', '');
      const aRevMajor = Number(aRevision.split('.')[0]);
      const aRevMinor = Number(aRevision.split('.')[1]);
      const bRevMajor = Number(bRevision.split('.')[0]);
      const bRevMinor = Number(bRevision.split('.')[1]);
      if (aRevMajor > bRevMajor) return 1;
      if (bRevMajor > aRevMajor) return -1;
      if (aRevMajor === bRevMajor && aRevMinor > bRevMinor) return 1;
      if (aRevMajor === bRevMajor && bRevMinor > aRevMinor) return -1;
    }
    return 0;
  };
  // 4.5   5.6   55.33
  function sortFunc2(a, b) {
    if (Number(a.split('.')[0]) > b.split('.')[0]) return 1;
    if (Number(b.split('.')[0]) > a.split('.')[0]) return -1;
    if (Number(a.split('.')[1]) > b.split('.')[1]) return 1;
    if (Number(b.split('.')[1]) > a.split('.')[1]) return -1;
  }
  // 4.3.4    5.3.11
  function sortFunc3(a, b) {
    if (Number(a.split('.')[0]) > b.split('.')[0]) return 1;
    if (Number(b.split('.')[0]) > a.split('.')[0]) return -1;
    if (Number(a.split('.')[1]) > b.split('.')[1]) return 1;
    if (Number(b.split('.')[1]) > a.split('.')[1]) return -1;
    if (Number(a.split('.')[2]) > b.split('.')[2]) return 1;
    if (Number(b.split('.')[2]) > a.split('.')[2]) return -1;
  }
  // 4.3.4.2    5.3.11.4
  function sortFunc4(a, b) {
    if (Number(a.split('.')[0]) > b.split('.')[0]) return 1;
    if (Number(b.split('.')[0]) > a.split('.')[0]) return -1;
    if (Number(a.split('.')[1]) > b.split('.')[1]) return 1;
    if (Number(b.split('.')[1]) > a.split('.')[1]) return -1;
    if (Number(a.split('.')[2]) > b.split('.')[2]) return 1;
    if (Number(b.split('.')[2]) > a.split('.')[2]) return -1;
    if (Number(a.split('.')[3]) > b.split('.')[3]) return 1;
    if (Number(b.split('.')[3]) > a.split('.')[3]) return -1;
  }
  // 4.3.4.2.2    5.3.11.4.4
  function sortFunc5(a, b) {
    if (Number(a.split('.')[0]) > b.split('.')[0]) return 1;
    if (Number(b.split('.')[0]) > a.split('.')[0]) return -1;
    if (Number(a.split('.')[1]) > b.split('.')[1]) return 1;
    if (Number(b.split('.')[1]) > a.split('.')[1]) return -1;
    if (Number(a.split('.')[2]) > b.split('.')[2]) return 1;
    if (Number(b.split('.')[2]) > a.split('.')[2]) return -1;
    if (Number(a.split('.')[3]) > b.split('.')[3]) return 1;
    if (Number(b.split('.')[3]) > a.split('.')[3]) return -1;
    if (Number(a.split('.')[4]) > b.split('.')[4]) return 1;
    if (Number(b.split('.')[4]) > a.split('.')[4]) return -1;
  }
  // 4.3 Patch 7
  function sortFunc6(a, b) {
    a = a.toLowerCase();
    b = b.toLowerCase();
    const aVersion = a.split(' patch ')[0];
    const bVersion = b.split(' patch ')[0];
    const aPatch = Number(a.split(' patch ')[1]);
    const bPatch = Number(b.split(' patch ')[1]);
  
    if (Number(aVersion.split('.')[0]) > bVersion.split('.')[0]) return 1;
    if (Number(bVersion.split('.')[0]) > aVersion.split('.')[0]) return -1;
    if (Number(aVersion.split('.')[1]) > bVersion.split('.')[1]) return 1;
    if (Number(bVersion.split('.')[1]) > aVersion.split('.')[1]) return -1;
    if (aVersion === bVersion) {
      if (aPatch > bPatch) return 1;
      if (aPatch < bPatch) return -1;
    } else {
      return 0;
    }
  }

export default {
    sortFunc1,
    sortFunc2,
    sortFunc3,
    sortFunc4,
    sortFunc5,
    sortFunc6
  };