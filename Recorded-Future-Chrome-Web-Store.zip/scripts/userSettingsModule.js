const OPTIONS_KEY = 'userOptions';
const DEFAULT_SETTINGS = {
  highlightingEnabled: true,
  highlightingMinimumCriticality: 1,
  disableMaliciousLinks: false,
  alertTypes: {
    domainAbuse: true
  },
  entityTypesToShow: {
    domain: true,
    url: false,
    hash: true,
    vulnerability: true,
    ip: true
  },
  userCustomBlacklist: [
    '([A-Za-z0-9])+.atlassian.net',
    '([A-Za-z0-9])+.lighting.force.com',
    '([A-Za-z0-9])+.my.salesforce.com',
    'calendar.google.com',
    'mail.google.com',
    'google.com',
    'app.recordedfuture.com',
    'rfadmin.recfut.com',
    'februus.recfut.com'
  ]
};

const setEntityTypesToShow = newEntityTypesToShow => {
  return new Promise(resolve => {
    getUserSettings().then(settings => {
      settings.entityTypesToShow = newEntityTypesToShow;
      saveNewSettings(settings);
      resolve();
    });
  });
};

const getEntityTypesToShow = () => {
  return new Promise(resolve => {
    chrome.storage.local.get([OPTIONS_KEY], items => {
      let currentOptions = items[OPTIONS_KEY] || DEFAULT_SETTINGS;
      let currentEntityTypeOptions = currentOptions.entityTypesToShow || DEFAULT_SETTINGS.entityTypesToShow;
      resolve(currentEntityTypeOptions);
    });
  });
};

const getUserSettings = () => {
  return new Promise(resolve => {
    chrome.storage.local.get([OPTIONS_KEY], items => {
      let currentOptions = items[OPTIONS_KEY] || DEFAULT_SETTINGS;

      // Handle if new settings types have been added that user currently do not have saved in storage
      Object.keys(DEFAULT_SETTINGS).forEach(key => {
        if (currentOptions[key] === undefined || currentOptions[key] === null) { // If current settings do not have this property
          currentOptions[key] = DEFAULT_SETTINGS[key]; // Then get the default settings of that property
        }
      });

      resolve(currentOptions);
    });
  });
};

const saveNewSettings = settings => {
  let newOptions = {};
  newOptions[OPTIONS_KEY] = settings;
  chrome.storage.local.set(newOptions);
};

const addSiteToBlacklist = host => {
  return getUserSettings().then(settings => {
    let userBlacklist = settings.userCustomBlacklist || [];
    if (!userBlacklist.includes(host)) {
      userBlacklist.push(host);
      settings.userCustomBlacklist = userBlacklist;
    }
    saveNewSettings(settings);
  });
};

const removeSiteFromBlacklist = host => {
  return getUserSettings().then(settings => {
    let userBlacklist = settings.userCustomBlacklist || [];

    userBlacklist = userBlacklist.filter(url => !host.match(new RegExp(url, 'g')));

    settings.userCustomBlacklist = userBlacklist;
    saveNewSettings(settings);
  });
};

const getSettingFromStorageByName = async settingName => new Promise(resolve => {
  chrome.storage.local.get([settingName], (items) => {
    const setting = items[settingName];
    resolve(setting);
  });
});

const setSettingInStorageByName = async (settingName, value) => new Promise(resolve => {
  const obj = {};
  obj[settingName] = value;
  chrome.storage.local.set(obj, () => {
    resolve();
  });
});

export default {
  getUserSettings,
  getEntityTypesToShow,
  saveNewSettings,
  addSiteToBlacklist,
  removeSiteFromBlacklist,
  setEntityTypesToShow,
  getSettingFromStorageByName,
  setSettingInStorageByName,
};