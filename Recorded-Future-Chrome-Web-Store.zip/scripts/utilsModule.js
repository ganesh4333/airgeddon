import regExpUtil from "./regExpUtilModule.js";
import userSettings from "./userSettingsModule.js";

import helpers from "./helpers.js";

const baseUrl = "https://app.recordedfuture.com/live/sc/entity/";
const noteUrl = "https://app.recordedfuture.com/live/sc/createnote/";
const dontIncludeTitleURLs = [
  /^https?:\/\/(?:mail|inbox)\.google\.com\//gi,
  /^https?:\/\/[\w\d\.]*live\.com\//gi,
];

const iframePathnames = ["/console/qradar/jsp/QRadar.jsp"];
const iframeDomains = [
  "falcon.crowdstrike.com",
  /([0-9A-Za-z]*.service-now.com)/gi,
  /([0-9A-Za-z]*.azure.com)/gi,
];

var hashObjMaps = {
  document: {},
  iframe: {},
};
var iocsResult;
const intelCardUrls = {};

const URL_SHORTENERS = [
  "tinyurl.com",
  "bit.ly",
  "tiny.cc",
  "rb.gy", //Rebrandly
];

var obfuscationPatterns = {
  ".": /(\s*)\(\.\)(\s*)|(\s*)\[\.\](\s*)/gi,
};

var entityTypesToShowCache;
userSettings.getEntityTypesToShow().then((entityTypesToShow) => {
  entityTypesToShowCache = entityTypesToShow;
});

function getDocumentBody() {
  return document.body;
}

let bkgPort = chrome.runtime.connect({ name: "port-bkg-cs" });
let allReadCanvasTexts = "";
let canvasReadingInProgress = false;

function readAllCanvasTexts() {
  if (canvasReadingInProgress) {
    console.log("Reading of canvas already in progress, aborting");
    return;
  }
  let canvasList = [...document.querySelectorAll("canvas")].map((x) =>
    x.toDataURL("image/png").replace("image/png", "image/octet-stream")
  );

  if (canvasList.length > 0) {
    canvasReadingInProgress = true;

    const promiseList = [];
    canvasList.forEach((canvas) => {
      const promise = getCanvasTextContent(canvas);
      promiseList.push(promise);
    });
    Promise.all(promiseList).then(() => {
      canvasReadingInProgress = false;

      console.log("allReadCanvasTexts", allReadCanvasTexts);

      getEntities().then((entities) => {
        bkgPort.postMessage({ refreshBadge: true, entities });
      });
    });
  }
}

async function getCanvasTextContent(canvas) {
  const { createWorker } = Tesseract;
  const workerPath = chrome.runtime.getURL("./scripts/tesseractworker.min.js");
  const corePath = chrome.runtime.getURL("./scripts/tesseract-core.js");
  const worker = createWorker({
    workerPath,
    corePath,
    logger: (m) => console.log(`Reading canvas: ${m.progress * 100}%`),
  });
  await worker.load();
  await worker.loadLanguage("eng");
  await worker.initialize("eng");
  const {
    data: { text },
  } = await worker.recognize(canvas);
  if (!allReadCanvasTexts.includes(text)) {
    allReadCanvasTexts += "\n" + text;
  }
  await worker.terminate();
  return;
}

//readAllCanvasTexts();

const getAllIframes = () => {
  const iframes = document.getElementsByTagName("iframe");
  const getIframesInsideShadowDoms = (root) => {
    let list = [];
    [...root.querySelectorAll("*")].forEach((x) => {
      if (x.shadowRoot) {
        list = [
          ...list,
          ...[...x.shadowRoot.querySelectorAll("iframe")],
          ...[...getIframesInsideShadowDoms(x.shadowRoot)],
        ];
      }
    });
    return list;
  };
  const iframesInShadowDoms = getIframesInsideShadowDoms(document);
  return [...iframes, ...iframesInShadowDoms];
};

async function getEntities(entityTypesToShow = null) {
  if (entityTypesToShow) {
    entityTypesToShowCache = entityTypesToShow;
  }

  const isPdf = window.location.href
    .split("?")[0]
    .toLowerCase()
    .endsWith(".pdf");
  const containsFrames = document.body.innerHTML.includes("<frame");

  if (isPdf) {
    const text = await helpers.getPdfTextContent(window.location.href);
    const iocs = await findIocs(text, "document", null, true);
    let docIocs = JSON.parse(JSON.stringify(iocs));
    return docIocs;
  } else {
    let docBody = getDocumentBody();
    const iocs = await findIocs(
      docBody,
      "document",
      null,
      false,
      containsFrames
    );

    let docIocs = JSON.parse(JSON.stringify(iocs));
    let iframeMap = {};

    if (iframeDomain()) {
      let iframes = getAllIframes();
      for (let i = 0; i < iframes.length; ++i) {
        let contentDoc = iframes[i].contentDocument;
        if (
          contentDoc !== null &&
          contentDoc.body !== null &&
          isVisible(iframes[i])
        ) {
          let contentDocBody = contentDoc.body;
          let text = trimText(contentDocBody);
          let textHashCode = getHashCodeForString(text);
          let iframeIocs = await findIframeIocs(
            contentDoc,
            contentDocBody,
            textHashCode
          );
          if (iframeIocs) {
            iframeMap[textHashCode] = iframeIocs;
            if (!docIocs) {
              docIocs = iframeIocs;
            } else {
              docIocs.matches.forEach(function (row, index) {
                let newPartial = iframeIocs.matches.find((rowPartial) => {
                  return rowPartial.type === row.type;
                });
                if (newPartial !== undefined) {
                  this[index].iocs = uniqueIocs(row, newPartial);
                }
                if (iframeIocs.frame !== undefined) {
                  Object.values(iframeIocs.frame).forEach((frameRow) => {
                    let newFramePartial = frameRow.matches.find(
                      (framePartial) => {
                        return framePartial.type === row.type;
                      }
                    );
                    this[index].iocs = uniqueIocs(row, newFramePartial);
                  });
                }
              }, docIocs.matches);
              docIocs.documentLength += iframeIocs.documentLength;
            }
          }
        }
      }
      if (Object.keys(iframeMap).length !== 0) {
        hashObjMaps["iframe"] = iframeMap;
      }
    }
    return docIocs;
  }
}

async function findIocs(
  body,
  type,
  parent = null,
  doNotTrim = false,
  containsFrames = false
) {
  if (!regExpUtil) {
    return;
  }

  let text;
  if (containsFrames) {
    text = trimText(body);
    body.querySelectorAll("frame").forEach((frame) => {
      text +=
        frame.contentDocument &&
        frame.contentDocument.body &&
        frame.contentDocument.body.innerText
          ? frame.contentDocument.body.innerText
          : "";
    });
  } else if (doNotTrim) {
    text = body;
  } else {
    text = trimText(body);
  }
  var textHashCode = getHashCodeForString(text);

  // Just check if the page is untouched before trying again...

  if (type in Object.keys(hashObjMaps)) {
    if (textHashCode in hashObjMaps[type]) {
      return hashObjMaps[type][textHashCode];
    }
  } else {
    if (parent !== null && parent.hash in hashObjMaps[parent.type]) {
      if (hashObjMaps[parent.type][parent.hash] === undefined) {
        hashObjMaps[parent.type][parent.hash] = {};
      }
      if (hashObjMaps[parent.type][parent.hash][type] === undefined) {
        hashObjMaps[parent.type][parent.hash][type] = {};
      }
      if (textHashCode in hashObjMaps[parent.type][parent.hash][type]) {
        return hashObjMaps[parent.type][parent.hash][type][textHashCode];
      }
    }
  }

  if (allReadCanvasTexts && allReadCanvasTexts !== "") {
    text += "\n" + allReadCanvasTexts + "\n";
  }

  var iocsLists = {};
  var labels = {};
  var title = {};
  var links = {};

  if (!entityTypesToShowCache) {
    // just in case settings does not exist
    entityTypesToShowCache = {
      domain: true,
      url: true,
      hash: true,
      vulnerability: true,
      ip: true,
    };
  }

  if (entityTypesToShowCache.domain) {
    var idns = regExpUtil.getAllIdnMatches(text);
    iocsLists["idns"] = idns;
    labels["idns"] = "Domain";
    title["idns"] = "Domain risk rules";
    links["idns"] =
      "https://support.recordedfuture.com/hc/en-us/articles/115003793388-Domain-Risk-Rules";
  }
  // always fetch URLs regardless because even though the tab might be disabled in the popup
  // user might still want to highlight URLs in page
  var urls = regExpUtil.getAllPlainTextUrls(text);
  iocsLists["urls"] = urls;
  labels["urls"] = "URL";
  title["urls"] = "URL risk rules";
  links["urls"] =
    "https://support.recordedfuture.com/hc/en-us/articles/115010052768";

  if (entityTypesToShowCache.hash) {
    var hashes = regExpUtil.getAllHashes(text);
    iocsLists["hashes"] = hashes;
    labels["hashes"] = "Hash";
    title["hashes"] = "Hash risk rules";
    links["hashes"] =
      "https://support.recordedfuture.com/hc/en-us/articles/115000846167-Hash-Risk-Rules";
  }
  if (entityTypesToShowCache.vulnerability) {
    var cves = regExpUtil.getAllCves(text);
    iocsLists["cves"] = cves;
    labels["cves"] = "Vulnerability";
    title["cves"] = "Vulnerability risk rules";
    links["cves"] =
      "https://support.recordedfuture.com/hc/en-us/articles/115000894468-Vulnerability-Risk-Rules";
  }
  if (entityTypesToShowCache.ip) {
    var ips = regExpUtil.getAllIps(text);
    iocsLists["ips"] = ips;
    labels["ips"] = "IP Address";
    title["ips"] = "IP Address risk rules";
    links["ips"] =
      "https://support.recordedfuture.com/hc/en-us/articles/115000894448-IP-Address-Risk-Rules";
  }

  var matches = Object.keys(iocsLists).map(function (key) {
    var iocList = iocsLists[key];
    var iocs = iocList.map((ioc) => {
      return {
        name: ioc,
        link: getIntelCardUrl(ioc),
      };
    });

    return {
      type: key,
      label: labels[key],
      supportTitle: title[key],
      supportLink: links[key],
      iocs: iocs,
    };
  });

  for (let i = 0; i < matches.length; i++) {
    const match = matches[i];
    match.iocs = match.iocs.filter((ioc) => {
      const containsDomain = regExpUtil.getAllIdnMatches(ioc.name).length > 0;
      const containsIp = regExpUtil.textContainsIp(ioc.name).length > 0;
      // If the entity contains both a domain and an IP then it will be filtered out
      // This is to avoid including faulty entities that are concatenated from several different strings
      // See RF-74670
      return containsDomain && containsIp ? false : true;
    });
  }

  let urlFromText = matches.find((x) => x.type === "urls").iocs;
  urlFromText.forEach((x) => (x.fromPlainText = true));
  if (!doNotTrim) {
    let urlsFromLinks = regExpUtil.getAllLinkUrls(body);
    urlsFromLinks = urlsFromLinks.map((x) => ({
      name: x,
      fromLink: true,
      link: getIntelCardUrl(x),
    }));

    // Commented out this because this caused a bug RFPD-22472
    //urlFromText = urlFromText.filter(x => !urlsFromLinks.find(y => y.name === x.name));

    matches.find((x) => x.type === "urls").iocs = [
      ...urlFromText,
      ...urlsFromLinks,
    ];
  } else {
    matches.find((x) => x.type === "urls").iocs = [...urlFromText];
  }

  iocsResult = {
    matches: matches,
    documentLength: text.length,
  };

  // Store the textHashCodes for the next time
  if (type in Object.keys(hashObjMaps)) {
    hashObjMaps[type] = { [textHashCode]: iocsResult };
  } else if (parent !== null) {
    if (hashObjMaps[parent.type][parent.hash] === undefined) {
      hashObjMaps[parent.type][parent.hash] = {};
    }
    if (hashObjMaps[parent.type][parent.hash][type] === undefined) {
      hashObjMaps[parent.type][parent.hash][type] = {};
    }
    hashObjMaps[parent.type][parent.hash][type][textHashCode] = iocsResult;
  }

  let urlsList = matches.find((x) => x.type === "urls").iocs;
  let urlsToFetchRedirectLinksFor = [];

  for (let i = 0; i < urlsList.length; i++) {
    const url = urlsList[i];
    if (url.name) {
      const host = new URL(url.name).host;
      if (URL_SHORTENERS.includes(host)) {
        urlsToFetchRedirectLinksFor.push(url.name);
      }
    }
  }
  if (urlsToFetchRedirectLinksFor.length > 0) {
    urlsToFetchRedirectLinksFor = urlsToFetchRedirectLinksFor.filter(
      (item, index) => urlsToFetchRedirectLinksFor.indexOf(item) === index
    ); // remove duplicates
    const resp = await fetchRedirectUrls(urlsToFetchRedirectLinksFor);
    if (resp.length > 0) {
      for (let i = 0; i < resp.length; i++) {
        const item = urlsList.find((x) => x.name === resp[i].from);
        if (item) {
          if (!item.redirect) {
            item.redirect = {};
          }
          item.redirect.redirectsTo = resp[i].to;
        }
      }
    }
  }

  return iocsResult;
}

function fetchRedirectUrls(urlList) {
  return new Promise((resolve) => {
    // fetch from background
    chrome.runtime.sendMessage(
      { action: "getRedirectUrls", urlList },
      (resp) => {
        resolve(resp);
      }
    );
  });
}

async function getNumberOfIocs(body, type) {
  const settings = await userSettings.getUserSettings();
  entityTypesToShowCache = settings.entityTypesToShow;

  var iocsResult = await findIocs(body, type);
  var iocLists = iocsResult && iocsResult.matches;
  var numberOfIocs;

  const iocListsClone = iocLists ? [...iocLists] : [];

  if (!entityTypesToShowCache.url) {
    iocListsClone.find((x) => x.type === "urls").iocs = [];
  } else {
    const urls = iocListsClone.find((x) => x.type === "urls").iocs;
    iocListsClone.find((x) => x.type === "urls").iocs = urls.filter(
      (x) =>
        x.fromPlainText ||
        (x.fromLink && x.riskData && x.riskData.riskScore >= 65)
    );
  }

  numberOfIocs = iocListsClone
    .map(function (iocList) {
      return iocList.iocs.length;
    })
    .reduce(function (sum, n) {
      return sum + n;
    }, 0);
  return numberOfIocs;
}

async function getNumberOfIframeIocsInTab() {
  let iframes = getAllIframes();
  let allIocs = { iocs: [] };

  for (let i = 0; i < iframes.length; ++i) {
    if (isVisible(iframes[i])) {
      let contentDoc = iframes[i].contentDocument;
      if (contentDoc !== null && contentDoc.body !== null) {
        let contentDocBody = contentDoc.body;
        let text = trimText(contentDocBody);
        let textHashCode = getHashCodeForString(text);
        let iframeIocs = await findIframeIocs(
          contentDoc,
          contentDocBody,
          textHashCode
        );
        if (iframeIocs) {
          for (let j = 0; j < iframeIocs.matches.length; j++) {
            const iocRow = iframeIocs.matches[j];
            allIocs.iocs = uniqueIocs(allIocs, iocRow);
          }
          if (iframeIocs.frame !== undefined) {
            const frameRows = Object.values(iframeIocs.frame);
            for (let j = 0; j < frameRows.length; j++) {
              const iocFrameRow = frameRows[j];
              allIocs.iocs = uniqueIocs(allIocs, iocFrameRow);
            }
          }
        }
      }
    }
  }

  return allIocs.iocs.length;
}

async function findIframeIocs(contentDoc, contentDocBody, textHashCode) {
  const iocs = await findIocs(contentDocBody, "iframe");
  let iframeIocs = isVisible(contentDoc)
    ? JSON.parse(JSON.stringify(iocs))
    : { matches: [], documentLength: 0 };
  let frames = contentDocBody.querySelectorAll("frame");
  for (let j = 0; j < frames.length; ++j) {
    if (frames[j].contentDocument && frames[j].contentDocument.body) {
      let parent = { type: "iframe", hash: textHashCode };
      let frameRow = await findIocs(
        frames[j].contentDocument.body,
        "frame",
        parent
      );
      if (iframeIocs["frame"] === undefined) {
        iframeIocs["frame"] = {};
      }
      let frameText = trimText(frames[j].contentDocument.body);
      let frameTextHashCode = getHashCodeForString(frameText);
      iframeIocs["frame"][frameTextHashCode] = frameRow;
      iframeIocs.documentLength += frameRow.documentLength;
    }
  }
  return iframeIocs;
}

function openIntelCard(text) {
  if (!regExpUtil) {
    return;
  }

  text = deobfuscate(text.toLowerCase());

  var intelCardUrl = getIntelCardUrl(text);

  if (intelCardUrl) {
    window.open(intelCardUrl, "_blank");
  }
}

function trimText(body) {
  // Get the document text
  if (body.innerText && body.innerText === "") {
    return "";
  }
  let text = typeof body === "object" ? getDocumentText(body).trim() : body;

  /* eslint-disable no-control-regex */
  const scriptsRegex = new RegExp(
    "<s*script[^>]*>((.|\n)*?)<s*/s*script>",
    "gm"
  );
  const imgsRegex = new RegExp("<s*img[^>]*>", "gm");

  if (text && typeof text === "string") {
    text = text.replace(scriptsRegex, " ");
    text = text.replace(imgsRegex, " ");
  }
  /* eslint-enable no-control-regex */

  return deobfuscate(text).replace(/%2F/gi, " ");
}

function getHashCodeForString(s) {
  return s.split("").reduce(function (a, b) {
    a = (a << 5) - a + b.charCodeAt(0);
    return a & a;
  }, 0);
}

function iframeDomain() {
  return (
    document.querySelectorAll("iframe").length > 0 ||
    iframePathnames.includes(window.location.pathname) ||
    iframeDomains.includes(document.domain) ||
    iframeDomains.some((x) => document.domain.match(new RegExp(x, "g")))
  );
}

function uniqueIocs(row, partial) {
  return [...row.iocs, ...partial.iocs].filter(
    (elem, index, self) =>
      self.findIndex((tmpRow) => {
        return tmpRow.name === elem.name;
      }) === index
  );
}

//////////////////////////////////////////////////////////////////////

// This is to handle special cases that can not be captured normally with just innerText
function getAdditionalElements(body) {
  let result = "";
  body.querySelectorAll("text").forEach((t) => {
    // If the body contains text elements (inside an SVG) then Firefox have a problem formatting these with just innerText
    // Therefore we need to append these manually so that Firefox can capture them
    if (t && t.textContent) {
      result += t.textContent + "\n";
    }
  });
  return result;
}

function getDocumentText(body) {
  let innerText = body.innerText;

  if (document.getElementById("rfAdditionalBodyText")) {
    innerText +=
      " " + document.getElementById("rfAdditionalBodyText").innerText;
  }

  let docTxt = body !== null ? innerText || filteredTextContent(body) : "";
  docTxt += getShadowDomText(body);
  docTxt += getAdditionalElements(body);

  /* eslint-disable no-control-regex */
  const scriptsRegex = new RegExp(
    "<s*script[^>]*>((.|\n)*?)<s*/s*script>",
    "gm"
  );
  const imgsRegex = new RegExp("<s*img[^>]*>", "gm");
  docTxt = docTxt.replace(scriptsRegex, " ");
  docTxt = docTxt.replace(imgsRegex, " ");
  /* eslint-enable no-control-regex */

  return docTxt;
}

function getChildNodeText(root) {
  let childTxt = [];
  for (let el of root.childNodes) {
    if (
      el.nodeType === 1 &&
      !(el instanceof (HTMLStyleElement || HTMLScriptElement)) &&
      isVisible(el)
    ) {
      let chTxt = el.innerText || filteredTextContent(el);
      if (getHashCodeForString(chTxt) !== 0) {
        childTxt.push(chTxt);
      }
    }
  }
  return childTxt;
}

function getShadowDomText(root) {
  let txt = "";
  const ELEMENTS_TO_SKIP = [
    "html",
    "head",
    "script",
    "noscript",
    "style",
    "img",
    "input",
    "video",
    "button",
    "code",
    "svg", // svg related element
    "g", // svg related element
    "rect", // svg related element
    "circle", // svg related element
    "ellipse", // svg related element
    "polygon", // svg related element
    "linearGradient", // svg related element
    "radialGradient", // svg related element
    "defs", // svg related element
    "path", // svg related element
    "mask", // svg related element
    "stop", // svg related element
    "use", // svg related element
    "switch", // svg related element
    "head",
    "title",
    "meta",
    "link",
    "iframe",
    "textarea",
    "dom-module", // Youtube specific stuff
    "dom-if", // Youtube specific stuff
    "dom-repeat", // Youtube specific stuff
    "yt-icon", // Youtube specific stuff
    "ytd-badge-supported-renderer", // Youtube specific stuff
    "ytd-thumbnail-overlay-now-playing-renderer", // Youtube specific stuff
    "ytd-thumbnail-overlay-time-status-renderer", // Youtube specific stuff
    "ytd-thumbnail-overlay-equalizer", // Youtube specific stuff
    "ytd-thumbnail", // Youtube specific stuff
    "ytd-menu-renderer", // Youtube specific stuff
    "ytd-grid-video-renderer", // Youtube specific stuff
    "ytd-badge-supported-renderer", // Youtube specific stuff
    "yt-interaction", // Youtube specific stuff
    "yt-icon-button", // Youtube specific stuff
    "yt-formatted-string", // Youtube specific stuff
    "tp-yt-paper-tooltip", // Youtube specific stuff
    "yt-img-shadow", // Youtube specific stuff
    "ytd-channel-name", // Youtube specific stuff
    "ytd-rich-grid-media", // youtube specific stuff
    "ytd-rich-item-renderer", // youtube specific stuff
    "ytd-guide-entry-renderer", // youtube specific stuff
    "ytd-video-renderer", // youtube specific stuff
    "ytd-button-renderer", // youtube specific stuff
    "ytd-video-meta-block", // youtube specific stuff
    "template", // Youtube specific stuff
    "clipPath",
    ".rfBrowextIocHighlightLink",
    ".rfBrowextIocHighlightLink__image",
    ".rfBrowextIocHighlightLink__title",
    ".rfBrowextIocHighlightLink__riskplupp",
    ".rfBrowextIocHighlightLink__tooltip",
    ".rfBrowextIocHighlightLink__risk",
    /* '.rfBrowextUrlHighlightLink', */
    ".rfBrowextUrlHighlightLink__image",
    ".rfBrowextUrlHighlightLink__title",
    ".rfBrowextUrlHighlightLink__riskplupp",
    ".rfBrowextUrlHighlightLink__tooltip",
    ".rfBrowextUrlHighlightLink__risk",
    ".rfBrowextUrlHighlightLink__disabledIcon",
    ".rfBrowextUrlHighlightLink__riskScoreWrapper" /* ,
      '.rfHighlightForeignObject' */,
  ];
  const query = ELEMENTS_TO_SKIP.reduce(
    (total, current) => `${total}:not(${current})`,
    "*"
  );
  for (let el of root.querySelectorAll(query)) {
    if (el.shadowRoot) {
      txt =
        txt +
        getChildNodeText(el.shadowRoot).join(" ") +
        getShadowDomText(el.shadowRoot);
    }
  }
  return txt;
}

function deobfuscate(text) {
  text = typeof text === "object" ? text.innerText : text;
  for (var replacement in obfuscationPatterns) {
    if (obfuscationPatterns.hasOwnProperty(replacement)) {
      var searchPattern = obfuscationPatterns[replacement];
      text = text.replace(searchPattern, replacement);
    }
  }
  return text;
}

function filteredTextContent(node) {
  let result = "";
  [].forEach.call(
    node.querySelectorAll(
      "*:not(html):not(head):not(script):not(meta):not(link)"
    ),
    function (elem) {
      if ("textContent" in elem) {
        result += elem.textContent;
      }
    }
  );
  return result;
}

function getIntelCardUrl(text) {
  if (intelCardUrls[text]) {
    return intelCardUrls[text];
  }

  var prefix;
  if (!regExpUtil) {
    return;
  }

  text = deobfuscate(text.toLowerCase());

  if (regExpUtil.isIp4(text)) {
    prefix = "ip:";
    text = regExpUtil.getAllIp4Matches(text)[0];
    if (text) {
      text = normalizeIPv4(text);
    }
  } else if (regExpUtil.isIp6(text)) {
    prefix = "ip:";
    text = regExpUtil.getAllIp6Matches(text)[0];
  } else if (regExpUtil.isIdn(text)) {
    prefix = "idn:";
    text = regExpUtil.getAllIdnMatches(text)[0];
  } else if (regExpUtil.isHash(text)) {
    prefix = "hash:";
    text = regExpUtil.getAllHashes(text)[0];
  } else if (regExpUtil.isCve(text)) {
    prefix = "?name=";
  } else {
    // JIRA RF-16222 Support vulnerability, malware, and threat actor cards
    prefix = "?name=";
  }

  const ret = text && baseUrl + prefix + text.toLowerCase();
  intelCardUrls[text] = ret;
  return ret;
}

function getCreateNoteUrl(pageTitle, pageUrl, selectedText) {
  return (
    noteUrl +
    "?title=" +
    encodeURIComponent(pageTitle) +
    "&text=" +
    encodeURIComponent(selectedText) +
    "&validation_url=" +
    encodeURIComponent(pageUrl)
  );
}

function isTitleAndURLincluded(url) {
  var match = dontIncludeTitleURLs.find(function (pattern) {
    return url.match(pattern) != null;
  });
  return !match;
}

function normalizeIPv4(ip) {
  return ip
    .split(".")
    .map(function (val) {
      return parseInt(val);
    })
    .join(".");
}

function isVisible(contentDocument) {
  let body = contentDocument.body;
  let width = Math.max(
    body ? getBodyWidth(body) : 0,
    contentDocument ? getDocumentWidth(contentDocument) : 0
  );
  let height = Math.max(
    body ? getBodyHeight(body) : 0,
    contentDocument ? getDocumentHeight(contentDocument) : 0
  );
  return height > 10 && width > 10;
}

function getBodyWidth(body) {
  return Math.max(body.scrollWidth || 0, body.offsetWidth);
}

function getDocumentWidth(doc) {
  return Math.max(
    doc.clientWidth || 0,
    doc.scrollWidth || 0,
    doc.offsetWidth || 0
  );
}

function getBodyHeight(body) {
  return Math.max(body.scrollHeight || 0, body.offsetHeight);
}

function getDocumentHeight(doc) {
  return Math.max(
    doc.clientHeight || 0,
    doc.scrollHeight || 0,
    doc.offsetHeight || 0
  );
}

export default {
  readAllCanvasTexts,
  findIocs,
  getEntities,
  getIntelCardUrl,
  getCreateNoteUrl,
  getNumberOfIocs,
  getNumberOfIframeIocsInTab,
  openIntelCard,
  isTitleAndURLincluded,
  isVisible,
  trimText,
  getHashCodeForString,
  iframeDomain,
};
